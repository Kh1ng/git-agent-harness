//! TICKET-066: parse rate-limit and quota-reset signals from backend
//! failure output.
//!
//! Every classification pattern in this module exists because a real,
//! provenance-tracked example justified it — see
//! `tests/fixtures/quota-logs/PROVENANCE.md` and the fixture-driven tests
//! in this module's own `#[cfg(test)]` block below (this is a binary
//! crate with no library target, so integration tests under `tests/`
//! cannot call into `src/` modules directly — fixture tests for pure
//! `src/` logic live as unit tests here instead, loading the same fixture
//! files via `include_str!`). Do not add a new pattern here without a
//! matching real fixture. No live provider calls are made or required —
//! this only ever parses text already captured elsewhere.
//!
//! Wired into the dispatch path via
//! `dispatch::attempts::mark_backend_unavailable_from_output_for_identity_at`,
//! which calls `parse()` after a backend run completes and feeds the result
//! into `availability::record_unavailable_for_identity`.
#![allow(dead_code)]

use chrono::{DateTime, Duration as ChronoDuration, NaiveTime, TimeZone, Utc};
use chrono_tz::Tz;
use regex::Regex;
use std::sync::OnceLock;
use time::format_description::well_known::Rfc3339;
use time::{Date, Month, OffsetDateTime, PrimitiveDateTime, Time};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FailureKind {
    /// Account/subscription usage or weekly limit exhausted. Not worth
    /// retrying until (if known) `reset_at`.
    QuotaExhausted,
    /// Transient throttling (HTTP 429-shaped, server load, or an
    /// unspecified "rate limit" with no indication it's account-level
    /// exhaustion). Worth retrying after a short cooldown.
    RateLimited,
    /// Authentication failure (invalid token, not logged in, etc).
    AuthenticationError,
    /// Explicit model context window / context length exhaustion. This is
    /// a routing signal: the same backend may succeed with a larger-context
    /// model, and the whole backend/account should not be disabled.
    ContextLimitExceeded,
    /// GAH observed a genuinely idle backend process. This is a harness
    /// watchdog classification, never provider quota/rate-limit evidence.
    BackendStalled,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum Confidence {
    /// Recognized a generic/ambiguous pattern with real-world reports of
    /// it meaning different things in different contexts (see the generic
    /// Claude "Rate limit reached" fixture's provenance note).
    Low,
    Medium,
    /// Language is unambiguous about which failure kind this is.
    High,
}

#[derive(Debug, Clone)]
pub struct ParsedFailure {
    pub backend: String,
    pub kind: FailureKind,
    /// Whether a short-term retry loop is worth attempting at all. `false`
    /// for quota/billing exhaustion; `true` for transient rate limiting or a
    /// bounded reroute after a harness-observed backend stall.
    pub retryable: bool,
    /// RFC3339. Only set when resolved with actual confidence — see
    /// `unresolved_timezone` for the case where we recognized a reset
    /// time but couldn't resolve it to an absolute instant.
    pub reset_at: Option<String>,
    pub retry_after_seconds: Option<u64>,
    pub confidence: Confidence,
    /// The specific substring that triggered classification, for audit
    /// trails and debugging false positives/negatives.
    pub matched_evidence: String,
    /// Set when the message named an explicit IANA-style timezone (e.g.
    /// "America/Santiago") that we could not resolve to an absolute
    /// instant (invalid identifier, ambiguous/invalid local datetime, or
    /// conversion failure). `reset_at` is left `None` in that case rather
    /// than guessing an offset.
    pub unresolved_timezone: Option<String>,
}

/// A short, conservative cooldown for rate-limit classifications that
/// carry no better timing information from the provider. This is a
/// policy default, not something read from the message — never applied
/// to quota_exhausted, where a made-up short cooldown would be actively
/// harmful (hammering an exhausted account).
const CONSERVATIVE_RATE_LIMIT_COOLDOWN_SECONDS: u64 = 60;

fn transient_not_usage_limit_re() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| Regex::new(r"(?i)not your usage limit").unwrap())
}

fn usage_or_weekly_limit_re() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| Regex::new(r"(?i)(usage limit|weekly limit|monthly limit|daily limit|quota exhausted|insufficient (credits|quota))").unwrap())
}

fn insufficient_balance_re() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| {
        Regex::new(
            r"(?i)(account balance (?:is )?insufficient|insufficient (?:account )?balance|credit balance.{0,24}(?:insufficient|exhausted)|payment required)",
        )
        .unwrap()
    })
}

fn generic_rate_limit_re() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| {
        Regex::new(r"(?i)(rate limit|(?:code|status|http|error)\s*:?\s*429|RESOURCE_EXHAUSTED|overloaded|server busy)").unwrap()
    })
}

fn codex_selected_model_capacity_re() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| {
        Regex::new(r#"(?i)\"message\"\s*:\s*\"Selected model is at capacity\. Please try a different model\.\""#)
            .unwrap()
    })
}

fn authentication_error_re() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| {
        Regex::new(
            r"(?i)(invalid api key|api key (?:is )?(?:invalid|expired|revoked)|missing [A-Z0-9_-]*api key|authentication failed|not authenticated|not logged in|(?:access |refresh |oauth )?token (?:has |is )?expired|\b(?:http|status)(?: code)?[: ]+40[13]\b|\b40[13] (?:unauthorized|forbidden)\b)",
        )
        .unwrap()
    })
}

/// Shape: "Feb 23rd, 2026 9:01 PM" / "Apr 7th, 2026 1:07 AM" — full date
/// and time, no timezone.
fn full_date_time_re() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| {
        Regex::new(
            r"(?i)\b([A-Za-z]{3,9})\.?\s+(\d{1,2})(?:st|nd|rd|th)?,\s*(\d{4})\s+(\d{1,2}):(\d{2})\s*(AM|PM)\b",
        )
        .unwrap()
    })
}

/// Shape: "2:57 PM" — time only, no date, no timezone.
fn time_only_re() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| Regex::new(r"(?i)\bat\s+(\d{1,2}):(\d{2})\s*(AM|PM)\b").unwrap())
}

/// Shape: "2:30 PM (America/Santiago)" — minute-bearing reset with explicit
/// IANA timezone.
fn time_only_with_tz_minute_re() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| {
        Regex::new(r"(?i)\b(\d{1,2}):(\d{2})\s*(AM|PM)\s*\(([A-Za-z_]+/[A-Za-z_]+)\)").unwrap()
    })
}

/// Shape: "3pm (America/Santiago)" — hour only (no minutes), explicit
/// named timezone in parens.
fn time_only_with_tz_re() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| {
        Regex::new(r"(?i)\b(\d{1,2})\s*(am|pm)\s*\(([A-Za-z_]+/[A-Za-z_]+)\)").unwrap()
    })
}

/// Shape: "Jun 3 at 4pm (Europe/Berlin)" — month + day (no year), explicit
/// named timezone in parens.
fn month_day_time_with_tz_re() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| {
        Regex::new(
            r"(?i)\b([A-Za-z]{3,9})\s+(\d{1,2})\s+at\s+(\d{1,2})\s*(am|pm)\s*\(([A-Za-z_]+/[A-Za-z_]+)\)",
        )
        .unwrap()
    })
}

fn agy_quota_re() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| Regex::new(r"(?i)(Individual quota reached|AGY quota exhausted)").unwrap())
}

fn agy_auth_re() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| {
        Regex::new(r"(?i)(not logged into Antigravity|not logged in|AGY not authenticated)")
            .unwrap()
    })
}

fn claude_session_limit_re() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| Regex::new(r"(?i)\byour session limit\b.*\bresets\b").unwrap())
}

fn context_window_exhausted_re() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| {
        Regex::new(
            r"(?i)(ran out of room in the model['\s]s context window|ran out of (?:room in |the )?model['\s]s? context (?:window|length)|context (?:window|length) (?:is )?(?:full|exceeded|at capacity|limit reached)|maximum context (?:length|window) reached|context limit exceeded|out of context(?: window)?)",
        )
        .unwrap()
    })
}

fn to_zoned_reset_at(
    now: OffsetDateTime,
    hour12: u8,
    minute: u8,
    ampm: &str,
    zone_name: &str,
) -> (Option<String>, Option<String>) {
    let zone: Tz = match zone_name.parse() {
        Ok(zone) => zone,
        Err(_) => return (None, Some(zone_name.to_string())),
    };

    let Some(now_utc) = DateTime::<Utc>::from_timestamp(now.unix_timestamp(), now.nanosecond())
    else {
        return (None, Some(zone_name.to_string()));
    };

    let local_now = now_utc.with_timezone(&zone);
    let hour = to_24h(hour12, ampm);
    let Some(local_time) = NaiveTime::from_hms_opt(hour.into(), minute.into(), 0) else {
        return (None, Some(zone_name.to_string()));
    };

    let mut local_candidate = local_now.date_naive().and_time(local_time);
    if local_candidate <= local_now.naive_local() {
        local_candidate += ChronoDuration::days(1);
    }

    let utc_candidate = match zone.from_local_datetime(&local_candidate) {
        chrono::LocalResult::Single(candidate) => Some(candidate.with_timezone(&Utc)),
        // A wall-clock time during the fall-back hour identifies two real
        // instants. Picking either would fabricate precision the provider
        // did not supply, so keep the timezone unresolved and fail closed.
        chrono::LocalResult::Ambiguous(_, _) | chrono::LocalResult::None => None,
    };

    let Some(utc_candidate) = utc_candidate else {
        return (None, Some(zone_name.to_string()));
    };

    (
        OffsetDateTime::from_unix_timestamp(utc_candidate.timestamp())
            .ok()
            .and_then(|ts| ts.format(&Rfc3339).ok()),
        None,
    )
}

fn parse_agy_cooldown_seconds(text: &str) -> Option<u64> {
    static RE: OnceLock<Regex> = OnceLock::new();
    let re = RE.get_or_init(|| {
        Regex::new(r"(?i)\bResets\s+(?:in|~)\s*(?:(\d+)h)?\s*(?:(\d+)m)?\s*(?:(\d+)s)?\b").unwrap()
    });
    if let Some(caps) = re.captures(text) {
        let mut total_secs = 0u64;
        let mut matched = false;
        if let Some(h_match) = caps.get(1) {
            if let Ok(h) = h_match.as_str().parse::<u64>() {
                total_secs += h * 3600;
                matched = true;
            }
        }
        if let Some(m_match) = caps.get(2) {
            if let Ok(m) = m_match.as_str().parse::<u64>() {
                total_secs += m * 60;
                matched = true;
            }
        }
        if let Some(s_match) = caps.get(3) {
            if let Ok(s) = s_match.as_str().parse::<u64>() {
                total_secs += s;
                matched = true;
            }
        }
        if matched && total_secs > 0 {
            return Some(total_secs);
        }
    }
    None
}

fn parse_month(name: &str) -> Option<Month> {
    let lower = name.to_ascii_lowercase();
    let key = &lower[..lower.len().min(3)];
    Some(match key {
        "jan" => Month::January,
        "feb" => Month::February,
        "mar" => Month::March,
        "apr" => Month::April,
        "may" => Month::May,
        "jun" => Month::June,
        "jul" => Month::July,
        "aug" => Month::August,
        "sep" => Month::September,
        "oct" => Month::October,
        "nov" => Month::November,
        "dec" => Month::December,
        _ => return None,
    })
}

fn to_24h(hour12: u8, ampm: &str) -> u8 {
    let h = hour12 % 12;
    if ampm.eq_ignore_ascii_case("pm") {
        h + 12
    } else {
        h
    }
}

/// Reset-time resolution result: `(reset_at_rfc3339, unresolved_timezone)`.
/// At most one of the two is ever `Some` for a given input.
fn extract_reset(text: &str, now: OffsetDateTime) -> (Option<String>, Option<String>) {
    // Named-timezone shapes take priority and are checked first: if a
    // timezone is explicitly present, never fall through to a no-timezone
    // shape that would silently assume `now`'s offset instead.
    if let Some(caps) = time_only_with_tz_minute_re().captures(text) {
        if let (Ok(hour12), Ok(minute)) = (caps[1].parse::<u8>(), caps[2].parse::<u8>()) {
            return to_zoned_reset_at(now, hour12, minute, &caps[3], &caps[4]);
        }
        return (None, Some(caps[4].to_string()));
    }

    if let Some(caps) = month_day_time_with_tz_re().captures(text) {
        return (None, Some(caps[5].to_string()));
    }
    if let Some(caps) = time_only_with_tz_re().captures(text) {
        return (None, Some(caps[3].to_string()));
    }

    if let Some(caps) = full_date_time_re().captures(text) {
        if let (Some(month), Ok(day), Ok(year), Ok(hour12), Ok(minute)) = (
            parse_month(&caps[1]),
            caps[2].parse::<u8>(),
            caps[3].parse::<i32>(),
            caps[4].parse::<u8>(),
            caps[5].parse::<u8>(),
        ) {
            let hour = to_24h(hour12, &caps[6]);
            if let (Ok(date), Ok(time)) = (
                Date::from_calendar_date(year, month, day),
                Time::from_hms(hour, minute, 0),
            ) {
                let naive = PrimitiveDateTime::new(date, time);
                let resolved = naive.assume_offset(now.offset());
                return (
                    resolved
                        .format(&time::format_description::well_known::Rfc3339)
                        .ok(),
                    None,
                );
            }
        }
        return (None, None);
    }

    if let Some(caps) = time_only_re().captures(text) {
        if let (Ok(hour12), Ok(minute)) = (caps[1].parse::<u8>(), caps[2].parse::<u8>()) {
            let hour = to_24h(hour12, &caps[3]);
            if let Ok(time) = Time::from_hms(hour, minute, 0) {
                let mut candidate =
                    PrimitiveDateTime::new(now.date(), time).assume_offset(now.offset());
                if candidate <= now {
                    candidate += time::Duration::days(1);
                }
                return (
                    candidate
                        .format(&time::format_description::well_known::Rfc3339)
                        .ok(),
                    None,
                );
            }
        }
        return (None, None);
    }

    (None, None)
}

/// Parse a single backend failure message. Returns `None` when nothing
/// recognizable as quota exhaustion or rate limiting is present — callers
/// must be able to tell "we saw this and don't know what it is" apart from
/// "we're confident this isn't a quota/rate-limit failure at all".
pub fn parse(backend: &str, text: &str, now: OffsetDateTime) -> Option<ParsedFailure> {
    // agy-main/agy-second are legacy instance strings, not kinds (see
    // backend_kind.rs); fold them locally before dispatching on the kind.
    // `backend` itself stays untouched below -- ParsedFailure.backend is
    // built from the original string, not the folded kind.
    use crate::backend_kind::BackendKind;
    let kind = match backend {
        "agy-main" | "agy-second" => Some(BackendKind::Agy),
        other => BackendKind::parse(other).ok(),
    };

    if kind == Some(BackendKind::Codex) {
        if let Some(m) = codex_selected_model_capacity_re().find(text) {
            return Some(ParsedFailure {
                backend: backend.to_string(),
                kind: FailureKind::RateLimited,
                retryable: true,
                reset_at: None,
                retry_after_seconds: Some(CONSERVATIVE_RATE_LIMIT_COOLDOWN_SECONDS),
                confidence: Confidence::High,
                matched_evidence: extract_evidence_line(text, m.start(), m.end()),
                unresolved_timezone: None,
            });
        }
    }

    // AGY-specific patterns checked first: auth errors and quota exhaustion.
    if kind == Some(BackendKind::Agy) {
        if let Some(m) = agy_auth_re().find(text) {
            return Some(ParsedFailure {
                backend: backend.to_string(),
                kind: FailureKind::AuthenticationError,
                retryable: true,
                reset_at: None,
                retry_after_seconds: None,
                confidence: Confidence::High,
                matched_evidence: extract_evidence_line(text, m.start(), m.end()),
                unresolved_timezone: None,
            });
        }

        if let Some(m) = agy_quota_re().find(text) {
            let reset_at = parse_agy_cooldown_seconds(text).map(|secs| {
                let reset_time = now + time::Duration::seconds(secs as i64);
                reset_time
                    .format(&time::format_description::well_known::Rfc3339)
                    .unwrap_or_default()
            });
            return Some(ParsedFailure {
                backend: backend.to_string(),
                kind: FailureKind::QuotaExhausted,
                retryable: false,
                reset_at,
                retry_after_seconds: None,
                confidence: Confidence::High,
                matched_evidence: extract_evidence_line(text, m.start(), m.end()),
                unresolved_timezone: None,
            });
        }
    }

    if kind == Some(BackendKind::Claude) {
        if let Some(m) = claude_session_limit_re().find(text) {
            let (reset_at, unresolved_timezone) = extract_reset(text, now);
            return Some(ParsedFailure {
                backend: backend.to_string(),
                kind: FailureKind::QuotaExhausted,
                retryable: false,
                reset_at,
                retry_after_seconds: None,
                confidence: Confidence::High,
                matched_evidence: extract_evidence_line(text, m.start(), m.end()),
                unresolved_timezone,
            });
        }
    }

    if let Some(m) = authentication_error_re().find(text) {
        return Some(ParsedFailure {
            backend: backend.to_string(),
            kind: FailureKind::AuthenticationError,
            retryable: false,
            reset_at: None,
            retry_after_seconds: None,
            confidence: Confidence::High,
            matched_evidence: extract_evidence_line(text, m.start(), m.end()),
            unresolved_timezone: None,
        });
    }

    // Highest precedence: an explicit "not your usage limit" disclaimer
    // must never be classified as quota exhaustion, even though the phrase
    // itself contains the substring "usage limit".
    if let Some(m) = transient_not_usage_limit_re().find(text) {
        let _ = m;
        return Some(ParsedFailure {
            backend: backend.to_string(),
            kind: FailureKind::RateLimited,
            retryable: true,
            reset_at: None,
            retry_after_seconds: Some(CONSERVATIVE_RATE_LIMIT_COOLDOWN_SECONDS),
            confidence: Confidence::High,
            matched_evidence: extract_evidence_line(text, m.start(), m.end()),
            unresolved_timezone: None,
        });
    }

    if let Some(m) = usage_or_weekly_limit_re().find(text) {
        let (reset_at, unresolved_timezone) = extract_reset(text, now);
        return Some(ParsedFailure {
            backend: backend.to_string(),
            kind: FailureKind::QuotaExhausted,
            retryable: false,
            reset_at,
            retry_after_seconds: None,
            confidence: Confidence::High,
            matched_evidence: extract_evidence_line(text, m.start(), m.end()),
            unresolved_timezone,
        });
    }

    if let Some(m) = insufficient_balance_re().find(text) {
        return Some(ParsedFailure {
            backend: backend.to_string(),
            kind: FailureKind::QuotaExhausted,
            retryable: false,
            reset_at: None,
            retry_after_seconds: None,
            confidence: Confidence::High,
            matched_evidence: extract_evidence_line(text, m.start(), m.end()),
            unresolved_timezone: None,
        });
    }

    if let Some(m) = generic_rate_limit_re().find(text) {
        // Real-world reports (see PROVENANCE.md) show this generic phrasing
        // can be client-side/session-related rather than account quota
        // exhaustion, so this is deliberately low-confidence and carries
        // no invented reset time.
        return Some(ParsedFailure {
            backend: backend.to_string(),
            kind: FailureKind::RateLimited,
            retryable: true,
            reset_at: None,
            retry_after_seconds: Some(CONSERVATIVE_RATE_LIMIT_COOLDOWN_SECONDS),
            confidence: Confidence::Low,
            matched_evidence: extract_evidence_line(text, m.start(), m.end()),
            unresolved_timezone: None,
        });
    }

    // Context window exhaustion is checked after backend-specific patterns to avoid
    // shadowing existing backend-specific classifications. This is a routing signal:
    // the same backend may succeed with a larger-context model, so it should be
    // retryable and not disable the whole backend/account.
    if let Some(m) = context_window_exhausted_re().find(text) {
        return Some(ParsedFailure {
            backend: backend.to_string(),
            kind: FailureKind::ContextLimitExceeded,
            retryable: true,
            reset_at: None,
            retry_after_seconds: None,
            confidence: Confidence::High,
            matched_evidence: extract_evidence_line(text, m.start(), m.end()),
            unresolved_timezone: None,
        });
    }

    None
}

/// The line containing the match, trimmed, for readable evidence in
/// multi-line log output; falls back to the raw match text for single-line
/// or JSON-blob inputs where "line" isn't a meaningful unit.
fn extract_evidence_line(text: &str, match_start: usize, match_end: usize) -> String {
    let line_start = text[..match_start].rfind('\n').map(|i| i + 1).unwrap_or(0);
    let line_end = text[match_end..]
        .find('\n')
        .map(|i| match_end + i)
        .unwrap_or(text.len());
    let line = text[line_start..line_end].trim();
    if line.is_empty() {
        text[match_start..match_end].to_string()
    } else {
        line.to_string()
    }
}

#[cfg(test)]
mod tests {
    //! Every test here loads a real, provenance-tracked fixture from
    //! tests/fixtures/quota-logs/ (see PROVENANCE.md there) rather than an
    //! invented string. The only hand-written strings in this module are
    //! the negative-test inputs, which exist specifically to prove the
    //! parser does NOT match things it shouldn't — see
    //! `unrelated_text_containing_limit_does_not_match`.
    use super::*;

    fn utc(year: i32, month: Month, day: u8, hour: u8, minute: u8) -> OffsetDateTime {
        PrimitiveDateTime::new(
            Date::from_calendar_date(year, month, day).unwrap(),
            Time::from_hms(hour, minute, 0).unwrap(),
        )
        .assume_utc()
    }

    const CODEX_FULL_RESET: &str =
        include_str!("../tests/fixtures/quota-logs/codex_usage_exhausted_full_reset.txt");
    const CODEX_ADMIN_VARIANT: &str =
        include_str!("../tests/fixtures/quota-logs/codex_usage_exhausted_admin_variant.txt");
    const CODEX_TIME_ONLY: &str =
        include_str!("../tests/fixtures/quota-logs/codex_usage_exhausted_time_only.txt");
    const CODEX_SELECTED_MODEL_CAPACITY: &str =
        include_str!("../tests/fixtures/quota-logs/codex_selected_model_at_capacity.jsonl");
    const CODEX_CONTEXT_WINDOW_EXHAUSTED: &str =
        include_str!("../tests/fixtures/quota-logs/codex_context_window_exhausted.txt");
    const CLAUDE_TZ_RESET: &str =
        include_str!("../tests/fixtures/quota-logs/claude_usage_exhausted_tz_reset.txt");
    const CLAUDE_SESSION_LIMIT_TZ_RESET: &str =
        include_str!("../tests/fixtures/quota-logs/claude_session_limit_tz_reset.txt");
    const CLAUDE_WEEKLY_LIMIT: &str =
        include_str!("../tests/fixtures/quota-logs/claude_weekly_limit_structured.json");
    const CLAUDE_GENERIC_RATE_LIMIT: &str =
        include_str!("../tests/fixtures/quota-logs/claude_generic_rate_limit.json");
    const CLAUDE_GENERIC_RATE_LIMIT_ZERO_TOKENS: &str =
        include_str!("../tests/fixtures/quota-logs/claude_generic_rate_limit_zero_tokens.json");
    const CLAUDE_TRANSIENT_THROTTLE: &str =
        include_str!("../tests/fixtures/quota-logs/claude_transient_throttle.json");
    const AGY_AUTH_NOT_LOGGED_IN: &str =
        include_str!("../tests/fixtures/quota-logs/agy_auth_not_logged_in.txt");
    const OPENCODE_HY3_RATE_LIMIT: &str =
        include_str!("../tests/fixtures/quota-logs/opencode_hy3_rate_limit.log");
    const VIBE_INVALID_API_KEY: &str =
        include_str!("../tests/fixtures/quota-logs/vibe_invalid_api_key.txt");

    // ── Codex: full date+time, no timezone (openai/codex #12299) ───────────

    #[test]
    fn codex_full_reset_resolves_to_absolute_instant() {
        let now = utc(2026, Month::January, 1, 0, 0);
        let parsed = parse("codex", CODEX_FULL_RESET, now).unwrap();
        assert_eq!(parsed.kind, FailureKind::QuotaExhausted);
        assert!(!parsed.retryable);
        assert_eq!(parsed.confidence, Confidence::High);
        assert_eq!(parsed.reset_at.as_deref(), Some("2026-02-23T21:01:00Z"));
        assert_eq!(parsed.unresolved_timezone, None);
        assert!(parsed
            .matched_evidence
            .to_lowercase()
            .contains("usage limit"));
    }

    // ── Codex: business/admin variant (openai/codex #16906) ────────────────

    #[test]
    fn codex_admin_variant_full_reset_resolves() {
        let now = utc(2026, Month::January, 1, 0, 0);
        let parsed = parse("codex", CODEX_ADMIN_VARIANT, now).unwrap();
        assert_eq!(parsed.kind, FailureKind::QuotaExhausted);
        assert_eq!(parsed.reset_at.as_deref(), Some("2026-04-07T01:07:00Z"));
    }

    // ── Codex: time-only reset (openai/codex #16847) — day rollover ────────

    #[test]
    fn codex_time_only_reset_stays_same_day_when_still_ahead() {
        // "try again at 2:57 PM", observed at 10:00 UTC the same day.
        let now = utc(2026, Month::March, 10, 10, 0);
        let parsed = parse("codex", CODEX_TIME_ONLY, now).unwrap();
        assert_eq!(parsed.kind, FailureKind::QuotaExhausted);
        assert_eq!(parsed.reset_at.as_deref(), Some("2026-03-10T14:57:00Z"));
    }

    #[test]
    fn codex_time_only_reset_rolls_over_to_next_day_when_already_past() {
        // Same message, but observed at 18:00 UTC -- 2:57 PM has already
        // passed today, so the reset must roll over to tomorrow.
        let now = utc(2026, Month::March, 10, 18, 0);
        let parsed = parse("codex", CODEX_TIME_ONLY, now).unwrap();
        assert_eq!(parsed.reset_at.as_deref(), Some("2026-03-11T14:57:00Z"));
    }

    #[test]
    fn codex_time_only_reset_rolls_over_across_a_month_boundary() {
        // Exercise rollover specifically across a day/month boundary, not
        // just an ordinary day increment.
        let now = utc(2026, Month::March, 31, 18, 0);
        let parsed = parse("codex", CODEX_TIME_ONLY, now).unwrap();
        assert_eq!(parsed.reset_at.as_deref(), Some("2026-04-01T14:57:00Z"));
    }

    #[test]
    fn codex_selected_model_capacity_is_treated_as_model_level_rate_limit() {
        let now = utc(2026, Month::July, 15, 21, 29);
        let parsed = parse("codex", CODEX_SELECTED_MODEL_CAPACITY, now).unwrap();

        assert_eq!(parsed.kind, FailureKind::RateLimited);
        assert!(parsed.retryable);
        assert_eq!(parsed.reset_at, None);
        assert_eq!(
            parsed.retry_after_seconds,
            Some(CONSERVATIVE_RATE_LIMIT_COOLDOWN_SECONDS)
        );
        assert!(parsed.matched_evidence.contains(
            "\"message\":\"Selected model is at capacity. Please try a different model.\""
        ),);
        assert_eq!(parsed.unresolved_timezone, None);
    }

    // ── Claude: explicit IANA timezone (anthropics/claude-code #9236) ──────

    #[test]
    fn claude_tz_reset_classifies_quota_exhausted_but_leaves_reset_at_unset() {
        let now = utc(2026, Month::January, 1, 0, 0);
        let parsed = parse("claude", CLAUDE_TZ_RESET, now).unwrap();
        assert_eq!(parsed.kind, FailureKind::QuotaExhausted);
        assert_eq!(parsed.confidence, Confidence::High);
        assert_eq!(
            parsed.reset_at, None,
            "must not silently assume local timezone when an explicit zone is present"
        );
        assert_eq!(
            parsed.unresolved_timezone.as_deref(),
            Some("America/Santiago")
        );
    }

    #[test]
    fn claude_session_limit_tz_reset_parses_exact_reset_time() {
        let now = utc(2026, Month::January, 15, 10, 0);
        let parsed = parse("claude", CLAUDE_SESSION_LIMIT_TZ_RESET, now).unwrap();
        assert_eq!(parsed.kind, FailureKind::QuotaExhausted);
        assert!(!parsed.retryable);
        assert_eq!(parsed.unresolved_timezone, None);
        assert_eq!(parsed.reset_at.as_deref(), Some("2026-01-15T20:30:00Z"));
        assert_eq!(parsed.confidence, Confidence::High);
    }

    #[test]
    fn claude_session_limit_tz_reset_respects_summertime_offsets() {
        let now = utc(2026, Month::July, 15, 10, 0);
        let parsed = parse("claude", CLAUDE_SESSION_LIMIT_TZ_RESET, now).unwrap();
        assert_eq!(parsed.reset_at.as_deref(), Some("2026-07-15T19:30:00Z"));
    }

    #[test]
    fn claude_session_limit_does_not_guess_unknown_or_ambiguous_timezone() {
        let now = utc(2026, Month::November, 1, 0, 0);

        let unknown = parse(
            "claude",
            "You've hit your session limit · resets 2:30pm (Mars/Olympus).",
            now,
        )
        .unwrap();
        assert_eq!(unknown.reset_at, None);
        assert_eq!(unknown.unresolved_timezone.as_deref(), Some("Mars/Olympus"));

        let ambiguous = parse(
            "claude",
            "You've hit your session limit · resets 1:30am (America/Chicago).",
            now,
        )
        .unwrap();
        assert_eq!(ambiguous.reset_at, None);
        assert_eq!(
            ambiguous.unresolved_timezone.as_deref(),
            Some("America/Chicago")
        );
    }

    // ── Claude: weekly limit, structured event (anthropics/claude-code #68816) ─

    #[test]
    fn claude_weekly_limit_structured_classifies_quota_exhausted_reset_unresolved() {
        let now = utc(2026, Month::January, 1, 0, 0);
        let parsed = parse("claude", CLAUDE_WEEKLY_LIMIT, now).unwrap();
        assert_eq!(parsed.kind, FailureKind::QuotaExhausted);
        assert_eq!(parsed.reset_at, None);
        assert_eq!(parsed.unresolved_timezone.as_deref(), Some("Europe/Berlin"));
    }

    // ── Claude: generic ambiguous rate_limit (anthropics/claude-code #41583, #33840) ─

    #[test]
    fn claude_generic_rate_limit_is_low_confidence_with_no_fabricated_reset() {
        let now = utc(2026, Month::January, 1, 0, 0);
        let parsed = parse("claude", CLAUDE_GENERIC_RATE_LIMIT, now).unwrap();
        assert_eq!(parsed.kind, FailureKind::RateLimited);
        assert_eq!(
            parsed.confidence,
            Confidence::Low,
            "reports show this generic phrasing can be client-side/session-related, not account quota exhaustion"
        );
        assert_eq!(parsed.reset_at, None);
        assert_eq!(
            parsed.retry_after_seconds,
            Some(CONSERVATIVE_RATE_LIMIT_COOLDOWN_SECONDS)
        );
    }

    #[test]
    fn claude_generic_rate_limit_zero_tokens_variant_classifies_the_same() {
        let now = utc(2026, Month::January, 1, 0, 0);
        let parsed = parse("claude", CLAUDE_GENERIC_RATE_LIMIT_ZERO_TOKENS, now).unwrap();
        assert_eq!(parsed.kind, FailureKind::RateLimited);
        assert_eq!(parsed.confidence, Confidence::Low);
        assert_eq!(parsed.reset_at, None);
    }

    // ── Claude: explicit transient throttle (anthropics/claude-code #64030) ─
    // Required negative test: this must never be classified as quota
    // exhaustion, even though its own text contains the substring
    // "usage limit" (inside "not your usage limit").

    #[test]
    fn claude_transient_server_throttle_is_not_quota_exhaustion() {
        let now = utc(2026, Month::January, 1, 0, 0);
        let parsed = parse("claude", CLAUDE_TRANSIENT_THROTTLE, now).unwrap();
        assert_eq!(parsed.kind, FailureKind::RateLimited);
        assert_ne!(parsed.kind, FailureKind::QuotaExhausted);
        assert!(parsed.retryable);
        assert_eq!(parsed.reset_at, None);
    }

    #[test]
    fn opencode_internal_hy3_rate_limit_is_classified_without_a_fabricated_reset() {
        let now = utc(2026, Month::January, 1, 0, 0);
        let parsed = parse("opencode", OPENCODE_HY3_RATE_LIMIT, now).unwrap();
        assert_eq!(parsed.kind, FailureKind::RateLimited);
        assert_eq!(parsed.reset_at, None);
        assert_eq!(
            parsed.retry_after_seconds,
            Some(CONSERVATIVE_RATE_LIMIT_COOLDOWN_SECONDS)
        );
        assert!(parsed.matched_evidence.contains("Rate limit exceeded"));
    }

    #[test]
    fn opencode_insufficient_balance_is_non_retryable_quota_unavailability() {
        let now = utc(2026, Month::January, 1, 0, 0);
        let parsed = parse(
            "opencode",
            "Error: Forbidden: Sorry, your account balance is insufficient",
            now,
        )
        .unwrap();
        assert_eq!(parsed.kind, FailureKind::QuotaExhausted);
        assert!(!parsed.retryable);
        assert_eq!(parsed.confidence, Confidence::High);
        assert_eq!(parsed.reset_at, None);
        assert!(parsed.matched_evidence.contains("balance is insufficient"));
    }

    // ── Required negative tests ──────────────────────────────────────────

    #[test]
    fn generic_rate_limit_reached_does_not_produce_a_fabricated_reset() {
        let now = utc(2026, Month::January, 1, 0, 0);
        let parsed = parse("claude", CLAUDE_GENERIC_RATE_LIMIT, now).unwrap();
        assert_eq!(parsed.reset_at, None);
        assert_eq!(parsed.unresolved_timezone, None);
    }

    #[test]
    fn unrelated_text_containing_limit_does_not_match() {
        let now = utc(2026, Month::January, 1, 0, 0);
        let text = "The disk quota limit is configured to 10GB per user in settings.";
        assert!(
            parse("codex", text, now).is_none(),
            "the word 'limit' alone must not trigger a quota/rate-limit classification"
        );
    }

    #[test]
    fn malformed_reset_text_preserves_classification_but_leaves_reset_unset() {
        let now = utc(2026, Month::January, 1, 0, 0);
        // Same shape as a real Codex reset string, but with an unrecognized
        // month name -- classification (from the independent "usage limit"
        // phrase) must survive; the reset time must not be guessed.
        let text = "You've hit your usage limit... try again at Blah 23rd, 2026 9:01 PM.";
        let parsed = parse("codex", text, now).unwrap();
        assert_eq!(parsed.kind, FailureKind::QuotaExhausted);
        assert_eq!(parsed.reset_at, None);
        assert_eq!(parsed.unresolved_timezone, None);
    }

    #[test]
    fn evidence_is_preserved_and_nonempty_for_every_match() {
        let now = utc(2026, Month::January, 1, 0, 0);
        for fixture in [
            CODEX_FULL_RESET,
            CODEX_ADMIN_VARIANT,
            CODEX_TIME_ONLY,
            CLAUDE_TZ_RESET,
            CLAUDE_WEEKLY_LIMIT,
            CLAUDE_GENERIC_RATE_LIMIT,
            CLAUDE_TRANSIENT_THROTTLE,
        ] {
            let parsed = parse("test", fixture, now).unwrap();
            assert!(!parsed.matched_evidence.trim().is_empty());
        }
    }

    // ── AGY: quota/auth classification (TICKET-107) ─────────────────────
    //
    // Real evidence exists on this host only for the auth-failure text
    // (see PROVENANCE.md, `agy_auth_not_logged_in.txt`). No real AGY
    // quota-exhaustion capture exists yet, so the quota-branch tests below
    // exercise the literal strings already shipped in `agy_quota_re`
    // rather than an external fixture -- see PROVENANCE.md for the caveat.

    #[test]
    fn agy_resource_exhausted_without_subscription_evidence_is_transient() {
        let now = utc(2026, Month::January, 1, 0, 0);
        let parsed = parse("agy-main", "Error: RESOURCE_EXHAUSTED", now).unwrap();
        assert_eq!(parsed.kind, FailureKind::RateLimited);
        assert!(parsed.retryable);
        assert_eq!(parsed.confidence, Confidence::Low);
    }

    #[test]
    fn agy_contextual_code_429_is_transient() {
        let now = utc(2026, Month::January, 1, 0, 0);
        let parsed = parse("agy-second", "request failed with code 429", now).unwrap();
        assert_eq!(parsed.kind, FailureKind::RateLimited);
    }

    #[test]
    fn agy_individual_quota_reached_classifies_as_quota_exhaustion() {
        let now = utc(2026, Month::January, 1, 0, 0);
        let parsed = parse(
            "agy",
            include_str!("../tests/fixtures/quota-logs/agy_individual_quota_reached.txt"),
            now,
        )
        .unwrap();
        assert_eq!(parsed.kind, FailureKind::QuotaExhausted);
        assert_eq!(parsed.reset_at.as_deref(), Some("2026-01-07T18:54:28Z"));
    }

    #[test]
    fn agy_auth_failure_classifies_as_authentication_error() {
        let now = utc(2026, Month::January, 1, 0, 0);
        let parsed = parse("agy-main", AGY_AUTH_NOT_LOGGED_IN, now).unwrap();
        assert_eq!(parsed.kind, FailureKind::AuthenticationError);
        assert!(parsed.retryable);
        assert_eq!(parsed.confidence, Confidence::High);
    }

    #[test]
    fn vibe_invalid_api_key_classifies_as_non_retryable_authentication_error() {
        let now = utc(2026, Month::July, 15, 21, 29);
        let parsed = parse("vibe", VIBE_INVALID_API_KEY, now).unwrap();
        assert_eq!(parsed.kind, FailureKind::AuthenticationError);
        assert!(!parsed.retryable);
        assert_eq!(parsed.confidence, Confidence::High);
        assert_eq!(parsed.reset_at, None);
    }

    #[test]
    fn agy_naked_429_without_context_does_not_match() {
        let now = utc(2026, Month::January, 1, 0, 0);
        // The regex requires the literal phrase "code 429" -- a bare 429
        // digit sequence elsewhere in unrelated text must not classify.
        let text = "The bus route 429 was delayed this morning.";
        assert!(
            parse("agy-main", text, now).is_none(),
            "a naked 429 unrelated to an HTTP/error code must not classify as quota exhaustion"
        );
    }

    #[test]
    fn agy_unknown_empty_failure_returns_none() {
        let now = utc(2026, Month::January, 1, 0, 0);
        assert!(parse("agy-main", "", now).is_none());
        assert!(parse("agy-second", "process exited with no output", now).is_none());
    }

    // ── Context window exhaustion (Issue #437) ─────────────────────────────────

    #[test]
    fn codex_context_window_exhausted_from_real_fixture() {
        let now = utc(2026, Month::January, 1, 0, 0);
        let parsed = parse("codex", CODEX_CONTEXT_WINDOW_EXHAUSTED, now).unwrap();
        assert_eq!(parsed.kind, FailureKind::ContextLimitExceeded);
        assert!(
            parsed.retryable,
            "context exhaustion should be retryable with larger context model"
        );
        assert_eq!(parsed.confidence, Confidence::High);
        assert!(parsed.matched_evidence.contains("ran out of room"));
        assert_eq!(parsed.reset_at, None);
        assert_eq!(parsed.retry_after_seconds, None);
    }

    #[test]
    fn context_window_exhausted_variants_are_also_detected() {
        let now = utc(2026, Month::January, 1, 0, 0);
        let variants = [
            ("Context window is full", "Context window"),
            ("Context length exceeded", "Context length"),
            ("Maximum context window reached", "Maximum context"),
            ("Context limit exceeded", "Context limit"),
            ("Out of context", "Out of context"),
        ];
        for (text, expected_content) in variants {
            let parsed = parse("test", text, now);
            match parsed {
                Some(ref p) => {
                    assert_eq!(
                        p.kind,
                        FailureKind::ContextLimitExceeded,
                        "failed for: {}",
                        text
                    );
                    assert!(p.retryable);
                    assert_eq!(p.confidence, Confidence::High);
                    assert!(
                        p.matched_evidence.contains(expected_content),
                        "expected evidence to contain '{}' for text '{}', got '{}'",
                        expected_content,
                        text,
                        p.matched_evidence
                    );
                }
                None => panic!("parse returned None for text: {}", text),
            }
        }
    }

    #[test]
    fn context_exhaustion_works_for_multiple_providers() {
        let now = utc(2026, Month::January, 1, 0, 0);
        let text = "ran out of room in the model's context window";
        for backend in ["codex", "claude", "vibe", "opencode", "agy"] {
            let parsed = parse(backend, text, now).unwrap();
            assert_eq!(
                parsed.kind,
                FailureKind::ContextLimitExceeded,
                "failed for backend: {}",
                backend
            );
            assert!(parsed.retryable);
        }
    }

    #[test]
    fn unrelated_context_text_does_not_false_positive() {
        let now = utc(2026, Month::January, 1, 0, 0);
        // These should NOT match context exhaustion patterns
        let non_matches = [
            "The context of the conversation was saved",
            "In the context of this problem",
            "Contextual understanding is important",
            "This is a context-free grammar",
        ];
        for text in non_matches {
            assert!(
                parse("test", text, now).is_none(),
                "false positive for: {}",
                text
            );
        }
    }
}
