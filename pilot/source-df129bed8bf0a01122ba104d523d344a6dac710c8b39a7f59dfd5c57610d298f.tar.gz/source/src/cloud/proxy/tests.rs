use super::*;
mod pilot;

#[test]
fn a_slow_request_cannot_extend_the_proxy_deadline() {
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let mut peer = TcpStream::connect(listener.local_addr().unwrap()).unwrap();
    let sender = std::thread::spawn(move || {
        for _ in 0..40 {
            if peer.write_all(b"P").is_err() {
                break;
            }
            std::thread::sleep(Duration::from_millis(250));
        }
    });
    let (mut stream, _) = listener.accept().unwrap();
    let began = Instant::now();
    assert!(read_request(&mut stream, "job-only-key").is_err());
    assert!(began.elapsed() < Duration::from_secs(8));
    drop(stream);
    sender.join().unwrap();
}

fn parse(request: &str) -> Result<(String, Vec<u8>)> {
    let listener = TcpListener::bind("127.0.0.1:0")?;
    let mut peer = TcpStream::connect(listener.local_addr()?)?;
    peer.write_all(request.as_bytes())?;
    peer.shutdown(std::net::Shutdown::Write)?;
    let (mut stream, _) = listener.accept()?;
    read_request(&mut stream, "job-only-key")
}

#[test]
fn loopback_proxy_requires_job_auth_and_rejects_smuggled_requests() {
    let body = "{\"model\":\"pilot\"}";
    let valid=format!("POST /v1/chat/completions HTTP/1.1\r\nAuthorization: Bearer job-only-key\r\nContent-Length: {}\r\n\r\n{body}",body.len());
    let (path, parsed) = parse(&valid).unwrap();
    assert_eq!(path, "chat/completions");
    assert_eq!(parsed, body.as_bytes());
    assert!(parse(&valid.replace("job-only-key", "someone-else")).is_err());
    assert!(parse(&valid.replace("chat/completions", "../../admin")).is_err());
    assert!(parse(&valid.replace(
        "Content-Length:",
        "Transfer-Encoding: chunked\r\nContent-Length:"
    ))
    .is_err());
    assert!(
        parse(&valid.replace("Content-Length:", "Content-Length: 1\r\nContent-Length:")).is_err()
    );
    assert!(parse(&format!("{valid}extra")).is_err());
}

#[test]
fn provider_transport_stops_when_access_is_revoked_without_echoing_a_key() {
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let address = listener.local_addr().unwrap();
    let stop = Arc::new(AtomicBool::new(false));
    let ready = stop.clone();
    let server = std::thread::spawn(move || {
        let (mut socket, _) = listener.accept().unwrap();
        socket
            .set_read_timeout(Some(Duration::from_secs(10)))
            .unwrap();
        let mut buf = [0; 4096];
        let _ = socket.read(&mut buf);
        ready.store(true, Ordering::Release);
        let _ = socket.read(&mut buf);
    });
    let checks = AtomicUsize::new(0);
    let error = crate::curl_http::cloud_provider_request(
        &format!("http://{address}/v1/chat/completions"),
        "{}",
        "private-provider-key",
        || checks.fetch_add(1, Ordering::SeqCst) == 0,
    )
    .err()
    .unwrap();
    assert!(stop.load(Ordering::Acquire));
    assert_eq!(error.to_string(), "inference access denied");
    assert!(!format!("{error:?}").contains("private-provider-key"));
    server.join().unwrap();
}
