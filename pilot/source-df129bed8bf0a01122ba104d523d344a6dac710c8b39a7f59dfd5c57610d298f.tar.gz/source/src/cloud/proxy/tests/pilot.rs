use super::*;
use std::io::{BufRead, BufReader};
use std::sync::Mutex;

fn request(socket: &TcpStream) -> (String, String, Value) {
    socket
        .set_read_timeout(Some(Duration::from_secs(10)))
        .unwrap();
    let mut reader = BufReader::new(socket.try_clone().unwrap());
    let mut headers = String::new();
    let mut length = 0;
    loop {
        let mut line = String::new();
        reader.read_line(&mut line).unwrap();
        if line == "\r\n" {
            break;
        }
        assert!(!line.is_empty());
        if let Some(value) = line.to_ascii_lowercase().strip_prefix("content-length:") {
            length = value.trim().parse().unwrap();
        }
        headers.push_str(&line);
    }
    let path = headers.split_whitespace().nth(1).unwrap().to_owned();
    let mut body = vec![0; length];
    reader.read_exact(&mut body).unwrap();
    (path, headers, serde_json::from_slice(&body).unwrap())
}

#[test]
fn two_devices_relay_inference_without_transferring_the_provider_credential() {
    let provider_listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let provider_address = provider_listener.local_addr().unwrap();
    let provider = std::thread::spawn(move || {
        let (mut socket, _) = provider_listener.accept().unwrap();
        let (_, headers, body) = request(&socket);
        assert!(headers.contains("Bearer owner-provider-canary"));
        assert_eq!(body["model"], "pilot-model");
        let response=json!({"id":"pilot","object":"chat.completion","model":"pilot-model","choices":[{"index":0,"message":{"role":"assistant","content":"served by the AI node"},"finish_reason":"stop"}]}).to_string();
        respond(&mut socket, 200, false, response.as_bytes());
    });
    let cloud = TcpListener::bind("127.0.0.1:0").unwrap();
    let origin = format!("http://{}", cloud.local_addr().unwrap());
    let inbox = Arc::new(Mutex::new(None));
    let shared = inbox.clone();
    let server = std::thread::spawn(move || {
        let mut completed = None;
        loop {
            let (mut socket, _) = cloud.accept().unwrap();
            let (path, headers, body) = request(&socket);
            assert!(!headers.contains("owner-provider-canary"));
            assert!(!body.to_string().contains("owner-provider-canary"));
            let value = match path.as_str() {
                "/rest/v1/rpc/enqueue_cloud_inference" => {
                    assert_eq!(body["p_device_token"], "compute-device-only");
                    assert_eq!(body["p_body"]["model"], "pilot-model");
                    *shared.lock().unwrap() = Some(
                        json!({"id":"request","claim_id":"inference-claim","path":body["p_path"],"body":body["p_body"]}),
                    );
                    json!("request")
                }
                "/rest/v1/rpc/check_cloud_inference" => {
                    assert_eq!(body["p_device_token"], "inference-device-only");
                    json!(true)
                }
                "/rest/v1/rpc/finish_cloud_inference" => {
                    assert_eq!(body["p_device_token"], "inference-device-only");
                    completed =
                        Some(json!({"status":body["p_status"],"response":body["p_response"]}));
                    json!(true)
                }
                "/rest/v1/rpc/poll_cloud_inference" => {
                    assert_eq!(body["p_device_token"], "compute-device-only");
                    completed.clone().unwrap_or(Value::Null)
                }
                _ => panic!("unexpected cloud operation"),
            };
            respond(&mut socket, 200, false, value.to_string().as_bytes());
            if path == "/rest/v1/rpc/poll_cloud_inference" && !value.is_null() {
                break;
            }
        }
    });
    let device = |node: &str, token: &str| Device {
        device_id: node.into(),
        device_token: token.into(),
        workspace_id: "workspace".into(),
        node_id: node.into(),
        origin: origin.clone(),
        key: "public-test-key".into(),
    };
    let job = Job {
        workspace_id: "workspace".into(),
        work_id: uuid::Uuid::new_v4().to_string(),
        node_id: "compute".into(),
        profile: "repo".into(),
        mode: "improve".into(),
        target: 42,
        memory_mb: 512,
        claim_id: uuid::Uuid::new_v4().to_string(),
        inference_node_id: Some("inference".into()),
        inference_model: Some("pilot-model".into()),
    };
    let proxy = JobProxy::start(device("compute", "compute-device-only"), job).unwrap();
    let owner = device("inference", "inference-device-only");
    let owner_worker = std::thread::spawn(move || {
        let deadline = Instant::now() + Duration::from_secs(10);
        loop {
            if let Some(request) = inbox.lock().unwrap().take() {
                InferenceProvider {
                    url: format!("http://{provider_address}/v1"),
                    key: "owner-provider-canary".into(),
                    models: vec!["pilot-model".into()],
                }
                .serve(&owner, request, &AtomicBool::new(false));
                break;
            }
            assert!(Instant::now() < deadline);
            std::thread::sleep(Duration::from_millis(25));
        }
    });
    let config: Value = serde_json::from_str(&proxy.opencode_config()).unwrap();
    let endpoint = format!(
        "{}/chat/completions",
        config["provider"]["gah-cloud"]["options"]["baseURL"]
            .as_str()
            .unwrap()
    );
    let token = config["provider"]["gah-cloud"]["options"]["apiKey"]
        .as_str()
        .unwrap();
    let response = crate::curl_http::cloud_request_with_timeout(
        &endpoint,
        &json!({"model":"pilot-model","messages":[{"role":"user","content":"test"}]}).to_string(),
        Some(token),
        None,
        15,
    )
    .unwrap();
    assert_eq!(response.status, 200);
    assert!(String::from_utf8_lossy(&response.body).contains("served by the AI node"));
    assert!(!String::from_utf8_lossy(&response.body).contains("owner-provider-canary"));
    owner_worker.join().unwrap();
    server.join().unwrap();
    provider.join().unwrap();
    drop(proxy);
}
