//! Supabase connection, private session storage, and revocable device credentials.
use super::{endpoint, OrchestrationConfig, OrchestrationMode};
use anyhow::{bail, Result};
use fs2::FileExt;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::io::Write;
use std::path::{Path, PathBuf};

#[derive(Clone)]
pub struct CloudClient {
    pub origin: String,
    pub key: String,
    pub workspace: String,
}

#[derive(Deserialize, Serialize)]
struct Session {
    origin: String,
    access_token: String,
    refresh_token: String,
    expires_at: i64,
}

#[derive(Clone, Deserialize, Serialize)]
pub struct Device {
    pub device_id: String,
    pub device_token: String,
    pub workspace_id: String,
    pub node_id: String,
    pub origin: String,
    pub key: String,
}

/// Resolve only explicit connection values; no hosted identifier is compiled in.
impl CloudClient {
    pub fn from_config(config: &OrchestrationConfig) -> Result<Self> {
        let env = |name: &str| std::env::var(name).ok();
        let mode = match env("GAH_ORCHESTRATION_MODE").as_deref() {
            Some("hosted") => OrchestrationMode::Hosted,
            Some("self-hosted") => OrchestrationMode::SelfHosted,
            Some("local") => OrchestrationMode::Local,
            Some(_) => bail!("unknown GAH_ORCHESTRATION_MODE"),
            None => config.mode,
        };
        if mode == OrchestrationMode::Local {
            bail!("cloud orchestration is not configured");
        }
        let origin = endpoint(&super::required(&env, "GAH_SUPABASE_URL")?, mode)?
            .origin()
            .ascii_serialization();
        let key = super::required(&env, "GAH_SUPABASE_ANON_KEY")?;
        if key.starts_with("sb_secret_") {
            bail!("use a publishable or anon key");
        }
        let workspace = env("GAH_SUPABASE_WORKSPACE_ID")
            .or_else(|| config.workspace_id.clone())
            .ok_or_else(|| anyhow::anyhow!("missing cloud workspace ID"))?;
        uuid::Uuid::parse_str(&workspace)
            .map_err(|_| anyhow::anyhow!("invalid cloud workspace ID"))?;
        Ok(Self {
            origin,
            key,
            workspace,
        })
    }

    pub fn request(&self, path: &str, body: Value, token: Option<&str>) -> Result<Value> {
        let response = crate::curl_http::cloud_request(
            &format!("{}/{}", self.origin, path),
            &body.to_string(),
            token,
            &self.key,
        )?;
        if !(200..300).contains(&response.status) {
            // Use only known Auth codes. Upstream messages can contain private data.
            if path.starts_with("auth/v1/") {
                let error: Value = serde_json::from_slice(&response.body).unwrap_or(Value::Null);
                let code = error["error_code"]
                    .as_str()
                    .or_else(|| error["code"].as_str());
                let explanation = match code {
                    Some("invalid_credentials") => Some("Sign-in rejected: check the email and password for this Supabase instance."),
                    Some("email_not_confirmed") => Some("Sign-in rejected: confirm this account's email before signing in."),
                    Some("email_address_invalid" | "validation_failed") => Some("Sign-in rejected: enter a valid account email address."),
                    Some("over_request_rate_limit" | "over_email_send_rate_limit") => Some("Sign-in rate limit reached. Wait before trying again."),
                    _ => None,
                };
                if let Some(explanation) = explanation {
                    bail!("{explanation}");
                }
            }
            bail!("cloud request rejected (HTTP {})", response.status);
        }
        if response.body.is_empty() {
            return Ok(Value::Null);
        }
        serde_json::from_slice(&response.body)
            .map_err(|_| anyhow::anyhow!("invalid cloud response"))
    }

    pub fn user_rpc(&self, name: &str, body: Value) -> Result<Value> {
        let token = self.user_token()?;
        self.request(&format!("rest/v1/rpc/{name}"), body, Some(&token))
    }

    /// Existing accounts can sign in with an email code. Secrets are read on stdin.
    pub fn login(&self, email: &str) -> Result<()> {
        self.request(
            "auth/v1/otp",
            json!({"email":email,"create_user":false}),
            None,
        )?;
        eprintln!("Enter the email sign-in code. The Auth email template must include the code:");
        let mut code = String::new();
        std::io::stdin().read_line(&mut code)?;
        let value = self.request(
            "auth/v1/verify",
            json!({"email":email,"token":code.trim(),"type":"email"}),
            None,
        )?;
        self.save_session(value)
    }

    /// Use an existing account's password without retaining it in the saved session.
    pub fn login_password(&self, email: &str, password: &str) -> Result<()> {
        if password.is_empty() {
            bail!("password is required");
        }
        let value = self.request(
            "auth/v1/token?grant_type=password",
            json!({"email":email,"password":password}),
            None,
        )?;
        self.save_session(value)
    }

    fn save_session(&self, value: Value) -> Result<()> {
        let session = self.session_from(value)?;
        let path = session_path();
        let _lock = private_lock(&path)?;
        private_write(&path, &serde_json::to_vec(&session)?)?;
        Ok(())
    }

    fn session_from(&self, value: Value) -> Result<Session> {
        Ok(Session {
            origin: self.origin.clone(),
            access_token: value["access_token"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("missing access token"))?
                .into(),
            refresh_token: value["refresh_token"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("missing refresh token"))?
                .into(),
            expires_at: chrono::Utc::now().timestamp()
                + value["expires_in"]
                    .as_i64()
                    .ok_or_else(|| anyhow::anyhow!("missing token expiry"))?,
        })
    }

    pub fn user_token(&self) -> Result<String> {
        if let Ok(token) = std::env::var("GAH_SUPABASE_ACCESS_TOKEN") {
            if !token.is_empty() && !token.contains(['\r', '\n']) {
                return Ok(token);
            }
            bail!("invalid user access token");
        }
        let path = session_path();
        let _lock = private_lock(&path)?;
        let mut session: Session = private_read(&path)
            .and_then(|bytes| serde_json::from_slice(&bytes).map_err(Into::into))
            .map_err(|_| anyhow::anyhow!("sign in with gah cloud login"))?;
        if session.origin != self.origin {
            bail!("cloud session belongs to another origin; sign in again");
        }
        if session.expires_at <= chrono::Utc::now().timestamp() + 60 {
            let value = self.request(
                "auth/v1/token?grant_type=refresh_token",
                json!({"refresh_token":session.refresh_token}),
                None,
            )?;
            session = self.session_from(value)?;
            private_write(&path, &serde_json::to_vec(&session)?)?;
        }
        Ok(session.access_token)
    }
}

impl Device {
    pub fn load(path: &Path) -> Result<Self> {
        let device: Self = serde_json::from_slice(&private_read(path)?)
            .map_err(|_| anyhow::anyhow!("invalid device file"))?;
        endpoint(&device.origin, OrchestrationMode::SelfHosted)?;
        uuid::Uuid::parse_str(&device.workspace_id)?;
        if device.key.starts_with("sb_secret_") || device.device_token.len() != 72 {
            bail!("invalid device credential");
        }
        Ok(device)
    }
    pub fn rpc(&self, name: &str, mut body: Value) -> Result<Value> {
        body["p_device_token"] = json!(self.device_token);
        CloudClient {
            origin: self.origin.clone(),
            key: self.key.clone(),
            workspace: self.workspace_id.clone(),
        }
        .request(&format!("rest/v1/rpc/{name}"), body, None)
    }
}

fn session_path() -> PathBuf {
    crate::config::default_config_dir().join("cloud-session.json")
}

/// Secret files reject symlinks and public permissions; replacement is atomic.
pub fn private_read(path: &Path) -> Result<Vec<u8>> {
    use std::io::Read;
    let mut options = std::fs::OpenOptions::new();
    options.read(true);
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        options.custom_flags(libc::O_NOFOLLOW);
    }
    let file = options.open(path)?;
    let metadata = file.metadata()?;
    if !metadata.is_file() {
        bail!("secret path must be a regular file");
    }
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        if metadata.permissions().mode() & 0o077 != 0 {
            bail!("secret file permissions must be 0600");
        }
    }
    let mut bytes = Vec::new();
    file.take(65537).read_to_end(&mut bytes)?;
    if bytes.len() > 65536 {
        bail!("secret file is too large");
    }
    Ok(bytes)
}
pub fn private_write(path: &Path, bytes: &[u8]) -> Result<()> {
    let parent = path
        .parent()
        .filter(|p| !p.as_os_str().is_empty())
        .unwrap_or(Path::new("."));
    std::fs::create_dir_all(parent)?;
    if path.exists() {
        private_read(path)?;
    }
    let mut file = tempfile::NamedTempFile::new_in(parent)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        file.as_file()
            .set_permissions(std::fs::Permissions::from_mode(0o600))?;
    }
    file.write_all(bytes)?;
    file.as_file().sync_all()?;
    file.persist(path)?;
    Ok(())
}
fn private_lock(path: &Path) -> Result<std::fs::File> {
    let parent = path.parent().unwrap();
    std::fs::create_dir_all(parent)?;
    let mut options = std::fs::OpenOptions::new();
    options.create(true).truncate(false).read(true).write(true);
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        options.mode(0o600).custom_flags(libc::O_NOFOLLOW);
    }
    let file = options.open(path.with_extension("lock"))?;
    file.lock_exclusive()?;
    Ok(file)
}
