use super::*;

#[test]
fn cloud_launch_is_accepted_by_the_dispatch_cli() {
    use clap::Parser;
    let config = std::path::Path::new("/private/config with spaces.toml");
    let command = dispatch_command(&job(), "opencode", config).unwrap();
    let args = std::iter::once(command.get_program()).chain(command.get_args());
    let parsed = crate::cli::args::Cli::try_parse_from(args).unwrap();
    let crate::cli::args::Commands::Dispatch {
        config_path,
        profile,
        target,
        ..
    } = parsed.command
    else {
        panic!("cloud worker must launch dispatch");
    };
    assert_eq!(config_path.as_deref(), config.to_str());
    assert_eq!(profile, "repo");
    assert_eq!(target, "42");
}

fn options() -> WorkerOptions {
    WorkerOptions {
        device: Device {
            device_id: uuid::Uuid::new_v4().to_string(),
            device_token: "private-test-only".into(),
            workspace_id: "workspace".into(),
            node_id: "compute".into(),
            origin: "https://example.test".into(),
            key: "public".into(),
        },
        config_path: None,
        profiles: vec!["repo".into()],
        backend: "opencode".into(),
        max_concurrent: 1,
        memory_budget_mb: 1024,
        reserve_memory_mb: 1024,
        allow_inference_relay: false,
        inference_models: vec![],
        once: true,
    }
}
fn job() -> Job {
    Job {
        workspace_id: "workspace".into(),
        work_id: uuid::Uuid::new_v4().to_string(),
        node_id: "compute".into(),
        profile: "repo".into(),
        mode: "improve".into(),
        target: 42,
        memory_mb: 512,
        claim_id: uuid::Uuid::new_v4().to_string(),
        inference_node_id: None,
        inference_model: None,
    }
}

#[test]
fn cloud_claims_cannot_substitute_launch_parameters() {
    let options = options();
    let valid = job();
    valid.validate(&options).unwrap();
    let mut invalid = valid.clone();
    invalid.profile = "../../outside".into();
    assert!(invalid.validate(&options).is_err());
    let mut invalid = valid.clone();
    invalid.mode = "shell".into();
    assert!(invalid.validate(&options).is_err());
    let mut invalid = valid.clone();
    invalid.node_id = "other".into();
    assert!(invalid.validate(&options).is_err());
    let mut invalid = valid.clone();
    invalid.memory_mb = 2048;
    assert!(invalid.validate(&options).is_err());
    let mut invalid = valid;
    invalid.inference_node_id = Some("ai".into());
    invalid.inference_model = Some("model".into());
    assert!(invalid.validate(&options).is_err());
}

#[test]
fn memory_sample_has_finite_capacity() {
    let (total, available) = memory().unwrap();
    assert!(total > 0);
    assert!(available <= total);
}

#[test]
fn memory_limit_counts_all_descendants_and_ignores_other_jobs() {
    let processes = std::collections::HashMap::from([
        (10, (1, 100)),
        (11, (10, 200)),
        (12, (11, 300)),
        (20, (1, 900)),
    ]);
    assert_eq!(tree_memory(10, &processes), 600);
    assert_eq!(tree_memory(20, &processes), 900);
    assert!(process_memory().unwrap().contains_key(&std::process::id()));
}

#[test]
fn supervisor_drop_stops_a_running_job_instead_of_detaching_it() {
    let mut command = Command::new("/bin/sleep");
    command.arg("30");
    crate::runner::prepare_process_group(&mut command);
    let child = command.spawn().unwrap();
    let pid = child.id();
    let log = tempfile::tempfile().unwrap();
    drop(Running {
        job: job(),
        child,
        _proxy: None,
        _capacity: crate::controller::LiveAdmission::Defer("fixture".into()),
        _log: log,
    });
    #[cfg(unix)]
    assert_eq!(unsafe { libc::kill(pid as libc::pid_t, 0) }, -1);
}

#[test]
fn revoked_execution_lease_kills_the_process_and_reports_failure() {
    use std::io::{BufRead, BufReader, Read, Write};
    let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
    let mut device = options().device;
    device.origin = format!("http://{}", listener.local_addr().unwrap());
    let server = std::thread::spawn(move || {
        for (path, response) in [("renew_cloud_work", "false"), ("finish_cloud_work", "true")] {
            let (mut stream, _) = listener.accept().unwrap();
            let mut reader = BufReader::new(stream.try_clone().unwrap());
            let mut length = 0;
            let mut headers = String::new();
            loop {
                let mut line = String::new();
                reader.read_line(&mut line).unwrap();
                if line == "\r\n" {
                    break;
                }
                assert!(!line.is_empty());
                if let Some(value) = line.to_lowercase().strip_prefix("content-length:") {
                    length = value.trim().parse().unwrap();
                }
                headers.push_str(&line);
            }
            assert!(headers.starts_with(&format!("POST /rest/v1/rpc/{path} ")));
            let mut body = vec![0; length];
            reader.read_exact(&mut body).unwrap();
            if path == "finish_cloud_work" {
                assert_eq!(
                    serde_json::from_slice::<Value>(&body).unwrap()["p_exit_code"],
                    -1
                );
            }
            write!(
                stream,
                "HTTP/1.1 200 OK\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{response}",
                response.len()
            )
            .unwrap();
        }
    });
    let mut command = Command::new("/bin/sleep");
    command.arg("30");
    crate::runner::prepare_process_group(&mut command);
    let child = command.spawn().unwrap();
    let pid = child.id();
    let run = Running {
        job: job(),
        child,
        _proxy: None,
        _capacity: crate::controller::LiveAdmission::Defer("fixture".into()),
        _log: tempfile::tempfile().unwrap(),
    };
    supervise(run, device, &AtomicBool::new(false));
    server.join().unwrap();
    #[cfg(unix)]
    assert_eq!(unsafe { libc::kill(pid as libc::pid_t, 0) }, -1);
}
