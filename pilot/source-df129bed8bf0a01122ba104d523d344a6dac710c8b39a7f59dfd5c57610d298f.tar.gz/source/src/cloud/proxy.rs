//! A job-scoped loopback API relays inference to an explicitly granted AI node.
use super::{client::Device, worker::Job};
use anyhow::{bail, Result};
use serde_json::{json, Value};
use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::sync::{
    atomic::{AtomicBool, AtomicUsize, Ordering},
    Arc,
};
use std::time::{Duration, Instant};

pub(super) struct JobProxy {
    stop: Arc<AtomicBool>,
    thread: Option<std::thread::JoinHandle<()>>,
    port: u16,
    token: String,
    model: String,
}
impl JobProxy {
    pub fn start(device: Device, job: Job) -> Result<Self> {
        let listener = TcpListener::bind("127.0.0.1:0")?;
        listener.set_nonblocking(true)?;
        let port = listener.local_addr()?.port();
        let stop = Arc::new(AtomicBool::new(false));
        let token = uuid::Uuid::new_v4().to_string();
        let model = job
            .inference_model
            .clone()
            .ok_or_else(|| anyhow::anyhow!("missing inference model"))?;
        let stopped = stop.clone();
        let key = token.clone();
        let thread = std::thread::spawn(move || {
            let active = Arc::new(AtomicUsize::new(0));
            let mut requests = Vec::new();
            while !stopped.load(Ordering::Acquire) {
                match listener.accept() {
                    Ok((mut stream, _)) => {
                        if active.load(Ordering::Acquire) >= 8 {
                            respond(&mut stream, 503, false, b"{\"error\":\"relay is busy\"}");
                            continue;
                        }
                        active.fetch_add(1, Ordering::AcqRel);
                        let device = device.clone();
                        let job = job.clone();
                        let key = key.clone();
                        let stopped = stopped.clone();
                        let active = active.clone();
                        requests.push(std::thread::spawn(move || {
                            let result = relay(&mut stream, &device, &job, &key, &stopped);
                            if result.is_err() {
                                respond(
                                    &mut stream,
                                    502,
                                    false,
                                    b"{\"error\":\"authorized inference is unavailable\"}",
                                );
                            }
                            active.fetch_sub(1, Ordering::AcqRel);
                        }));
                        requests.retain(|thread| !thread.is_finished());
                    }
                    Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => {
                        std::thread::sleep(Duration::from_millis(50))
                    }
                    Err(_) => break,
                }
            }
            for request in requests {
                let _ = request.join();
            }
        });
        Ok(Self {
            stop,
            thread: Some(thread),
            port,
            token,
            model,
        })
    }
    pub fn opencode_config(&self) -> String {
        json!({"enabled_providers":["gah-cloud"],"model":format!("gah-cloud/{}",self.model),
            "provider":{"gah-cloud":{"npm":"@ai-sdk/openai-compatible","name":"Shared inference",
                "options":{"baseURL":format!("http://127.0.0.1:{}/v1",self.port),"apiKey":self.token},
                "models":{self.model.clone():{"name":self.model}}}}}).to_string()
    }
}
impl Drop for JobProxy {
    fn drop(&mut self) {
        self.stop.store(true, Ordering::Release);
        if let Some(thread) = self.thread.take() {
            let _ = thread.join();
        }
    }
}

fn relay(
    stream: &mut TcpStream,
    device: &Device,
    job: &Job,
    key: &str,
    stop: &AtomicBool,
) -> Result<()> {
    stream.set_read_timeout(Some(Duration::from_secs(5)))?;
    stream.set_write_timeout(Some(Duration::from_secs(5)))?;
    let (path, body) = read_request(stream, key)?;
    let mut body: Value =
        serde_json::from_slice(&body).map_err(|_| anyhow::anyhow!("invalid inference JSON"))?;
    if body["model"].as_str() != job.inference_model.as_deref() {
        bail!("inference model is not authorized");
    }
    // Streaming is buffered at the cloud boundary, then returned as complete SSE.
    let streaming = body["stream"] == json!(true);
    if let Some(root) = body.as_object_mut() {
        root.remove("api_key");
        root.remove("base_url");
    }
    let mut args = job.args();
    args["p_request_key"] = json!(uuid::Uuid::new_v4().to_string());
    args["p_path"] = json!(path);
    args["p_body"] = body;
    let request = device.rpc("enqueue_cloud_inference", args)?;
    let deadline = Instant::now() + Duration::from_secs(110);
    while Instant::now() < deadline
        && !stop.load(Ordering::Acquire)
        && !crate::runner::shutdown_requested()
    {
        let result = device.rpc("poll_cloud_inference", json!({"p_request_id":request}))?;
        if !result.is_null() {
            let status = result["status"]
                .as_u64()
                .filter(|v| (100..=599).contains(v))
                .ok_or_else(|| anyhow::anyhow!("invalid inference status"))?
                as u16;
            let response = result["response"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("invalid inference response"))?;
            respond(
                stream,
                status,
                streaming && (200..300).contains(&status),
                response.as_bytes(),
            );
            return Ok(());
        }
        std::thread::sleep(Duration::from_millis(500));
    }
    bail!("inference request expired")
}

fn read_request(stream: &mut TcpStream, key: &str) -> Result<(String, Vec<u8>)> {
    let deadline = Instant::now() + Duration::from_secs(5);
    let mut buffer = Vec::new();
    let mut block = [0; 4096];
    let split = loop {
        let count = read_before(stream, &mut block, deadline)?;
        if count == 0 {
            bail!("incomplete request");
        }
        buffer.extend_from_slice(&block[..count]);
        if let Some(index) = buffer.windows(4).position(|v| v == b"\r\n\r\n") {
            if index > 16384 {
                bail!("headers too large");
            }
            break index;
        }
        if buffer.len() > 16384 {
            bail!("headers too large");
        }
    };
    let header = std::str::from_utf8(&buffer[..split])?;
    let mut lines = header.split("\r\n");
    let request: Vec<_> = lines.next().unwrap_or("").split_whitespace().collect();
    if request.len() != 3 || request[0] != "POST" {
        bail!("unsupported inference request");
    }
    let path = match request[1] {
        "/v1/chat/completions" => "chat/completions",
        "/v1/responses" => "responses",
        _ => bail!("unsupported inference path"),
    };
    let mut length = None;
    let mut authorized = false;
    for line in lines {
        let (name, value) = line
            .split_once(':')
            .ok_or_else(|| anyhow::anyhow!("invalid header"))?;
        if name.eq_ignore_ascii_case("authorization") {
            if authorized || value.trim() != format!("Bearer {key}") {
                bail!("unauthorized proxy request");
            }
            authorized = true;
        }
        if name.eq_ignore_ascii_case("content-length") {
            if length.is_some() {
                bail!("duplicate length");
            }
            length = Some(value.trim().parse::<usize>()?);
        }
        if name.eq_ignore_ascii_case("transfer-encoding") {
            bail!("chunked requests are unsupported");
        }
    }
    let length = length
        .filter(|v| *v <= 262144)
        .ok_or_else(|| anyhow::anyhow!("invalid request length"))?;
    if !authorized {
        bail!("unauthorized proxy request");
    }
    let mut body = buffer[split + 4..].to_vec();
    if body.len() > length {
        bail!("request contains extra bytes");
    }
    while body.len() < length {
        let count = read_before(
            stream,
            &mut block[..(length - body.len()).min(4096)],
            deadline,
        )?;
        if count == 0 {
            bail!("incomplete body");
        }
        body.extend_from_slice(&block[..count]);
    }
    Ok((path.into(), body))
}

// An idle timeout alone lets a client keep a shutdown waiting by dripping bytes.
fn read_before(stream: &mut TcpStream, buffer: &mut [u8], deadline: Instant) -> Result<usize> {
    let remaining = deadline
        .checked_duration_since(Instant::now())
        .filter(|time| !time.is_zero())
        .ok_or_else(|| anyhow::anyhow!("proxy request timed out"))?;
    stream.set_read_timeout(Some(remaining))?;
    Ok(stream.read(buffer)?)
}
fn respond(stream: &mut TcpStream, status: u16, streaming: bool, body: &[u8]) {
    let kind = if streaming {
        "text/event-stream"
    } else {
        "application/json"
    };
    let header=format!("HTTP/1.1 {status} Response\r\nContent-Type: {kind}\r\nContent-Length: {}\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n",body.len());
    let _ = stream.write_all(header.as_bytes());
    let _ = stream.write_all(body);
}

#[derive(Clone)]
pub(super) struct InferenceProvider {
    url: String,
    key: String,
    models: Vec<String>,
}
impl InferenceProvider {
    pub fn from_env(models: &[String]) -> Result<Option<Self>> {
        if models.is_empty() {
            return Ok(None);
        }
        let url = std::env::var("GAH_CLOUD_INFERENCE_URL")
            .map_err(|_| anyhow::anyhow!("missing owner inference endpoint"))?;
        let parsed = url::Url::parse(&url)
            .map_err(|_| anyhow::anyhow!("invalid owner inference endpoint"))?;
        if !(parsed.scheme() == "https"
            || parsed.scheme() == "http"
                && matches!(parsed.host_str(), Some("localhost" | "127.0.0.1" | "[::1]")))
            || !parsed.username().is_empty()
            || parsed.password().is_some()
            || parsed.query().is_some()
            || parsed.fragment().is_some()
        {
            bail!("owner inference endpoint must use HTTPS");
        }
        let key = std::env::var("GAH_CLOUD_INFERENCE_KEY")
            .map_err(|_| anyhow::anyhow!("missing owner inference credential"))?;
        if key.is_empty() || key.contains(['\r', '\n']) {
            bail!("invalid owner inference credential");
        }
        Ok(Some(Self {
            url: url.trim_end_matches('/').into(),
            key,
            models: models.to_vec(),
        }))
    }
    pub fn serve(&self, device: &Device, request: Value, stop: &AtomicBool) {
        let id = &request["id"];
        let claim = &request["claim_id"];
        let check = || {
            !stop.load(Ordering::Acquire)
                && device
                    .rpc(
                        "check_cloud_inference",
                        json!({"p_request_id":id,"p_claim_id":claim}),
                    )
                    .ok()
                    == Some(json!(true))
        };
        let model = request["body"]["model"].as_str().unwrap_or("");
        let path = request["path"].as_str().unwrap_or("");
        let result = if self.models.iter().any(|v| v == model)
            && ["chat/completions", "responses"].contains(&path)
        {
            crate::curl_http::cloud_provider_request(
                &format!("{}/{path}", self.url),
                &request["body"].to_string(),
                &self.key,
                check,
            )
            .ok()
        } else {
            None
        };
        let (status, response) = match result {
            Some(result)
                if (200..300).contains(&result.status)
                    && !String::from_utf8_lossy(&result.body).contains(&self.key) =>
            {
                (
                    result.status,
                    String::from_utf8_lossy(&result.body).into_owned(),
                )
            }
            _ => (502, "{\"error\":\"shared inference unavailable\"}".into()),
        };
        let _ = device.rpc(
            "finish_cloud_inference",
            json!({"p_request_id":id,"p_claim_id":claim,"p_status":status,"p_response":response}),
        );
    }
}

#[cfg(test)]
mod tests;
