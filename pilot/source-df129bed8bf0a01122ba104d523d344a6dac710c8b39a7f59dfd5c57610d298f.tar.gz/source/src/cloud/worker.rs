//! Outbound execution with live grants, bounded capacity, and at-most-once starts.
use super::client::Device;
use super::proxy::{InferenceProvider, JobProxy};
use anyhow::{bail, Result};
use serde::Deserialize;
use serde_json::{json, Value};
use std::process::{Child, Command, Stdio};
use std::sync::{
    atomic::{AtomicBool, Ordering},
    Arc,
};
use std::time::{Duration, Instant};

pub struct WorkerOptions {
    pub device: Device,
    pub config_path: Option<String>,
    pub profiles: Vec<String>,
    pub backend: String,
    pub max_concurrent: u32,
    pub memory_budget_mb: u32,
    pub reserve_memory_mb: u32,
    pub allow_inference_relay: bool,
    pub inference_models: Vec<String>,
    pub once: bool,
}

#[derive(Clone, Deserialize)]
pub(super) struct Job {
    pub workspace_id: String,
    pub work_id: String,
    pub node_id: String,
    pub profile: String,
    pub mode: String,
    pub target: u32,
    pub memory_mb: u32,
    pub claim_id: String,
    pub inference_node_id: Option<String>,
    pub inference_model: Option<String>,
}

struct Running {
    job: Job,
    child: Child,
    _proxy: Option<JobProxy>,
    _capacity: crate::controller::LiveAdmission,
    // Logs stay private on the compute node, never in the cloud directory.
    _log: std::fs::File,
}
struct WorkerPool {
    stop: Arc<AtomicBool>,
    compute: Vec<(u32, std::thread::JoinHandle<()>)>,
    inference: Vec<std::thread::JoinHandle<()>>,
}
impl Drop for WorkerPool {
    fn drop(&mut self) {
        self.stop.store(true, Ordering::Release);
        for (_, task) in self.compute.drain(..) {
            let _ = task.join();
        }
        for task in self.inference.drain(..) {
            let _ = task.join();
        }
    }
}
impl Drop for Running {
    fn drop(&mut self) {
        // Even a supervisor failure cannot detach an unauthorized process.
        if self.child.try_wait().ok().flatten().is_none() {
            crate::runner::kill_process_group(&mut self.child);
            let _ = self.child.wait();
        }
    }
}

impl Job {
    pub(super) fn args(&self) -> Value {
        json!({"p_work_id":self.work_id,"p_claim_id":self.claim_id})
    }
    fn validate(&self, options: &WorkerOptions) -> Result<()> {
        if self.workspace_id != options.device.workspace_id
            || self.node_id != options.device.node_id
            || !options.profiles.contains(&self.profile)
            || !["improve", "review"].contains(&self.mode.as_str())
            || self.target == 0
            || self.target > i32::MAX as u32
            || self.memory_mb < 64
            || self.memory_mb > options.memory_budget_mb
            || (self.inference_node_id.is_some() != self.inference_model.is_some())
            || self.inference_node_id.is_some()
                && (!options.allow_inference_relay || options.backend != "opencode")
        {
            bail!("claimed job does not match worker policy");
        }
        uuid::Uuid::parse_str(&self.work_id)
            .map_err(|_| anyhow::anyhow!("invalid work identifier"))?;
        uuid::Uuid::parse_str(&self.claim_id)
            .map_err(|_| anyhow::anyhow!("invalid claim identifier"))?;
        Ok(())
    }
}

/// The worker never retries denied cloud work through a local dispatch path.
pub fn run_worker(options: WorkerOptions) -> Result<()> {
    crate::runner::install_shutdown_handler()?;
    if ![
        "opencode",
        "codex",
        "claude",
        "openhands",
        "hermes",
        "vibe",
        "agy",
    ]
    .contains(&options.backend.as_str())
        || options.max_concurrent == 0
        || options.max_concurrent > 32
        || options.memory_budget_mb < 64
    {
        bail!("invalid worker policy");
    }
    if options.allow_inference_relay && options.backend != "opencode" {
        bail!("remote inference currently requires the opencode backend");
    }
    let cfg = crate::config::load(options.config_path.as_deref())?;
    for profile in &options.profiles {
        crate::config::get_profile(&cfg, profile)?;
    }
    let config_path = crate::config::resolve_config_path(options.config_path.as_deref());
    let provider = InferenceProvider::from_env(&options.inference_models)?;
    let mut pool = WorkerPool {
        stop: Arc::new(AtomicBool::new(false)),
        compute: Vec::new(),
        inference: Vec::new(),
    };
    let mut polled = false;
    let mut checked = Instant::now() - Duration::from_secs(5);
    loop {
        let shutdown = crate::runner::shutdown_requested();
        if checked.elapsed() >= Duration::from_secs(5) || shutdown {
            pool.compute.retain(|(_, task)| !task.is_finished());
            pool.inference.retain(|task| !task.is_finished());
            if !shutdown && (!options.once || !polled) {
                if options
                    .device
                    .rpc("heartbeat_cloud_device", json!({}))
                    .is_err()
                {
                    if options.once {
                        bail!("cloud heartbeat denied or unavailable");
                    }
                    eprintln!("gah cloud: heartbeat denied or unavailable; no new work accepted");
                } else {
                    let pressure = pressure()?;
                    let active_mb: u32 = pool.compute.iter().map(|(memory, _)| memory).sum();
                    let mut available = (pressure.memory_available_bytes / (1024 * 1024))
                        .min(u64::from(u32::MAX)) as u32;
                    available = available
                        .saturating_sub(options.reserve_memory_mb)
                        .min(options.memory_budget_mb.saturating_sub(active_mb));
                    if pool.compute.len() < options.max_concurrent as usize
                        && !options.profiles.is_empty()
                    {
                        if let Ok(value)=options.device.rpc("claim_cloud_work",json!({"p_available_memory_mb":available,
                            "p_profiles":options.profiles,"p_allow_inference":options.allow_inference_relay})) {
                            if !value.is_null() {
                                let job:Job=serde_json::from_value(value).map_err(|_| anyhow::anyhow!("invalid claimed job"))?;
                                match start(&options, &config_path, job.clone(), pressure) {
                                    Ok(Some(run)) => {
                                        let device = options.device.clone(); let stop = pool.stop.clone();
                                        pool.compute.push((run.job.memory_mb, std::thread::spawn(move || supervise(run, device, &stop))));
                                    },
                                    Ok(None) => { let _=options.device.rpc("release_cloud_work", job.args()); },
                                    Err(_) => {
                                        let mut args=job.args();args["p_exit_code"]=json!(-1);let _=options.device.rpc("finish_cloud_work",args);
                                        eprintln!("gah cloud: claimed work was not launched; worker policy or setup failed");
                                    }
                                }
                            }
                        }
                    }
                    if let Some(provider) = &provider {
                        if pool.inference.len() < options.max_concurrent as usize {
                            if let Ok(request) =
                                options.device.rpc("claim_cloud_inference", json!({}))
                            {
                                if !request.is_null() {
                                    let provider = provider.clone();
                                    let device = options.device.clone();
                                    let stop = pool.stop.clone();
                                    pool.inference.push(std::thread::spawn(move || {
                                        provider.serve(&device, request, &stop)
                                    }));
                                }
                            }
                        }
                    }
                }
                polled = true;
            }
            checked = Instant::now();
        }
        if (shutdown || options.once && polled)
            && pool.compute.is_empty()
            && pool.inference.iter().all(|t| t.is_finished())
        {
            break;
        }
        std::thread::sleep(Duration::from_millis(100));
    }
    Ok(())
}

// Every job has its own bounded checks. A slow RPC for one job cannot keep
// another job executing past its authorization lease.
fn supervise(mut run: Running, device: Device, stop: &AtomicBool) {
    let mut checked = Instant::now() - Duration::from_secs(5);
    loop {
        if stop.load(Ordering::Acquire) || crate::runner::shutdown_requested() {
            break;
        }
        match run.child.try_wait() {
            Ok(Some(exit)) => {
                let mut args = run.job.args();
                args["p_exit_code"] = json!(exit.code().unwrap_or(-1));
                let _ = device.rpc("finish_cloud_work", args);
                return;
            }
            Ok(None) => {}
            Err(_) => break,
        }
        if checked.elapsed() >= Duration::from_secs(5) {
            let within_memory = process_memory().ok().is_some_and(|memory| {
                tree_memory(run.child.id(), &memory) <= u64::from(run.job.memory_mb) * 1024
            });
            if !within_memory
                || device.rpc("renew_cloud_work", run.job.args()).ok() != Some(json!(true))
            {
                break;
            }
            checked = Instant::now();
        }
        std::thread::sleep(Duration::from_millis(100));
    }
    crate::runner::kill_process_group(&mut run.child);
    let _ = run.child.wait();
    let mut args = run.job.args();
    args["p_exit_code"] = json!(-1);
    let _ = device.rpc("finish_cloud_work", args);
    eprintln!("gah cloud: stopped a job after cancellation, lost access, memory pressure, or cloud unavailability");
}

fn start(
    options: &WorkerOptions,
    config: &std::path::Path,
    job: Job,
    pressure: crate::controller::NodePressure,
) -> Result<Option<Running>> {
    job.validate(options)?;
    let capacity = crate::controller::acquire_cloud(job.memory_mb, pressure)?;
    if matches!(capacity, crate::controller::LiveAdmission::Defer(_)) {
        return Ok(None);
    }
    let proxy = if job.inference_node_id.is_some() {
        Some(JobProxy::start(options.device.clone(), job.clone())?)
    } else {
        None
    };
    let logs = crate::config::default_config_dir().join("cloud-logs");
    std::fs::create_dir_all(&logs)?;
    let mut file_options = std::fs::OpenOptions::new();
    file_options.create_new(true).write(true);
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        file_options.mode(0o600).custom_flags(libc::O_NOFOLLOW);
    }
    let log = file_options.open(logs.join(format!("{}.log", job.work_id)))?;
    let mut command = dispatch_command(&job, &options.backend, config)?;
    command
        .stdin(Stdio::null())
        .stdout(log.try_clone()?)
        .stderr(log.try_clone()?);
    // Only local runtime and provider credentials are inherited. Cloud device,
    // session, and service credentials never enter a dispatch environment.
    for (key, _) in std::env::vars() {
        if key.starts_with("GAH_SUPABASE_") || key.starts_with("GAH_CLOUD_") {
            command.env_remove(key);
        }
    }
    command.env("GAH_ORCHESTRATION_MODE", "local");
    if let Some(proxy) = &proxy {
        command.arg("--model").arg(format!(
            "gah-cloud/{}",
            job.inference_model.as_deref().unwrap()
        ));
        command.env("GAH_CLOUD_RELAY_CONFIG", proxy.opencode_config());
    }
    crate::runner::prepare_process_group(&mut command);
    crate::runner::process::arm_child_pdeathsig(&mut command);
    let mut args = job.args();
    args["p_start"] = json!(true);
    if options.device.rpc("renew_cloud_work", args)? != json!(true) {
        bail!("work access denied before launch");
    }
    let child = command
        .spawn()
        .map_err(|_| anyhow::anyhow!("cloud dispatch could not launch"))?;
    Ok(Some(Running {
        job,
        child,
        _proxy: proxy,
        _capacity: capacity,
        _log: log,
    }))
}

/// Build the same CLI invocation accepted by the local dispatcher.
fn dispatch_command(job: &Job, backend: &str, config: &std::path::Path) -> Result<Command> {
    let mut command = Command::new(std::env::current_exe()?);
    command
        .args([
            "dispatch",
            "--profile",
            &job.profile,
            "--mode",
            &job.mode,
            "--target",
            &job.target.to_string(),
            "--backend",
            backend,
            "--config-path",
        ])
        .arg(config);
    Ok(command)
}

fn pressure() -> Result<crate::controller::NodePressure> {
    let (total, available) = memory()?;
    Ok(crate::controller::NodePressure {
        memory_total_bytes: total,
        memory_available_bytes: available,
        logical_cpus: std::thread::available_parallelism()
            .map(usize::from)
            .unwrap_or(1),
        load_one: 0.0,
        memory_full_psi_avg10: None,
        cpu_some_psi_avg10: None,
    })
}
fn memory() -> Result<(u64, u64)> {
    #[cfg(target_os = "linux")]
    {
        let contents = std::fs::read_to_string("/proc/meminfo")?;
        let read = |key: &str| -> Result<u64> {
            contents
                .lines()
                .find_map(|line| {
                    line.strip_prefix(key)?
                        .split_whitespace()
                        .next()?
                        .parse::<u64>()
                        .ok()
                })
                .map(|value| value * 1024)
                .ok_or_else(|| anyhow::anyhow!("cannot sample node memory"))
        };
        Ok((read("MemTotal:")?, read("MemAvailable:")?))
    }
    #[cfg(target_os = "macos")]
    {
        let total = Command::new("/usr/sbin/sysctl")
            .args(["-n", "hw.memsize"])
            .output()?;
        let total = std::str::from_utf8(&total.stdout)?.trim().parse()?;
        let stats = Command::new("/usr/bin/vm_stat").output()?;
        let stats = std::str::from_utf8(&stats.stdout)?;
        let page_size = stats
            .lines()
            .next()
            .and_then(|line| line.split("page size of ").nth(1))
            .and_then(|v| v.split_whitespace().next())
            .and_then(|v| v.parse::<u64>().ok())
            .ok_or_else(|| anyhow::anyhow!("cannot sample node memory"))?;
        let mut pages = 0;
        for line in stats.lines() {
            if ["Pages free:", "Pages inactive:", "Pages speculative:"]
                .iter()
                .any(|key| line.starts_with(key))
            {
                pages += line
                    .split(':')
                    .nth(1)
                    .unwrap_or("")
                    .trim()
                    .trim_end_matches('.')
                    .parse::<u64>()?;
            }
        }
        Ok((total, pages * page_size))
    }
    #[cfg(not(any(target_os = "linux", target_os = "macos")))]
    bail!("cloud worker memory sampling is unsupported on this platform")
}

// A five-second RSS threshold applies to the whole descendant tree.
// This is a stop threshold, not an operating-system sandbox.
fn process_memory() -> Result<std::collections::HashMap<u32, (u32, u64)>> {
    let output = Command::new("ps")
        .args(["-axo", "pid=,ppid=,rss="])
        .output()?;
    if !output.status.success() {
        bail!("cannot sample process memory");
    }
    let mut memory = std::collections::HashMap::new();
    for line in std::str::from_utf8(&output.stdout)?.lines() {
        let fields: Vec<_> = line.split_whitespace().collect();
        if fields.len() != 3 {
            bail!("invalid process memory sample");
        }
        memory.insert(fields[0].parse()?, (fields[1].parse()?, fields[2].parse()?));
    }
    Ok(memory)
}
fn tree_memory(root: u32, memory: &std::collections::HashMap<u32, (u32, u64)>) -> u64 {
    let mut total = 0;
    for (&pid, &(_, rss)) in memory {
        let mut ancestor = pid;
        for _ in 0..memory.len() {
            if ancestor == root {
                total += rss;
                break;
            }
            let Some(&(parent, _)) = memory.get(&ancestor) else {
                break;
            };
            if parent == ancestor {
                break;
            }
            ancestor = parent;
        }
    }
    total
}

#[cfg(test)]
mod tests;
