use super::SyncMr;
use crate::job_kind::JobKind;
use crate::ledger::{LedgerEntriesByWorkId, LedgerEntry};
use sha2::{Digest, Sha256};

/// Stable identity of the provider metadata a reviewer actually inspected.
/// Length-prefixing avoids ambiguous concatenation; the versioned prefix
/// permits canonicalization changes without treating old identities as equal.
pub(crate) fn review_metadata_fingerprint(
    source_sha: Option<&str>,
    title: Option<&str>,
    body: Option<&str>,
    draft: bool,
) -> String {
    let mut hasher = Sha256::new();
    hasher.update(b"gah-review-metadata-v1\0");
    // GAH creates GitLab MRs with this exact marker and `--ready` removes it.
    // Draft state is hashed separately, so the marker is not title content.
    let title = title
        .and_then(|value| value.strip_prefix("Draft: "))
        .or(title);
    for value in [
        source_sha.unwrap_or(""),
        title.unwrap_or(""),
        body.unwrap_or(""),
    ] {
        hasher.update((value.len() as u64).to_be_bytes());
        hasher.update(value.as_bytes());
    }
    hasher.update([u8::from(draft)]);
    format!("sha256:{:x}", hasher.finalize())
}

impl SyncMr {
    pub(super) fn review_metadata_fingerprint(&self) -> String {
        review_metadata_fingerprint(
            self.source_sha.as_deref(),
            Some(&self.title),
            self.body.as_deref(),
            self.draft,
        )
    }
}

pub(super) fn latest_review_for_mr<'a>(
    ledger: &'a LedgerEntriesByWorkId,
    mr: &SyncMr,
) -> Option<&'a LedgerEntry> {
    let entries = ledger.get(mr.work_id.as_ref()?)?;
    entries.iter().rev().find(|entry| {
        entry.branch.as_deref() == Some(mr.branch.as_str())
            && matches!(
                entry
                    .review_verdict
                    .as_deref()
                    .or(entry.validation_result.as_deref()),
                Some("APPROVE" | "NEEDS_FIX" | "REJECT" | "HUMAN_REVIEW" | "REVIEW_OUTPUT_INVALID")
            )
    })
}

pub(super) fn review_metadata_matches(latest: &LedgerEntry, mr: &SyncMr) -> bool {
    let recorded = latest.review_metadata_fingerprint.as_deref();
    if recorded == Some(mr.review_metadata_fingerprint().as_str()) {
        return true;
    }
    // Accept only GAH's one-way draft-to-ready lifecycle transition;
    // re-drafting still invalidates the review.
    !mr.draft
        && recorded
            == Some(
                review_metadata_fingerprint(
                    mr.source_sha.as_deref(),
                    Some(&mr.title),
                    mr.body.as_deref(),
                    true,
                )
                .as_str(),
            )
}

pub(crate) fn current_review_generation(mr: &SyncMr) -> Option<String> {
    let fingerprint = mr.review_metadata_fingerprint();
    crate::ledger::review_generation(mr.source_sha.as_deref(), Some(&fingerprint))
}

/// Generation-match check shared by every merge/dispatch caller. A stored
/// `generation` matches the live MR either exactly, or via GAH's one-way
/// draft-to-ready transition (`mark_ready_for_review` flips `draft` after the
/// review that approved it ran) — re-drafting still invalidates the review.
pub(crate) fn review_generation_matches(
    generation: &str,
    source_sha: Option<&str>,
    title: Option<&str>,
    body: Option<&str>,
    draft: bool,
) -> bool {
    let live_fingerprint = review_metadata_fingerprint(source_sha, title, body, draft);
    crate::ledger::review_generation(source_sha, Some(&live_fingerprint)).as_deref()
        == Some(generation)
        || (!draft
            && crate::ledger::review_generation(
                source_sha,
                Some(&review_metadata_fingerprint(source_sha, title, body, true)),
            )
            .as_deref()
                == Some(generation))
}

pub(crate) fn review_generation_matches_mr(generation: &str, mr: &SyncMr) -> bool {
    review_generation_matches(
        generation,
        mr.source_sha.as_deref(),
        Some(&mr.title),
        mr.body.as_deref(),
        mr.draft,
    )
}

pub(crate) fn review_contract_matches(latest: &LedgerEntry, mr: &SyncMr) -> bool {
    latest.review_contract_version == Some(crate::ledger::REVIEW_CONTRACT_VERSION)
        && latest.review_generation
            == crate::ledger::review_generation(
                latest.review_source_sha.as_deref(),
                latest.review_metadata_fingerprint.as_deref(),
            )
        && latest.review_generation.is_some()
        && review_metadata_matches(latest, mr)
        && latest
            .review_generation
            .as_deref()
            .is_some_and(|generation| review_generation_matches_mr(generation, mr))
}

/// Return implementation attribution independently from the latest review.
/// A metadata-only re-review appends a review without a new implementation.
pub(super) fn ledger_info_for_mr(
    ledger: &LedgerEntriesByWorkId,
    mr: &SyncMr,
) -> (
    Option<String>,
    Option<String>,
    Option<String>,
    Option<String>,
) {
    let Some(entries) = mr.work_id.as_ref().and_then(|id| ledger.get(id)) else {
        return (None, None, None, None);
    };
    let implementation = entries
        .iter()
        .rev()
        .find(|entry| {
            matches!(
                JobKind::parse(&entry.mode),
                Ok(JobKind::Fix) | Ok(JobKind::Improve)
            ) && entry.mr_url.as_deref() == mr.url.as_deref()
                && !entry.effective_backend.is_empty()
        })
        .or_else(|| {
            entries.iter().rev().find(|entry| {
                matches!(
                    JobKind::parse(&entry.mode),
                    Ok(JobKind::Fix) | Ok(JobKind::Improve)
                ) && entry.branch.as_deref() == Some(mr.branch.as_str())
                    && !entry.effective_backend.is_empty()
            })
        });
    let review = entries.iter().rev().find(|entry| {
        entry.branch.as_deref() == Some(mr.branch.as_str()) && entry.review_verdict.is_some()
    });
    (
        implementation.map(|entry| entry.effective_backend.clone()),
        implementation.and_then(|entry| entry.effective_model.clone()),
        review.and_then(|entry| entry.review_verdict.clone()),
        review.and_then(|entry| entry.review_gate_reason.clone()),
    )
}
