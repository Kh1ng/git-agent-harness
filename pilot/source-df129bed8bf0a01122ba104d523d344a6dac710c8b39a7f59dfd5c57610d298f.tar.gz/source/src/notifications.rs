//! Native notification hooks for `gah loop` / `gah dispatch`.
//!
//! Issue #84: an operator should not need a separate manager agent or an
//! external wrapper script to learn that GAH needs them. When a profile sets
//! `notify_command`, GAH pipes a single one-line message to that command's
//! stdin (shell-executed, exactly like `validation_commands`) on a small set
//! of high-signal controller/dispatch events:
//!
//!   * `HumanRequired` decided (reason + reference)
//!   * MR/PR created (url, work_id, backend/model)
//!   * Review verdict recorded (verdict + MR url)
//!   * Dispatch failed terminally (failure_class + work_id)
//!
//! Routine events (observation, wait, no-op) deliberately emit no
//! notification, to avoid spam. A failing or missing `notify_command` is
//! logged to stderr and swallowed -- it must never fail the dispatch/loop.
//!
//! The message-formatting logic is separated from shell execution so it can be
//! unit-tested without spawning a shell (see tests at the bottom of this file).
//!
//! Manager wake (operator ask, 2026-07-10): a Telegram ping alone still
//! requires a human to notice it and go start/resume a manager agent
//! session. When a profile explicitly opts in via `manager_wake_autonomy`
//! and `Defaults::current_manager` names a known agent CLI, GAH
//! additionally queues an instruction on that profile's durable manager
//! session -- so the next actionable
//! event (MR ready, human required, etc.) can get picked up without the
//! operator being the one to trigger it. `WakeAutonomy::Full` (unsupervised
//! merge authority) requires the operator to explicitly opt a specific
//! profile in -- it is never the default for a newly-added profile, and a
//! profile with no `manager_wake_autonomy` set behaves exactly as before
//! this feature existed.

use crate::config::{GahConfig, Profile, WakeAutonomy};
use crate::events;
use anyhow::Context;
use serde_json::json;
use sha2::{Digest, Sha256};
use std::collections::HashMap;
use std::sync::{Mutex, OnceLock};
use time::format_description::well_known::Rfc3339;
use time::OffsetDateTime;

type TerminalFailureCacheKey = (String, String, String);
type TerminalFailureCache = HashMap<TerminalFailureCacheKey, Option<TerminalFailureRecord>>;

const NOTIFICATION_ERROR_SUMMARY_MAX_BYTES: usize = 300;
const TERMINAL_FAILURE_EVENT_DEDUPE_SECONDS: i64 = 900;
const TERMINAL_FAILURE_EVENT_DEDUPE_SECONDS_ENV: &str = "GAH_TERMINAL_FAILURE_DEDUPE_SECONDS";

/// A notification-worthy controller/dispatch event. All fields are borrowed
/// from the live dispatch/controller state to avoid cloning.
pub enum NotifyEvent<'a> {
    /// A controller action was decided as `HumanRequired`.
    HumanRequired {
        reason: &'a str,
        reference: Option<&'a str>,
        /// TICKET-505: stable reason code for why autonomy stopped.
        reason_code: Option<&'a str>,
        failure_class: &'a str,
        failure_stage: Option<&'a str>,
        error_summary: Option<&'a str>,
        attempt_count: Option<u32>,
        mr_url: Option<&'a str>,
    },
    /// A candidate was skipped until an operator approves its paid route.
    PaidRouteApprovalRequired {
        profile: &'a str,
        work_id: &'a str,
        candidate: &'a crate::ledger::RoutingCandidateDiagnostic,
        alternative: Option<&'a crate::ledger::RoutingCandidateDiagnostic>,
    },
    /// Issue #653: a dispatch paused before backend launch because a declared
    /// external credential scope lacks an active grant for this work item.
    ExternalApprovalRequested {
        profile: &'a str,
        project: &'a str,
        work_id: &'a str,
        work_url: Option<&'a str>,
        credential_label: &'a str,
        env_vars: &'a str,
        bounds: &'a str,
        expires_at: &'a str,
        purpose: Option<&'a str>,
        grant_command: &'a str,
        deny_command: &'a str,
    },
    /// Issue #653: an external-approval request reached a terminal state.
    ExternalApprovalResolved {
        profile: &'a str,
        work_id: &'a str,
        credential_label: &'a str,
        state: &'a str,
    },
    /// A draft MR/PR was created/pushed.
    MrCreated {
        url: &'a str,
        work_id: &'a str,
        backend: &'a str,
        model: &'a str,
    },
    /// A review verdict was recorded.
    ReviewVerdict { verdict: &'a str, mr_url: &'a str },
    /// A reviewer completed but did not provide machine-safe repair context.
    /// This is an automatic reroute signal, not a terminal human request.
    ReviewOutputInvalid {
        mr_url: &'a str,
        backend: &'a str,
        model: &'a str,
        reason: &'a str,
    },
    /// TICKET-127: an MR/PR was auto-merged.
    MrMerged { url: &'a str, work_id: &'a str },
    /// A dispatch failed terminally (retries exhausted).
    DispatchFailed {
        timestamp: &'a str,
        profile: &'a str,
        failure_class: &'a str,
        failure_stage: Option<&'a str>,
        run_id: &'a str,
        work_id: &'a str,
        attempt_count: Option<u32>,
        error_summary: Option<&'a str>,
        mr_url: Option<&'a str>,
    },
    /// A terminal dispatch failure for the same `(profile, work_id)` was resolved
    /// by later merge/close/reconcile activity.
    DispatchFailureResolved {
        timestamp: &'a str,
        profile: &'a str,
        failure_class: &'a str,
        failure_stage: Option<&'a str>,
        work_id: &'a str,
        run_id: &'a str,
    },
    /// A backend was killed by GAH's idle watchdog. This is actionable even
    /// when the dispatch still has another route to try.
    BackendStalled {
        work_id: &'a str,
        backend: &'a str,
        model: &'a str,
        duration_seconds: f64,
    },
    /// A local operator handoff artifact was created (delivery_mode = handoff).
    HandoffCreated {
        ticket: &'a str,
        path: &'a str,
        summary: &'a str,
    },
}

/// Render a `backend`/`model` pair for a human-facing message. Some
/// backends (opencode) name their own models with the backend as a
/// namespace prefix already (e.g. `opencode/hy3-free`) -- naively
/// prepending `{backend}/` again produced `opencode/opencode/hy3-free`
/// (live-observed). Collapses to just `model` when it already starts with
/// `{backend}/`.
fn route_label(backend: &str, model: &str) -> String {
    if model.starts_with(&format!("{backend}/")) {
        model.to_string()
    } else {
        format!("{backend}/{model}")
    }
}

/// Render a `NotifyEvent` into the single-line message GAH pipes to
/// `notify_command`. Pure and allocation-light; unit-tested below.
pub fn format_message(event: &NotifyEvent) -> String {
    match event {
        NotifyEvent::HumanRequired {
            reason,
            reference,
            reason_code,
            failure_class,
            failure_stage,
            error_summary,
            attempt_count,
            mr_url,
        } => {
            let mut msg = format!(
                "[gah] human required: {reason} [class={failure_class}] [stage={}] [attempts={}]",
                failure_stage.unwrap_or("unknown"),
                format_attempt_count(*attempt_count),
            );
            if let Some(reference) = reference.or(*mr_url) {
                msg.push_str(&format!(" ({reference})"));
            }
            if let Some(code) = reason_code {
                msg.push_str(&format!(" [code={code}]"));
            }
            if let Some(summary) = summarize_error_summary(*error_summary) {
                msg.push_str(&format!(" summary={summary}"));
            }
            msg
        }
        NotifyEvent::PaidRouteApprovalRequired {
            profile,
            work_id,
            candidate,
            alternative,
        } => {
            let mut message = format!(
                "[gah] paid route approval required [profile={profile}] work_id={work_id} route={}; configured paid-route policy requires operator approval",
                route_label(&candidate.backend, candidate.model.as_deref().unwrap_or("default")),
            );
            if let Some(instance) = &candidate.backend_instance {
                message.push_str(&format!(" [instance={instance}]"));
            }
            if let Some(alternative) = alternative {
                message.push_str(&format!(
                    "; alternative {} expected to reset at {} (availability estimate)",
                    route_label(&alternative.backend, alternative.model.as_deref().unwrap_or("default")),
                    alternative.unavailable_until.as_deref().unwrap_or("unknown"),
                ));
                if let Some(instance) = &alternative.backend_instance {
                    message.push_str(&format!(" [alternative instance={instance}]"));
                }
            }
            message
        }
        NotifyEvent::ExternalApprovalRequested {
            profile,
            project,
            work_id,
            work_url,
            credential_label,
            env_vars,
            bounds,
            expires_at,
            purpose,
            grant_command,
            deny_command,
        } => {
            let mut msg = format!(
                "[gah] external API approval required [profile={profile}] [project={project}] work_id={work_id} credential={credential_label} env_vars=[{env_vars}] bounds={bounds} expiry={expires_at}",
            );
            if let Some(work_url) = work_url {
                msg.push_str(&format!(" link={work_url}"));
            }
            if let Some(purpose) = purpose {
                msg.push_str(&format!(" reason={purpose}"));
            }
            msg.push_str(&format!(
                " approve: {grant_command} deny: {deny_command} dashboard: Work > External API approvals"
            ));
            msg
        }
        NotifyEvent::ExternalApprovalResolved {
            profile,
            work_id,
            credential_label,
            state,
        } => {
            format!(
                "[gah] external approval {state} [profile={profile}] work_id={work_id} credential={credential_label}"
            )
        }
        NotifyEvent::MrCreated {
            url,
            work_id,
            backend,
            model,
        } => {
            format!(
                "[gah] MR created {url} (work_id={work_id}, {})",
                route_label(backend, model)
            )
        }
        NotifyEvent::ReviewVerdict { verdict, mr_url } => {
            format!("[gah] review {verdict} on {mr_url}")
        }
        NotifyEvent::ReviewOutputInvalid {
            mr_url,
            backend,
            model,
            reason,
        } => format!(
            "[gah] review output invalid on {mr_url} route={} summary={}; rerouting",
            route_label(backend, model),
            summarize_error_summary(Some(reason))
                .unwrap_or_else(|| "invalid structured review output".to_string())
        ),
        NotifyEvent::MrMerged { url, work_id } => {
            format!("[gah] auto-merged {url} (work_id={work_id})")
        }
        NotifyEvent::DispatchFailed {
            timestamp,
            profile,
            failure_class,
            failure_stage,
            run_id,
            work_id,
            attempt_count,
            error_summary,
            mr_url,
            ..
        } => {
            let mut msg = format!(
                "[gah] dispatch terminal failure [ts={timestamp}] [profile={profile}] [class={failure_class}] [stage={}] [run_id={run_id}] [attempts={}] work_id={work_id}",
                failure_stage.unwrap_or("unknown"),
                format_attempt_count(*attempt_count),
            );
            if let Some(mr_url) = mr_url {
                msg.push_str(&format!(" ref={mr_url}"));
            }
            if *failure_class == "human_blocked" && failure_stage == &Some("route") {
                msg.push_str(" [state=paused_non_spending]");
            }
            if let Some(summary) = summarize_error_summary(*error_summary) {
                msg.push_str(&format!(" summary={summary}"));
            }
            msg
        }
        NotifyEvent::DispatchFailureResolved {
            timestamp,
            profile,
            failure_class,
            failure_stage,
            work_id,
            run_id,
        } => format!(
            "[gah] terminal failure resolved [ts={timestamp}] [profile={profile}] [class={failure_class}] [stage={}] [run_id={run_id}] work_id={work_id}",
            failure_stage.unwrap_or("unknown"),
        ),
        NotifyEvent::BackendStalled {
            work_id,
            backend,
            model,
            duration_seconds,
            ..
        } => format!(
            "[gah] backend stalled work_id={work_id} route={} duration={duration_seconds:.0}s; rerouting",
            route_label(backend, model)
        ),
        NotifyEvent::HandoffCreated {
            ticket,
            path,
            summary,
        } => {
            if let Some(short_summary) = summarize_error_summary(Some(summary)) {
                format!("[gah] handoff ready for {ticket} at {path}: {short_summary}")
            } else {
                format!("[gah] handoff ready for {ticket} at {path}")
            }
        }
    }
}

/// Execute `command` via `sh -c`, piping `message` (plus a trailing newline)
/// to its stdin. Any failure (missing executable, non-zero exit, spawn error)
/// is returned so the caller can swallow it -- this function never aborts the
/// surrounding dispatch/loop on its own.
fn run_notify_command(command: &str, message: &str) -> std::io::Result<()> {
    use std::io::Write;
    use std::process::{Command, Stdio};

    let mut child = Command::new("sh")
        .args(["-c", command])
        .stdin(Stdio::piped())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()?;
    // Write the one-line message to stdin. A broken pipe here just means the
    // command exited before reading; treat it as non-fatal.
    if let Some(mut stdin) = child.stdin.take() {
        let _ = stdin.write_all(message.as_bytes());
        let _ = stdin.write_all(b"\n");
    }
    let status = child.wait()?;
    if status.success() {
        Ok(())
    } else {
        Err(std::io::Error::other(format!(
            "notify command exited with status: {status}"
        )))
    }
}

/// Build the instruction text for a woken manager agent, given the same
/// event that drove `format_message` and the profile's configured
/// autonomy. `None` means no wake should happen: autonomy is `Off`, or the
/// event has nothing left to act on (e.g. `MrMerged` already resolved
/// itself, there's no decision left to make).
pub fn format_wake_instruction(event: &NotifyEvent, autonomy: WakeAutonomy) -> Option<String> {
    let action = match autonomy {
        WakeAutonomy::Off => return None,
        WakeAutonomy::Full => {
            "Review this yourself against this repo's standing manager authorization (see CLAUDE.md / manager memory). If it's a PR ready to merge, review the diff and merge it if CI is green and review passed. If it's a failure or a block, investigate and fix or escalate. Stay scoped to this profile/repo only -- no destructive git operations, no unrelated scope creep. Report a one-line outcome at the end."
        }
        WakeAutonomy::ReviewOnly => {
            "Review this and post your findings as a comment on the relevant PR/issue. Do not merge or take any other write action -- a human will act on your review."
        }
    };

    let context = match event {
        NotifyEvent::MrCreated {
            url,
            work_id,
            backend,
            model,
        } => format!(
            "A draft PR/MR is ready: {url} (work_id={work_id}, dispatched via {}).",
            route_label(backend, model)
        ),
        NotifyEvent::HumanRequired {
            reason,
            reference,
            reason_code,
            failure_class,
            failure_stage,
            error_summary,
            attempt_count,
            mr_url,
        } => {
            let mut context = format!(
                "gah loop is blocked and needs judgment: [class={failure_class}] [stage={}] [attempts={}] {reason}.",
                failure_stage.unwrap_or("unknown"),
                format_attempt_count(*attempt_count),
            );
            if let Some(code) = reason_code {
                context.push_str(&format!(" [code={code}]"));
            }
            if let Some(reference) = reference.or(*mr_url) {
                context.push_str(&format!(" Reference: {reference}."));
            }
            if let Some(summary) = summarize_error_summary(*error_summary) {
                context.push_str(&format!(" summary={summary}"));
            }
            context
        }
        NotifyEvent::ReviewVerdict { verdict, mr_url } => {
            format!("A review verdict was recorded: {verdict} on {mr_url}.")
        }
        // The controller owns this bounded reroute. Waking a manager for each
        // malformed intermediate opinion would recreate the notification
        // spam this event is designed to explain.
        NotifyEvent::ReviewOutputInvalid { .. } | NotifyEvent::PaidRouteApprovalRequired { .. } => {
            return None
        }
        // Issue #653: external approvals are operator decisions; a woken
        // manager must never grant its own credentials.
        NotifyEvent::ExternalApprovalRequested { .. } => return None,
        NotifyEvent::ExternalApprovalResolved { .. } => return None,
        NotifyEvent::DispatchFailed {
            failure_class,
            failure_stage,
            work_id,
            attempt_count,
            error_summary,
            mr_url,
            ..
        } => {
            let mut context = format!(
                "A dispatch failed terminally: [class={failure_class}] [stage={}] [attempts={}] work_id={work_id}.",
                failure_stage.unwrap_or("unknown"),
                format_attempt_count(*attempt_count),
            );
            if *failure_class == "human_blocked" && failure_stage == &Some("route") {
                context.push_str(" [state=paused_non_spending]");
            }
            if let Some(mr_url) = mr_url {
                context.push_str(&format!(" ref={mr_url}"));
            }
            if let Some(summary) = summarize_error_summary(*error_summary) {
                context.push_str(&format!(" summary={summary}"));
            }
            context
        }
        NotifyEvent::DispatchFailureResolved { .. } => return None,
        NotifyEvent::BackendStalled {
            work_id,
            backend,
            model,
            duration_seconds,
        } => format!(
            "Backend stalled for work_id={work_id} on {} after {duration_seconds:.0}s; GAH is rerouting.",
            route_label(backend, model)
        ),
        // Already resolved -- nothing for a woken agent to act on.
        NotifyEvent::MrMerged { .. } => return None,
        NotifyEvent::HandoffCreated { .. } => return None,
    };

    Some(format!("[gah manager wake] {context} {action}"))
}

/// Enqueue `instruction` onto the control-plane server's durable project
/// chat (issue #819), replacing the old one-shot `spawn_manager_wake` that
/// spawned a competing process on every wake. Delivery is a bounded local or
/// central HTTP request; failures are swallowed so they never fail dispatch.
///
/// The instruction is still recorded to a timestamped file under `log_dir`
/// (see `Defaults::manager_wake_log_dir`) before dispatch, regardless of
/// whether the server accepts the wake -- preserving this
/// file's whole reason for existing (see the incident noted below): a wake
/// must never again be unobservable.
///
/// Live-hit (2026-07): the first real wake (autonomy Full) ran completely
/// unobserved -- stdout/stderr both went to `/dev/null`, so there was no way
/// to see what an unsupervised headless agent instance actually did or why
/// it might be making network connections, right when an operator was
/// specifically asking about unexpected outbound traffic.
fn wake_manager_session_with<F>(
    manager: &str,
    display_name: &str,
    repo_id: &str,
    instruction: &str,
    log_dir: &std::path::Path,
    enqueue: F,
) where
    F: FnOnce(&str, &str, &str, &std::path::Path) -> anyhow::Result<()>,
{
    use std::io::Write;

    if let Err(err) = std::fs::create_dir_all(log_dir) {
        eprintln!("[gah] manager_wake: failed to create log dir (swallowed): {err:#}");
    }
    let ts = time::OffsetDateTime::now_utc().unix_timestamp();
    let log_path = log_dir.join(format!(
        "{ts}-{}-{}.log",
        std::process::id(),
        uuid::Uuid::new_v4()
    ));
    let mut options = std::fs::OpenOptions::new();
    options.write(true).create_new(true);
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        options.mode(0o600);
    }
    let audit = options.open(&log_path).and_then(|mut file| {
        writeln!(
            file,
            "manager: {manager}\nrepo_id: {repo_id}\ndisplay_name: {display_name}\ninstruction: {instruction}"
        )
    });
    if let Err(err) = audit {
        eprintln!(
            "[gah] manager_wake: failed to write audit log {} (swallowed): {err:#}",
            log_path.display()
        );
    }

    if let Err(err) = enqueue(manager, repo_id, instruction, &log_path) {
        eprintln!("[gah] manager_wake failed (swallowed): {err:#}");
    }
}

fn manager_wake_url(central_url: &str) -> anyhow::Result<String> {
    let mut url = url::Url::parse(central_url).context("parsing registry_central_url")?;
    url.set_path(&format!(
        "{}/api/manager-chat/wake",
        url.path().trim_end_matches('/')
    ));
    url.set_query(None);
    Ok(url.to_string())
}

fn activity_url(central_url: &str) -> anyhow::Result<String> {
    let mut url = url::Url::parse(central_url).context("parsing registry_central_url")?;
    url.set_path(&format!(
        "{}/api/activity",
        url.path().trim_end_matches('/')
    ));
    url.set_query(None);
    Ok(url.to_string())
}

fn activity_shape(event: &NotifyEvent<'_>) -> (&'static str, &'static str, &'static str) {
    match event {
        NotifyEvent::DispatchFailed { .. } => ("dispatch_failed", "error", "Work failed"),
        NotifyEvent::MrCreated { .. } | NotifyEvent::HandoffCreated { .. } => {
            ("review_ready", "success", "Review ready")
        }
        NotifyEvent::ReviewVerdict { .. } => ("review_ready", "info", "Review updated"),
        NotifyEvent::MrMerged { .. }
        | NotifyEvent::DispatchFailureResolved { .. }
        | NotifyEvent::ExternalApprovalResolved { .. } => {
            ("dispatch_completed", "success", "Work updated")
        }
        NotifyEvent::HumanRequired { .. }
        | NotifyEvent::PaidRouteApprovalRequired { .. }
        | NotifyEvent::ExternalApprovalRequested { .. }
        | NotifyEvent::ReviewOutputInvalid { .. }
        | NotifyEvent::BackendStalled { .. } => {
            ("action_required", "warning", "Operator action required")
        }
    }
}

fn activity_body(profile: &Profile, event: &NotifyEvent<'_>) -> (String, String) {
    let profile_name = event_profile(event).unwrap_or(profile.display_name.as_str());
    let message = crate::redact::redact(&format_message(event));
    let message = crate::dispatch::utf8_safe_prefix(&message, 1_000).to_string();
    let (kind, severity, title) = activity_shape(event);
    let id_seed = json!({
        "event": event_name(event),
        "profile": profile_name,
        "work_id": event_work_id(event),
        "run_id": event_run_id(event),
        "message": message,
    });
    let digest = format!("{:x}", Sha256::digest(id_seed.to_string().as_bytes()));
    let occurred_at = match event {
        NotifyEvent::DispatchFailed { timestamp, .. }
        | NotifyEvent::DispatchFailureResolved { timestamp, .. } => (*timestamp).to_string(),
        _ => OffsetDateTime::now_utc()
            .format(&Rfc3339)
            .unwrap_or_default(),
    };
    let body = json!({
        "id": format!("rust:{}", &digest[..24]),
        "occurredAt": occurred_at,
        "profile": profile_name,
        "kind": kind,
        "severity": severity,
        "title": title,
        "message": message,
        "workId": event_work_id(event),
    })
    .to_string();
    (format!("worker-activity-{}", &digest[..24]), body)
}

fn post_activity(
    central_url: &str,
    profile: &Profile,
    event: &NotifyEvent<'_>,
) -> anyhow::Result<()> {
    let (key, body) = activity_body(profile, event);
    let token = std::env::var("COORDINATOR_TOKEN").ok();
    let response = crate::curl_http::request_with_idempotency_key(
        "POST",
        &activity_url(central_url)?,
        Some(&body),
        token.as_deref(),
        5,
        Some(&key),
    )?;
    if !matches!(response.status, 200 | 201 | 409) {
        anyhow::bail!(
            "activity API returned {}: {}",
            response.status,
            crate::redact::redact(&String::from_utf8_lossy(&response.body))
        );
    }
    Ok(())
}

fn enqueue_manager_wake(
    cfg: &GahConfig,
    manager: &str,
    repo_id: &str,
    instruction: &str,
) -> anyhow::Result<()> {
    let central_url = cfg
        .defaults
        .registry_central_url
        .as_deref()
        .unwrap_or("http://127.0.0.1:3773");
    let body = json!({
        "manager": manager,
        "repoId": repo_id,
        "instruction": instruction,
    })
    .to_string();
    let token = std::env::var("COORDINATOR_TOKEN").ok();
    let response = crate::curl_http::request(
        "POST",
        &manager_wake_url(central_url)?,
        Some(&body),
        token.as_deref(),
        5,
    )?;
    if response.status != 202 {
        anyhow::bail!(
            "manager chat wake API returned {}: {}",
            response.status,
            crate::redact::redact(&String::from_utf8_lossy(&response.body))
        );
    }
    Ok(())
}

fn format_attempt_count(attempt_count: Option<u32>) -> String {
    attempt_count.map_or_else(|| "unknown".to_string(), |count| count.to_string())
}

fn summarize_error_summary(summary: Option<&str>) -> Option<String> {
    summary.and_then(|summary| {
        let sanitized = crate::redact::redact(&strip_ansi(summary));
        // Notification hooks promise one logical line. Backend errors often
        // contain command output with newlines/tabs; collapse all whitespace
        // before truncation so one failure cannot forge extra alert lines.
        let sanitized = sanitized.split_whitespace().collect::<Vec<_>>().join(" ");
        let sanitized = sanitized.trim();
        if sanitized.is_empty() {
            return None;
        }
        let truncated =
            crate::dispatch::utf8_safe_prefix(sanitized, NOTIFICATION_ERROR_SUMMARY_MAX_BYTES);
        let truncated = truncated.trim();
        if truncated.is_empty() {
            None
        } else {
            Some(truncated.to_string())
        }
    })
}

fn strip_ansi(text: &str) -> String {
    let ansi = regex::Regex::new(r"\x1b\[[0-9;]*[a-zA-Z]").unwrap();
    let osc = regex::Regex::new(r"\x1b\].*?(?:\x07|\x1b\\)").unwrap();
    let ansi_text = ansi.replace_all(text, "");
    osc.replace_all(&ansi_text, "").into_owned()
}

#[derive(Debug, Clone)]
struct TerminalFailureRecord {
    profile: String,
    work_id: String,
    run_id: String,
    failure_class: String,
    failure_stage: Option<String>,
    attempt_count: Option<u32>,
    error_summary: Option<String>,
    timestamp: String,
}

#[derive(Debug)]
struct TerminalFailureState<'a> {
    profile: &'a str,
    work_id: &'a str,
    run_id: &'a str,
    failure_class: &'a str,
    failure_stage: Option<&'a str>,
    attempt_count: Option<u32>,
    error_summary: Option<&'a str>,
    timestamp: &'a str,
    mr_url: Option<&'a str>,
}

#[derive(Debug)]
pub(crate) struct TerminalFailurePayload<'a> {
    pub(crate) profile: &'a str,
    pub(crate) work_id: &'a str,
    pub(crate) run_id: &'a str,
    pub(crate) failure_class: &'a str,
    pub(crate) failure_stage: Option<&'a str>,
    pub(crate) attempt_count: Option<u32>,
    pub(crate) error_summary: Option<&'a str>,
    pub(crate) mr_url: Option<&'a str>,
}

fn terminal_failure_dedupe_window() -> time::Duration {
    let configured = std::env::var(TERMINAL_FAILURE_EVENT_DEDUPE_SECONDS_ENV)
        .ok()
        .and_then(|value| value.parse::<i64>().ok());
    time::Duration::seconds(configured.unwrap_or(TERMINAL_FAILURE_EVENT_DEDUPE_SECONDS))
}

fn terminal_failure_timestamp_now() -> String {
    OffsetDateTime::now_utc()
        .format(&Rfc3339)
        .unwrap_or_default()
}

fn parse_terminal_failure_timestamp(raw: &str) -> Option<OffsetDateTime> {
    OffsetDateTime::parse(raw, &Rfc3339).ok().or_else(|| {
        raw.parse::<i64>()
            .ok()
            .and_then(|secs| OffsetDateTime::from_unix_timestamp(secs).ok())
    })
}

fn terminal_failure_from_event(event: &events::ControllerEvent) -> Option<TerminalFailureRecord> {
    let value = serde_json::from_str::<serde_json::Value>(&event.details).ok()?;
    Some(TerminalFailureRecord {
        profile: value
            .get("profile")
            .and_then(|v| v.as_str())
            .unwrap_or("unknown")
            .to_string(),
        work_id: value
            .get("work_id")
            .and_then(|v| v.as_str())
            .unwrap_or("unknown")
            .to_string(),
        run_id: value
            .get("run_id")
            .and_then(|v| v.as_str())
            .unwrap_or("unknown")
            .to_string(),
        failure_class: value
            .get("failure_class")
            .and_then(|v| v.as_str())
            .unwrap_or("unknown")
            .to_string(),
        failure_stage: value
            .get("failure_stage")
            .and_then(|v| v.as_str())
            .map(str::to_string),
        attempt_count: value
            .get("attempt_count")
            .and_then(|v| v.as_u64().and_then(|v| v.try_into().ok())),
        error_summary: value
            .get("error_summary")
            .and_then(|v| v.as_str())
            .map(str::to_string),
        timestamp: event.timestamp.clone(),
    })
}

fn terminal_failure_state_cache() -> &'static Mutex<TerminalFailureCache> {
    static CACHE: OnceLock<Mutex<TerminalFailureCache>> = OnceLock::new();
    CACHE.get_or_init(|| Mutex::new(HashMap::new()))
}

#[cfg(test)]
pub(crate) fn clear_terminal_failure_cache_for_test(cfg: &GahConfig, profile: &str, work_id: &str) {
    let key = terminal_failure_cache_key(cfg, profile, work_id);
    let mut cache = terminal_failure_state_cache()
        .lock()
        .unwrap_or_else(|err| err.into_inner());
    cache.remove(&key);
}

fn terminal_failure_cache_key(
    cfg: &GahConfig,
    profile: &str,
    work_id: &str,
) -> TerminalFailureCacheKey {
    (
        cfg.defaults.events_path().to_string_lossy().to_string(),
        profile.to_string(),
        work_id.to_string(),
    )
}

fn cache_terminal_failure_record(
    cfg: &GahConfig,
    profile: &str,
    work_id: &str,
    failure: Option<TerminalFailureRecord>,
) {
    let key = terminal_failure_cache_key(cfg, profile, work_id);
    let mut cache = terminal_failure_state_cache()
        .lock()
        .unwrap_or_else(|err| err.into_inner());
    cache.insert(key, failure);
}

fn latest_unresolved_terminal_failure_from_events(
    events: &[events::ControllerEvent],
    profile: &str,
    work_id: &str,
) -> Option<TerminalFailureRecord> {
    for event in events.iter().rev() {
        let Some(failure) = terminal_failure_from_event(event) else {
            continue;
        };
        if failure.profile != profile || failure.work_id != work_id {
            continue;
        }
        match event.event_type.as_str() {
            t if t == events::EventType::TerminalFailureResolved.as_str() => return None,
            t if t == events::EventType::TerminalFailure.as_str() => return Some(failure),
            _ => continue,
        }
    }
    None
}

fn latest_unresolved_terminal_failure_record(
    cfg: &GahConfig,
    profile: &str,
    work_id: &str,
) -> Option<TerminalFailureRecord> {
    let events = match events::read_events(cfg) {
        Ok(events) => events,
        Err(error) => {
            eprintln!(
                "[gah] terminal failure dedupe fallback for profile={profile}, work_id={work_id}: {error:#}"
            );
            let key = terminal_failure_cache_key(cfg, profile, work_id);
            return terminal_failure_state_cache()
                .lock()
                .unwrap_or_else(|err| err.into_inner())
                .get(&key)
                .and_then(Clone::clone);
        }
    };

    let latest = latest_unresolved_terminal_failure_from_events(&events, profile, work_id);
    cache_terminal_failure_record(cfg, profile, work_id, latest.clone());
    latest
}

fn should_emit_terminal_failure(cfg: &GahConfig, current: &TerminalFailureState<'_>) -> bool {
    let Some(prior) =
        latest_unresolved_terminal_failure_record(cfg, current.profile, current.work_id)
    else {
        return true;
    };

    if prior.failure_class != current.failure_class {
        return true;
    }
    if prior.failure_stage.as_deref() != current.failure_stage {
        return true;
    }
    if prior.attempt_count != current.attempt_count {
        return true;
    }
    if prior.error_summary.as_deref() != current.error_summary {
        return true;
    }

    let now = match parse_terminal_failure_timestamp(current.timestamp) {
        Some(ts) => ts,
        None => return true,
    };
    let prior_ts = match parse_terminal_failure_timestamp(&prior.timestamp) {
        Some(ts) => ts,
        None => return true,
    };
    now - prior_ts > terminal_failure_dedupe_window()
}

fn record_terminal_failure_event(cfg: &GahConfig, failure: &TerminalFailureState<'_>) {
    let event_profile = failure.profile;
    let event_work_id = failure.work_id;
    let event_run_id = failure.run_id;
    let event_failure_class = failure.failure_class;
    let event_failure_stage = failure.failure_stage;
    let event_attempt_count = failure.attempt_count;
    let event_error_summary = failure.error_summary;
    let event_mr_url = failure.mr_url;
    let _ = events::record(
        cfg,
        events::EventType::TerminalFailure,
        Some(failure.profile),
        Some(failure.work_id),
        json!({
            "profile": event_profile,
            "work_id": event_work_id,
            "run_id": event_run_id,
            "failure_class": event_failure_class,
            "failure_stage": event_failure_stage,
            "attempt_count": event_attempt_count,
            "error_summary": event_error_summary,
            "mr_url": event_mr_url,
        })
        .to_string(),
    );
    cache_terminal_failure_record(
        cfg,
        event_profile,
        event_work_id,
        Some(TerminalFailureRecord {
            profile: event_profile.to_string(),
            work_id: event_work_id.to_string(),
            run_id: event_run_id.to_string(),
            failure_class: event_failure_class.to_string(),
            failure_stage: event_failure_stage.map(str::to_string),
            attempt_count: event_attempt_count,
            error_summary: event_error_summary.map(str::to_string),
            timestamp: terminal_failure_timestamp_now(),
        }),
    );
}

fn record_terminal_failure_resolved(
    cfg: &GahConfig,
    profile: &str,
    work_id: &str,
    failure_run_id: &str,
    failure_class: &str,
    failure_stage: Option<&str>,
    resolved_by_run_id: Option<&str>,
) {
    let details = if let Some(resolved_by_run_id) = resolved_by_run_id {
        json!({
            "profile": profile,
            "work_id": work_id,
            "resolved_run_id": failure_run_id,
            "failure_class": failure_class,
            "failure_stage": failure_stage,
            "resolved_by_run_id": resolved_by_run_id,
        })
        .to_string()
    } else {
        json!({
            "profile": profile,
            "work_id": work_id,
            "resolved_run_id": failure_run_id,
            "failure_class": failure_class,
            "failure_stage": failure_stage,
        })
        .to_string()
    };
    match resolved_by_run_id {
        Some(resolved_by_run_id) => {
            let _ = events::record_with_run_id(
                cfg,
                events::EventType::TerminalFailureResolved,
                Some(profile),
                Some(work_id),
                Some(resolved_by_run_id),
                details,
            );
        }
        None => {
            let _ = events::record(
                cfg,
                events::EventType::TerminalFailureResolved,
                Some(profile),
                Some(work_id),
                details,
            );
        }
    }
    cache_terminal_failure_record(cfg, profile, work_id, None);
}

fn event_name(event: &NotifyEvent<'_>) -> &'static str {
    match event {
        NotifyEvent::HumanRequired { .. } => "human_required",
        NotifyEvent::PaidRouteApprovalRequired { .. } => "paid_route_approval_required",
        NotifyEvent::ExternalApprovalRequested { .. } => "external_approval_requested",
        NotifyEvent::ExternalApprovalResolved { .. } => "external_approval_resolved",
        NotifyEvent::MrCreated { .. } => "mr_created",
        NotifyEvent::ReviewVerdict { .. } => "review_verdict",
        NotifyEvent::ReviewOutputInvalid { .. } => "review_output_invalid",
        NotifyEvent::MrMerged { .. } => "mr_merged",
        NotifyEvent::DispatchFailed { .. } => "dispatch_failed",
        NotifyEvent::DispatchFailureResolved { .. } => "dispatch_failure_resolved",
        NotifyEvent::BackendStalled { .. } => "backend_stalled",
        NotifyEvent::HandoffCreated { .. } => "handoff_created",
    }
}

fn event_work_id<'a>(event: &'a NotifyEvent<'a>) -> Option<&'a str> {
    match event {
        NotifyEvent::MrMerged { work_id, .. }
        | NotifyEvent::PaidRouteApprovalRequired { work_id, .. } => Some(work_id),
        NotifyEvent::ExternalApprovalRequested { work_id, .. }
        | NotifyEvent::ExternalApprovalResolved { work_id, .. } => Some(work_id),
        NotifyEvent::DispatchFailed { work_id, .. } => Some(work_id),
        NotifyEvent::DispatchFailureResolved { work_id, .. } => Some(work_id),
        NotifyEvent::HandoffCreated { ticket, .. } => Some(ticket),
        _ => None,
    }
}

fn event_run_id<'a>(event: &'a NotifyEvent<'a>) -> Option<&'a str> {
    match event {
        NotifyEvent::DispatchFailed { run_id, .. }
        | NotifyEvent::DispatchFailureResolved { run_id, .. } => Some(run_id),
        _ => None,
    }
}

fn event_profile<'a>(event: &'a NotifyEvent<'a>) -> Option<&'a str> {
    match event {
        NotifyEvent::DispatchFailed { profile, .. }
        | NotifyEvent::PaidRouteApprovalRequired { profile, .. }
        | NotifyEvent::ExternalApprovalRequested { profile, .. }
        | NotifyEvent::ExternalApprovalResolved { profile, .. }
        | NotifyEvent::DispatchFailureResolved { profile, .. } => Some(profile),
        _ => None,
    }
}

pub(crate) fn notify_terminal_failure(
    cfg: &GahConfig,
    profile: &Profile,
    input: TerminalFailurePayload<'_>,
) {
    let timestamp = terminal_failure_timestamp_now();
    let safe_summary = summarize_error_summary(input.error_summary);
    let terminal_failure = TerminalFailureState {
        profile: input.profile,
        work_id: input.work_id,
        run_id: input.run_id,
        failure_class: input.failure_class,
        failure_stage: input.failure_stage,
        attempt_count: input.attempt_count,
        error_summary: safe_summary.as_deref(),
        timestamp: &timestamp,
        mr_url: input.mr_url,
    };
    if !should_emit_terminal_failure(cfg, &terminal_failure) {
        return;
    }

    record_terminal_failure_event(cfg, &terminal_failure);

    notify_event(
        cfg,
        profile,
        NotifyEvent::DispatchFailed {
            timestamp: &timestamp,
            profile: terminal_failure.profile,
            failure_class: terminal_failure.failure_class,
            failure_stage: terminal_failure.failure_stage,
            run_id: terminal_failure.run_id,
            work_id: terminal_failure.work_id,
            attempt_count: terminal_failure.attempt_count,
            error_summary: terminal_failure.error_summary,
            mr_url: terminal_failure.mr_url,
        },
    );
}

pub(crate) fn notify_terminal_failure_resolved(
    cfg: &GahConfig,
    profile: &Profile,
    profile_name: &str,
    work_id: &str,
) {
    notify_terminal_failure_resolved_with_run_id(cfg, profile, profile_name, work_id, None);
}

pub(crate) fn notify_terminal_failure_resolved_with_run_id(
    cfg: &GahConfig,
    profile: &Profile,
    profile_name: &str,
    work_id: &str,
    resolved_by_run_id: Option<&str>,
) {
    let Some(failure) = latest_unresolved_terminal_failure_record(cfg, profile_name, work_id)
    else {
        return;
    };
    let timestamp = terminal_failure_timestamp_now();

    let failure_run_id = failure.run_id.as_str();
    record_terminal_failure_resolved(
        cfg,
        profile_name,
        work_id,
        failure_run_id,
        &failure.failure_class,
        failure.failure_stage.as_deref(),
        resolved_by_run_id,
    );
    notify_event(
        cfg,
        profile,
        NotifyEvent::DispatchFailureResolved {
            timestamp: &timestamp,
            profile: profile_name,
            failure_class: failure.failure_class.as_str(),
            failure_stage: failure.failure_stage.as_deref(),
            work_id,
            run_id: resolved_by_run_id.unwrap_or(failure_run_id),
        },
    );
}

/// Fire a notification for `event`: the existing `notify_command` hook (if
/// the profile defines one), and additionally wake the configured manager
/// agent (if the profile opts in via `manager_wake_autonomy` and
/// `cfg.defaults.current_manager` names a known agent CLI).
///
/// This is the single public entry point. It is infallible by design: any
/// error from either path is logged to stderr and swallowed so the
/// caller's flow continues exactly as if no hook existed.
pub fn notify_event(cfg: &GahConfig, profile: &Profile, event: NotifyEvent) {
    notify_event_with_enqueue(
        cfg,
        profile,
        event,
        |manager, repo_id, instruction, _log_path| {
            enqueue_manager_wake(cfg, manager, repo_id, instruction)
        },
    );
}

fn notify_event_with_enqueue<F>(cfg: &GahConfig, profile: &Profile, event: NotifyEvent, enqueue: F)
where
    F: FnOnce(&str, &str, &str, &std::path::Path) -> anyhow::Result<()>,
{
    notify_event_with_deliveries(
        cfg,
        profile,
        event,
        enqueue,
        post_activity,
        |cfg, message| {
            crate::notify_channels::deliver_channel_message(
                cfg,
                message,
                &crate::notify_channels::CurlNotifyTransport,
            )
        },
    );
}

fn notify_event_with_deliveries<F, P, C>(
    cfg: &GahConfig,
    profile: &Profile,
    event: NotifyEvent,
    enqueue: F,
    post: P,
    channel: C,
) where
    F: FnOnce(&str, &str, &str, &std::path::Path) -> anyhow::Result<()>,
    P: FnOnce(&str, &Profile, &NotifyEvent<'_>) -> anyhow::Result<()>,
    C: FnOnce(&GahConfig, &str) -> anyhow::Result<()>,
{
    if let Some(command) = &profile.notify_command {
        let message = crate::redact::redact(&format_message(&event));
        if let Err(err) = run_notify_command(command, &message) {
            eprintln!("[gah] notify_command failed (swallowed): {err:#}");
            let event_profile = event_profile(&event).unwrap_or(profile.display_name.as_str());
            if let Err(record_err) = events::record(
                cfg,
                events::EventType::NotificationDeliveryFailed,
                Some(event_profile),
                event_work_id(&event),
                json!({
                    "event_name": event_name(&event),
                    "profile": event_profile,
                    "work_id": event_work_id(&event),
                    "run_id": event_run_id(&event),
                    "error": format!("{err:#}"),
                })
                .to_string(),
            ) {
                eprintln!("[gah] failed to record notification delivery failure event (swallowed): {record_err:#}");
            }
        }
    }

    if let Some(instruction) = format_wake_instruction(&event, profile.manager_wake_autonomy) {
        let instruction = crate::redact::redact(&instruction);
        if let Some(manager) = cfg.defaults.current_manager.as_deref() {
            wake_manager_session_with(
                manager,
                &profile.display_name,
                &profile.repo_id,
                &instruction,
                &cfg.defaults.manager_wake_log_dir(),
                enqueue,
            );
        }
    }

    let posted_to_central = cfg.defaults.registry_central_url.as_deref().is_some_and(|url| {
        match post(url, profile, &event) {
            Ok(()) => true,
            Err(err) => {
                eprintln!("[gah] central activity delivery failed; falling back to direct channel (swallowed): {err:#}");
                let event_profile = event_profile(&event).unwrap_or(profile.display_name.as_str());
                if let Err(record_err) = events::record(
                    cfg,
                    events::EventType::NotificationDeliveryFailed,
                    Some(event_profile),
                    event_work_id(&event),
                    json!({
                        "event_name": event_name(&event),
                        "profile": event_profile,
                        "work_id": event_work_id(&event),
                        "run_id": event_run_id(&event),
                        "channel": "central_activity",
                        "error": format!("{err:#}"),
                    }).to_string(),
                ) {
                    eprintln!("[gah] failed to record activity delivery failure event (swallowed): {record_err:#}");
                }
                false
            }
        }
    });

    // The central feed only relays wake-notifiable kinds to the channel;
    // a posted event outside that set would otherwise be lost, so it still
    // takes the direct send.
    let feed_relays_to_channel = matches!(
        activity_shape(&event).0,
        "dispatch_failed" | "review_ready" | "action_required"
    );

    // Issue #653: deliver the same redacted message through the configured
    // channel (Telegram today, Discord webhook). Failures are visible via
    // the recorded delivery-failure event and never block the operation
    // that raised the notification — unknown delivery must not bypass
    // approval, it must only be observable. Dedup stays the caller's job:
    // notify paths that would repeat (e.g. paid-route skips) already
    // notify once per occurrence through `claim_notice`.
    if (!posted_to_central || !feed_relays_to_channel)
        && cfg.defaults.notification_channel != crate::notify_channels::NotificationChannel::None
    {
        let message = crate::redact::redact(&format_message(&event));
        if let Err(err) = channel(cfg, &message) {
            eprintln!("[gah] notification channel delivery failed (swallowed): {err:#}");
            let event_profile = event_profile(&event).unwrap_or(profile.display_name.as_str());
            if let Err(record_err) = events::record(
                cfg,
                events::EventType::NotificationDeliveryFailed,
                Some(event_profile),
                event_work_id(&event),
                json!({
                    "event_name": event_name(&event),
                    "profile": event_profile,
                    "work_id": event_work_id(&event),
                    "run_id": event_run_id(&event),
                    "channel": cfg.defaults.notification_channel.as_str(),
                    "error": format!("{err:#}"),
                })
                .to_string(),
            ) {
                eprintln!("[gah] failed to record channel delivery failure event (swallowed): {record_err:#}");
            }
        }
    }
}

#[cfg(test)]
mod tests;
