use super::{decide_next_action, NextAction, AUTO_RETRY_CAP};
use crate::models::AvailableTicket;
use crate::status::{Blocker, ScopeStatusJson, StatusError, StatusSnapshot};

#[path = "tests/backpressure.rs"]
mod backpressure;
#[path = "tests/lifecycle_priority.rs"]
mod lifecycle_priority;
#[path = "tests/pm.rs"]
mod pm;
#[path = "tests/priority.rs"]
mod priority;
#[path = "tests/review_gate.rs"]
mod review_gate;
#[path = "tests/review_handoff.rs"]
mod review_handoff;
#[path = "tests/support.rs"]
mod support;
use support::{empty_snapshot, mr, mr_ci_pending, mr_with_ci, ticket};

#[test]
fn incomplete_observation_stops_safely() {
    let mut snapshot = empty_snapshot();
    snapshot.errors.push(StatusError {
        subsystem: "sync".into(),
        message: "gh not found".into(),
        incomplete_snapshot: true,
    });
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "no_op");
    assert!(action.reason().contains("sync"));
}

#[test]
fn issue_intake_error_blocks_ticket_dispatch_but_not_mr_review() {
    let mut snapshot = empty_snapshot();
    snapshot.errors.push(StatusError {
        subsystem: "issue_intake".into(),
        message: "provider query failed".into(),
        incomplete_snapshot: false,
    });
    snapshot
        .available_tickets
        .push(ticket("12", Some("#12"), 0, None, false, false));
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "no_op");
    assert!(action.reason().contains("ticket intake incomplete"));

    snapshot
        .merge_requests
        .push(mr("gah/review", "NEEDS_REVIEW"));
    assert_eq!(decide_next_action(&snapshot).kind(), "review_mr");
}

#[test]
fn blocker_forces_human_required() {
    let mut snapshot = empty_snapshot();
    snapshot.blockers.push(Blocker {
        kind: "human_required".into(),
        reason: Some("ledger_human_required".into()),
        message: Some("Ledger indicates human intervention required".into()),
        backend: None,
        model: None,
        quota_pool: None,
        until: None,
        source_reference: Some("gah/real-1".into()),
        reason_code: None,
        remediation_plan: None,
    });
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "human_required");
}

#[test]
fn ci_failed_mr_retries_until_cap() {
    let mut snapshot = empty_snapshot();
    // Simulate 2 prior fix attempts (at the cap)
    let mut fix_attempts = std::collections::HashMap::new();
    fix_attempts.insert("gah/real-1".to_string(), 2); // AUTO_RETRY_CAP = 2
    snapshot.fix_attempt_counts = fix_attempts;
    let mut failed = mr("gah/real-1", "CI_FAILED");
    failed.review_generation = Some("review-v1:current-head:sha256:current-metadata".into());
    failed.review_verdict = Some("NEEDS_FIX".into());
    snapshot.merge_requests.push(failed);
    let action = decide_next_action(&snapshot);
    // With no unrelated work to continue, report the actual gate instead of
    // emitting a misleading idle/backpressure no-op forever.
    assert!(matches!(
        action,
        NextAction::HumanRequired {
            reason_code: Some(ref code),
            ..
        } if code == "fix_retry_cap_exceeded"
    ));
}

#[test]
fn ready_for_human_mr_maps_to_human_required() {
    let mut snapshot = empty_snapshot();
    snapshot
        .merge_requests
        .push(mr("gah/real-1", "READY_FOR_HUMAN"));
    let action = decide_next_action(&snapshot);
    assert!(matches!(
        action,
        NextAction::HumanRequired {
            reason_code: Some(ref code),
            ..
        } if code == "merge_policy"
    ));
}

#[test]
fn ready_for_human_draft_mr_with_ci_passed_becomes_mark_ready_for_review() {
    // Draft MRs must leave draft as soon as CI is conclusively green,
    // regardless of merge policy. Merge happens later, after the
    // controller observes the non-draft state.
    let mut snapshot = empty_snapshot();
    let mut mr = mr_with_ci("gah/real-1", "READY_FOR_HUMAN", true);
    mr.draft = true;
    snapshot.merge_requests.push(mr);
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "mark_ready_for_review");
    match action {
        NextAction::MarkReadyForReview { branch, .. } => assert_eq!(branch, "gah/real-1"),
        other => panic!("expected MarkReadyForReview, got {other:?}"),
    }
}

#[test]
fn ready_for_human_draft_mr_with_ci_passed_marks_ready_for_review_under_stop_for_human() {
    let mut snapshot = empty_snapshot();
    let mut mr = mr_with_ci("gah/real-1", "READY_FOR_HUMAN", true);
    mr.draft = true;
    snapshot.merge_requests.push(mr);
    snapshot.profile.merge_policy = crate::config::MergePolicy::StopForHuman;

    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "mark_ready_for_review");
}

#[test]
fn ready_for_human_mr_ci_passed_but_merge_retry_cap_exceeded_becomes_human_required() {
    let mut snapshot = empty_snapshot();
    snapshot
        .merge_requests
        .push(mr_with_ci("gah/real-1", "READY_FOR_HUMAN", true));
    snapshot
        .merge_attempt_counts
        .insert("gah/real-1".to_string(), 2); // == AUTO_RETRY_CAP
    let action = decide_next_action(&snapshot);
    assert!(matches!(
        action,
        NextAction::HumanRequired {
            reason_code: Some(ref code),
            ..
        } if code == "merge_retry_cap_exceeded"
    ));
}

// Issue #124: default auto policy merges a strong-approved, green MR.
#[test]
fn merge_policy_auto_merges_approved_mr_with_ci_passed() {
    let mut snapshot = empty_snapshot();
    snapshot
        .merge_requests
        .push(mr_with_ci("gah/real-1", "READY_FOR_HUMAN", true));
    snapshot.profile.merge_policy = crate::config::MergePolicy::Auto;
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "merge_mr");
}

// `stop_for_human` must never auto-merge: it surfaces the decision to a
// human operator once strong review is done and CI is green.
#[test]
fn merge_policy_stop_for_human_awaits_human_with_ci_passed() {
    let mut snapshot = empty_snapshot();
    snapshot
        .merge_requests
        .push(mr_with_ci("gah/real-1", "READY_FOR_HUMAN", true));
    snapshot.profile.merge_policy = crate::config::MergePolicy::StopForHuman;
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "human_required");
    assert!(action.reason().contains("stop_for_human"));
}

// `gitlab_mwps` still decides `MergeMr` (the MWPS flag is set at execution
// time in `execute_action`); it must not fall back to `human_required`.
#[test]
fn merge_policy_gitlab_mwps_decides_merge_mr_with_ci_passed() {
    let mut snapshot = empty_snapshot();
    snapshot
        .merge_requests
        .push(mr_with_ci("gah/real-1", "READY_FOR_HUMAN", true));
    snapshot.profile.merge_policy = crate::config::MergePolicy::GitlabMwps;
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "merge_mr");
    assert!(action.reason().contains("merge-when-pipeline-succeeds"));
}

// `stop_for_human` only changes behavior when CI has passed. A non-green
// `READY_FOR_HUMAN` MR still defers to a human (no merge attempted).
#[test]
fn merge_policy_stop_for_human_without_ci_passed_is_human_required() {
    let mut snapshot = empty_snapshot();
    snapshot
        .merge_requests
        .push(mr_with_ci("gah/real-1", "READY_FOR_HUMAN", false));
    snapshot.profile.merge_policy = crate::config::MergePolicy::StopForHuman;
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "human_required");
}

// Issue #156: the exact gap. Under the default `auto` merge policy (which
// both shipped profiles silently fall through to), a `READY_FOR_HUMAN` MR
// whose CI is non-terminal / unknown (GitLab `head_pipeline` missing or in
// a running/pending state) must NOT silently no-op forever. It must surface
// as a visible, observable `wait_until` re-check so the next loop tick can
// re-observe CI -- not a bare `no_op`, and not a parked state.
#[test]
fn issue_156_auto_policy_ci_pending_surfaces_as_wait_until() {
    for branch in ["gah/real-1", "gah/real-2"] {
        let mut snapshot = empty_snapshot();
        snapshot
            .merge_requests
            .push(mr_ci_pending(branch, "READY_FOR_HUMAN"));
        // Default (unset) merge policy is `Auto` -- the exact silent
        // default that triggered the bug report.
        assert_eq!(
            snapshot.profile.merge_policy,
            crate::config::MergePolicy::Auto
        );
        let action = decide_next_action(&snapshot);
        assert_eq!(
            action.kind(),
            "wait_until",
            "CI-pending MR under Auto must be observable, not a silent no_op"
        );
        assert!(action.reason().contains("not yet conclusively resolved"));
    }
}

// Issue #156 regression for the explicit `auto` value (same as the silent
// default above) and for the `gitlab_mwps` policy: CI-pending must surface
// as a re-check, never auto-merge.
#[test]
fn issue_156_explicit_auto_and_gitlab_mwps_ci_pending_waits() {
    for policy in [
        crate::config::MergePolicy::Auto,
        crate::config::MergePolicy::GitlabMwps,
    ] {
        let mut snapshot = empty_snapshot();
        snapshot
            .merge_requests
            .push(mr_ci_pending("gah/real-1", "READY_FOR_HUMAN"));
        snapshot.profile.merge_policy = policy;
        let action = decide_next_action(&snapshot);
        assert_eq!(action.kind(), "wait_until");
    }
}

// Issue #129 Bug A: `READY_FOR_HUMAN` must have exactly ONE defined
// behavior per policy. Under the default `auto` merge policy with green
// CI, it auto-merges (MergeMr); it never parks. This pins that the
// READY_FOR_HUMAN classification does not also map to HumanRequired in a
// separate code path for the same green-CI/auto-merge inputs.
#[test]
fn ready_for_human_green_ci_auto_policy_never_human_required() {
    let mut snapshot = empty_snapshot();
    snapshot
        .merge_requests
        .push(mr_with_ci("gah/real-1", "READY_FOR_HUMAN", true));
    snapshot.profile.merge_policy = crate::config::MergePolicy::Auto;
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "merge_mr");
    assert_ne!(action.kind(), "human_required");
}

// Review hold: a manager session running `gah hold set` on a work_id
// must stop gah's own loop from auto-merging it out from under them,
// even though every other input (READY_FOR_HUMAN, green CI, auto
// policy) would otherwise produce MergeMr. The MR is simply skipped for
// this tick, not escalated -- with no other actionable work in the
// snapshot, the controller emits a visible timed re-check rather than an
// indefinite NoOp.
#[test]
fn ready_for_human_review_held_work_id_does_not_auto_merge() {
    let mut snapshot = empty_snapshot();
    snapshot
        .merge_requests
        .push(mr_with_ci("gah/real-1", "READY_FOR_HUMAN", true));
    snapshot.profile.merge_policy = crate::config::MergePolicy::Auto;
    snapshot
        .review_held_work_ids
        .insert("TICKET-gah/real-1".to_string());

    let action = decide_next_action(&snapshot);
    assert_ne!(action.kind(), "merge_mr");
    assert!(matches!(
        action,
        NextAction::WaitUntil { reason, .. }
            if reason.contains("active manager review hold")
                && reason.contains("gah/real-1")
    ));
}

// Issue #129 Bug A: the complement -- the only case READY_FOR_HUMAN parks
// is when the merge policy forbids auto-merge (StopForHuman) with green CI
// (or any policy without green CI). Confirm the human-park path is the
// explicit policy decision, not a stray rule-6 mapping.
#[test]
fn ready_for_human_stop_for_human_is_explicit_human_required() {
    let mut snapshot = empty_snapshot();
    snapshot
        .merge_requests
        .push(mr_with_ci("gah/real-1", "READY_FOR_HUMAN", true));
    snapshot.profile.merge_policy = crate::config::MergePolicy::StopForHuman;
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "human_required");
    assert!(action.reason().contains("stop_for_human"));
}

#[test]
fn merged_and_closed_mrs_are_not_actionable() {
    let mut snapshot = empty_snapshot();
    snapshot.merge_requests.push(mr("gah/real-1", "MERGED"));
    snapshot
        .merge_requests
        .push(mr("gah/real-2", "CLOSED_UNMERGED"));
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "no_op");
}

#[test]
fn genuine_agent_failure_escalates() {
    let mut snapshot = empty_snapshot();
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-001-x.md",
        Some("TICKET-001"),
        1,
        Some("agent_no_progress"),
        false,
        false,
    ));
    let action = decide_next_action(&snapshot);
    match action {
        NextAction::Escalate { work_id, .. } => assert_eq!(work_id, "TICKET-001"),
        other => panic!("expected Escalate, got {other:?}"),
    }
}

#[test]
fn context_limit_failure_escalates_without_being_orphaned() {
    let mut snapshot = empty_snapshot();
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-context.md",
        Some("TICKET-context"),
        1,
        Some("context_limit_exceeded"),
        false,
        false,
    ));
    assert!(matches!(
        decide_next_action(&snapshot),
        NextAction::Escalate { .. }
    ));
}

// Live bug: `dispatch::decide_route` used to classify
// `RouteError::NoEligibleBackend` (every candidate backend momentarily
// quota-exhausted/cooling down) as `human_blocked`, which is excluded
// from `is_infra_failure` -- permanently orphaning the ticket even after
// a backend recovered, since this class is neither retried nor escalated
// nor flagged `human_required`. Now fixed to classify as `backend_error`,
// which *is* in `is_infra_failure`'s list; this pins that once a backend
// becomes eligible again, the ticket is retried, not silently dropped.
#[test]
fn backend_error_from_no_eligible_backend_retries_once_a_backend_is_eligible() {
    let mut snapshot = empty_snapshot();
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-noelig.md",
        Some("TICKET-noelig"),
        1,
        Some("backend_error"),
        false,
        false,
    ));

    // No eligible backend at all -> must not retry blindly.
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "no_op");

    // Now a backend is eligible -> retry, not orphaned.
    snapshot.availability.push(ScopeStatusJson {
        backend_instance: None,
        backend: "codex".into(),
        model: None,
        quota_pool: None,
        eligible_now: true,
        reason: None,
        unavailable_until: None,
        source: None,
        last_error_summary: None,
        observed_at: None,
        scope: None,
    });
    match decide_next_action(&snapshot) {
        NextAction::Retry { work_id, .. } => assert_eq!(work_id, "TICKET-noelig"),
        other => panic!("expected Retry, got {other:?}"),
    }
}

// Live incident (2026-08-04, gah profile #243 and 8 siblings): a `fix`
// attempt whose only remaining candidate backend needs operator approval
// for a paid route is legitimately classified `human_blocked` at dispatch
// time, and `human_required` is set true for that attempt. But once the
// harness re-evaluates and decides the ticket is NOT durably gated anymore
// (`human_required` back to false -- e.g. a free backend has since become
// eligible), `last_failure_class` on the ticket is still `human_blocked`
// from that attempt. Before this fix, `is_infra_failure` excluded
// `human_blocked`, so the ticket matched none of undispatched (prior
// attempts > 0), escalate (not a genuine agent failure), or retry (not an
// infra failure) -- silently orphaning it forever, exactly like the
// `NoEligibleBackend`/`backend_error` bug above. `human_required: false`
// on the ticket here is the load-bearing precondition: it is what the
// harness already decided when it stopped considering this durably gated.
#[test]
fn human_blocked_ticket_retries_once_not_durably_gated_and_a_backend_is_eligible() {
    let mut snapshot = empty_snapshot();
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-approval.md",
        Some("TICKET-approval"),
        1,
        Some("human_blocked"),
        false,
        false,
    ));

    // No eligible backend at all -> must not retry blindly.
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "no_op");

    // Now a backend is eligible -> retry, not orphaned.
    snapshot.availability.push(ScopeStatusJson {
        backend_instance: None,
        backend: "codex".into(),
        model: None,
        quota_pool: None,
        eligible_now: true,
        reason: None,
        unavailable_until: None,
        source: None,
        last_error_summary: None,
        observed_at: None,
        scope: None,
    });
    match decide_next_action(&snapshot) {
        NextAction::Retry { work_id, .. } => assert_eq!(work_id, "TICKET-approval"),
        other => panic!("expected Retry, got {other:?}"),
    }
}

#[test]
fn infra_failure_retries_only_when_a_backend_is_eligible() {
    let mut snapshot = empty_snapshot();
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-002-x.md",
        Some("TICKET-002"),
        1,
        Some("harness_error"),
        false,
        false,
    ));

    // No eligible backend at all -> must not retry blindly.
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "no_op");

    // Now a backend is eligible -> retry.
    snapshot.availability.push(ScopeStatusJson {
        backend_instance: None,
        backend: "codex".into(),
        model: None,
        quota_pool: None,
        eligible_now: true,
        reason: None,
        unavailable_until: None,
        source: None,
        last_error_summary: None,
        observed_at: None,
        scope: None,
    });
    let action = decide_next_action(&snapshot);
    match action {
        NextAction::Retry { work_id, .. } => assert_eq!(work_id, "TICKET-002"),
        other => panic!("expected Retry, got {other:?}"),
    }
}

#[test]
fn retry_cap_exceeded_forces_human_required() {
    let mut snapshot = empty_snapshot();
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-003-x.md",
        Some("TICKET-003"),
        2, // == AUTO_RETRY_CAP
        Some("agent_no_progress"),
        false,
        false,
    ));
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "human_required");
}

// Issue #95: infra-class failures must NOT consume the retry cap. A
// ticket with 3 backend_error/environment_error failures and 0 genuine
// agent failures should still be retried, not halted.
#[test]
fn infra_failures_do_not_exhaust_retry_cap() {
    let mut snapshot = empty_snapshot();
    snapshot.available_tickets.push(AvailableTicket {
        ticket_path: "docs/tickets/TICKET-INFRA-x.md".into(),
        work_id: Some("TICKET-INFRA".into()),
        normalized_work_identity: crate::work_claim::normalize_work_identity("TICKET-INFRA"),
        source: crate::models::CandidateSource::LegacyTicket,
        execution_policy: crate::models::CandidateExecutionPolicy {
            intake_mode: "legacy".into(),
            explicit_autonomy_required: false,
            autonomous_metadata_present: false,
            dispatchable_now: true,
            exclusion_reason_code: None,
            exclusion_reason: None,
        },
        title: None,
        recommended_backend: None,
        recommended_model: None,
        priority: crate::models::TicketPriority::Unspecified,
        prior_attempt_count: 3,
        genuine_agent_failure_count: 0, // all were infra failures
        last_failure_class: Some("backend_error".into()),
        has_active_mr: false,
        human_required: false,
        human_required_reason_code: None,
        has_active_claim: false,
    });
    // Without a backend eligible, it should not be retried or escalated
    snapshot.availability.push(ScopeStatusJson {
        backend_instance: None,
        backend: "codex".into(),
        model: None,
        quota_pool: None,
        eligible_now: true,
        reason: None,
        unavailable_until: None,
        source: None,
        last_error_summary: None,
        observed_at: None,
        scope: None,
    });
    let action = decide_next_action(&snapshot);
    // Should retry, not return human_required
    match action {
        NextAction::Retry { work_id, .. } => assert_eq!(work_id, "TICKET-INFRA"),
        other => panic!("expected Retry for infra-only failures, got {other:?}"),
    }
}

// Live incident: a `git fetch` failure during worktree setup (e.g. a
// misconfigured remote, transient auth prompt) is a harness-level
// plumbing failure classified `harness_error`, not an agent failure.
// Before the dispatch.rs fix, this path left `failure_class` as `None`,
// which neither the escalate loop (`is_genuine_agent_failure`) nor the
// retry loop (`is_infra_failure`) picks up -- both gate on
// `Some(failure_class)` -- so the ticket became permanently un-actionable
// once `prior_attempt_count > 0`. With `failure_class` correctly set to
// `harness_error`, it must flow through the infra-failure retry path.
#[test]
fn git_fetch_harness_error_is_retried_not_orphaned() {
    let mut snapshot = empty_snapshot();
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-FETCH-x.md",
        Some("TICKET-FETCH"),
        1,
        Some("harness_error"),
        false,
        false,
    ));
    snapshot.availability.push(ScopeStatusJson {
        backend_instance: None,
        backend: "codex".into(),
        model: None,
        quota_pool: None,
        eligible_now: true,
        reason: None,
        unavailable_until: None,
        source: None,
        last_error_summary: None,
        observed_at: None,
        scope: None,
    });
    let action = decide_next_action(&snapshot);
    match action {
        NextAction::Retry { work_id, .. } => assert_eq!(work_id, "TICKET-FETCH"),
        other => panic!("expected Retry for harness_error, got {other:?}"),
    }
}

// Issue #95: genuine agent failures MUST still exhaust the retry cap.
// A ticket with 2 agent_no_progress failures should be halted.
#[test]
fn genuine_agent_failures_still_exhaust_retry_cap() {
    let mut snapshot = empty_snapshot();
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-AGENT-x.md",
        Some("TICKET-AGENT"),
        2, // == AUTO_RETRY_CAP
        Some("agent_no_progress"),
        false,
        false,
    ));
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "human_required");
}

// Issue #95: mixed failures -- only agent failures count toward the cap.
// 2 agent failures + 2 infra failures: agent_failure_count = 2 == cap
// => exhausted.
#[test]
fn mixed_failures_only_agent_count_toward_cap() {
    let mut snapshot = empty_snapshot();
    snapshot.available_tickets.push(AvailableTicket {
        ticket_path: "docs/tickets/TICKET-MIXED-x.md".into(),
        work_id: Some("TICKET-MIXED".into()),
        normalized_work_identity: crate::work_claim::normalize_work_identity("TICKET-MIXED"),
        source: crate::models::CandidateSource::LegacyTicket,
        execution_policy: crate::models::CandidateExecutionPolicy {
            intake_mode: "legacy".into(),
            explicit_autonomy_required: false,
            autonomous_metadata_present: false,
            dispatchable_now: true,
            exclusion_reason_code: None,
            exclusion_reason: None,
        },
        title: None,
        recommended_backend: None,
        recommended_model: None,
        priority: crate::models::TicketPriority::Unspecified,
        prior_attempt_count: 4,         // 2 agent + 2 infra
        genuine_agent_failure_count: 2, // == AUTO_RETRY_CAP
        last_failure_class: Some("backend_error".into()),
        has_active_mr: false,
        human_required: false,
        human_required_reason_code: None,
        has_active_claim: false,
    });
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "human_required");
}

// Issue #95: infra-only failures do NOT block other undispatched tickets.
// Same as exhausted_ticket_does_not_block_others but with infra failures.
#[test]
fn infra_exhausted_ticket_does_not_block_others() {
    let mut snapshot = empty_snapshot();
    // TICKET-INFRA has 3 infra failures but 0 agent failures -> not exhausted
    snapshot.available_tickets.push(AvailableTicket {
        ticket_path: "docs/tickets/TICKET-INFRA-x.md".into(),
        work_id: Some("TICKET-INFRA".into()),
        normalized_work_identity: crate::work_claim::normalize_work_identity("TICKET-INFRA"),
        source: crate::models::CandidateSource::LegacyTicket,
        execution_policy: crate::models::CandidateExecutionPolicy {
            intake_mode: "legacy".into(),
            explicit_autonomy_required: false,
            autonomous_metadata_present: false,
            dispatchable_now: true,
            exclusion_reason_code: None,
            exclusion_reason: None,
        },
        title: None,
        recommended_backend: None,
        recommended_model: None,
        priority: crate::models::TicketPriority::Unspecified,
        prior_attempt_count: 3,
        genuine_agent_failure_count: 0,
        last_failure_class: Some("environment_error".into()),
        has_active_mr: false,
        human_required: false,
        human_required_reason_code: None,
        has_active_claim: false,
    });
    // TICKET-FRESH is undispatched
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-FRESH-x.md",
        Some("TICKET-FRESH"),
        0,
        None,
        false,
        false,
    ));
    let action = decide_next_action(&snapshot);
    // Untouched backlog work must run before retrying an infra-failed
    // ticket; otherwise one outage can monopolize the loop.
    match action {
        NextAction::DispatchTicket { work_id, .. } => {
            assert_eq!(work_id.as_deref(), Some("TICKET-FRESH"))
        }
        other => panic!("expected DispatchTicket for fresh work, got {other:?}"),
    }
}

#[test]
fn exhausted_ticket_does_not_block_others() {
    let mut snapshot = empty_snapshot();
    // TICKET-113 is exhausted (prior_attempt_count = 2, no active MR)
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-113-x.md",
        Some("TICKET-113"),
        2, // == AUTO_RETRY_CAP
        Some("agent_no_progress"),
        false,
        false,
    ));
    // TICKET-128 is eligible (prior_attempt_count = 0, no active MR)
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-128-x.md",
        Some("TICKET-128"),
        0,
        None,
        false,
        false,
    ));
    let action = decide_next_action(&snapshot);
    // Should dispatch TICKET-128, NOT return human_required
    match action {
        NextAction::DispatchTicket { work_id, .. } => {
            assert_eq!(work_id.as_deref(), Some("TICKET-128"))
        }
        other => panic!("expected DispatchTicket for TICKET-128, got {other:?}"),
    }
}

// TICKET-skip-and-continue: an MR stuck at NEEDS_FIX beyond the fix retry
// cap must NOT freeze the profile. An unrelated eligible ticket still
// dispatches (this is the worldcup-props !249 recurring-stall case).
#[test]
fn exhausted_mr_does_not_block_others() {
    let mut snapshot = empty_snapshot();
    // Stuck MR with fix attempts >= cap.
    snapshot
        .fix_attempt_counts
        .insert("gah/stuck-1".into(), AUTO_RETRY_CAP);
    snapshot
        .merge_requests
        .push(needs_fix_mr("gah/stuck-1", "TICKET-gah/stuck-1"));
    // An unrelated eligible ticket exists.
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-128-x.md",
        Some("TICKET-128"),
        0,
        None,
        false,
        false,
    ));
    let action = decide_next_action(&snapshot);
    match action {
        NextAction::DispatchTicket { work_id, .. } => {
            assert_eq!(work_id.as_deref(), Some("TICKET-128"))
        }
        other => panic!("expected DispatchTicket for TICKET-128, got {other:?}"),
    }
}

// A profile with ONLY an exhausted MR reports the exact gate instead of
// pretending the controller is idle.
#[test]
fn exhausted_mr_alone_is_human_required() {
    let mut snapshot = empty_snapshot();
    snapshot
        .fix_attempt_counts
        .insert("gah/stuck-1".into(), AUTO_RETRY_CAP);
    snapshot
        .merge_requests
        .push(needs_fix_mr("gah/stuck-1", "TICKET-gah/stuck-1"));
    let action = decide_next_action(&snapshot);
    assert!(matches!(
        action,
        NextAction::HumanRequired {
            reason_code: Some(ref code),
            ..
        } if code == "fix_retry_cap_exceeded"
    ));
}

#[test]
fn never_dispatched_ticket_is_eligible() {
    let mut snapshot = empty_snapshot();
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-004-x.md",
        Some("TICKET-004"),
        0,
        None,
        false,
        false,
    ));
    let action = decide_next_action(&snapshot);
    match action {
        NextAction::DispatchTicket { work_id, .. } => {
            assert_eq!(work_id.as_deref(), Some("TICKET-004"))
        }
        other => panic!("expected DispatchTicket, got {other:?}"),
    }
}

#[test]
fn ticket_with_active_mr_is_never_a_dispatch_candidate() {
    let mut snapshot = empty_snapshot();
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-005-x.md",
        Some("TICKET-005"),
        1,
        Some("agent_no_progress"),
        true, // has_active_mr
        false,
    ));
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "no_op");
}

// TICKET-human-required-scoping regression tests.
// A ticket-scoped human_required must NOT freeze the profile: the blocked
// ticket is skipped, and an unrelated eligible ticket still dispatches.
#[test]
fn ticket_scoped_human_block_does_not_freeze_profile() {
    let mut snapshot = empty_snapshot();
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-A-x.md",
        Some("TICKET-A"),
        1,
        None,
        false,
        true,
    ));
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-B-x.md",
        Some("TICKET-B"),
        0,
        None,
        false,
        false,
    ));
    // profile-wide blockers must stay empty
    assert!(snapshot.blockers.is_empty());
    let action = decide_next_action(&snapshot);
    match action {
        NextAction::DispatchTicket { work_id, .. } => {
            assert_eq!(work_id.as_deref(), Some("TICKET-B"))
        }
        other => panic!("expected DispatchTicket for TICKET-B, got {other:?}"),
    }
}

// Most-recent ledger entry belongs to another blocked ticket: the eligible
// one (written earlier) must remain dispatchable. Directly reproduces the
// observed incident (a newer NEEDS_FIX verdict froze the whole profile).
#[test]
fn most_recent_ledger_entry_belongs_to_other_blocked_ticket() {
    let mut snapshot = empty_snapshot();
    // B is eligible (written earlier, human_required false)
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-B-x.md",
        Some("TICKET-B"),
        0,
        None,
        false,
        false,
    ));
    // A is human-blocked (the newer ledger entry)
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-A-x.md",
        Some("TICKET-A"),
        1,
        None,
        false,
        true,
    ));
    let action = decide_next_action(&snapshot);
    match action {
        NextAction::DispatchTicket { work_id, .. } => {
            assert_eq!(work_id.as_deref(), Some("TICKET-B"))
        }
        other => panic!("expected DispatchTicket for TICKET-B, got {other:?}"),
    }
}

// Human-blocked ticket remains blocked (not redispatched, not escalated).
#[test]
fn human_blocked_ticket_remains_blocked() {
    let mut snapshot = empty_snapshot();
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-A-x.md",
        Some("TICKET-A"),
        1,
        None,
        false,
        true,
    ));
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "no_op");
}

// Multiple blocked and eligible tickets coexist: only eligible ones dispatch.
#[test]
fn multiple_blocked_and_eligible_coexist() {
    let mut snapshot = empty_snapshot();
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-A-x.md",
        Some("TICKET-A"),
        1,
        None,
        false,
        true,
    ));
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-B-x.md",
        Some("TICKET-B"),
        0,
        None,
        false,
        false,
    ));
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-C-x.md",
        Some("TICKET-C"),
        1,
        None,
        false,
        true,
    ));
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-D-x.md",
        Some("TICKET-D"),
        0,
        None,
        false,
        false,
    ));
    assert!(snapshot.blockers.is_empty());
    let action = decide_next_action(&snapshot);
    match action {
        NextAction::DispatchTicket { work_id, .. } => {
            assert_eq!(work_id.as_deref(), Some("TICKET-B"))
        }
        other => panic!("expected DispatchTicket for TICKET-B, got {other:?}"),
    }
}

// Genuine profile-wide blocker (sync failure observation) still halts the
// profile. It is reported via `errors` (-> decide_next_action Rule 1 =>
// NoOp), NOT via a ticket-scoped human_required `blockers` entry. The fix
// must preserve this path while no longer freezing on ticket-scoped HR.
#[test]
fn genuine_profile_wide_blocker_still_stops_dispatch() {
    let mut snapshot = empty_snapshot();
    snapshot.errors.push(StatusError {
        subsystem: "sync".into(),
        message: "gh not found".into(),
        incomplete_snapshot: true,
    });
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-B-x.md",
        Some("TICKET-B"),
        0,
        None,
        false,
        false,
    ));
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "no_op");
    // ticket-scoped human_required must NOT create a profile-wide blocker
    assert!(snapshot.blockers.is_empty());
    // the genuine profile-wide failure is recorded in errors
    assert!(!snapshot.errors.is_empty());
}

// A ticket whose human_required has since cleared must no longer be blocked.
// (build_snapshot re-derives per-work-item human_required from current
// ledger history; here we model the cleared state directly.)
#[test]
fn later_state_clears_prior_human_requirement() {
    let mut snapshot = empty_snapshot();
    // No human_required flag + fresh (prior_attempt_count 0) -> eligible, dispatches.
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-A-x.md",
        Some("TICKET-A"),
        0,
        None,
        false,
        false,
    ));
    let action = decide_next_action(&snapshot);
    match action {
        NextAction::DispatchTicket { work_id, .. } => {
            assert_eq!(work_id.as_deref(), Some("TICKET-A"))
        }
        other => panic!("expected DispatchTicket for cleared TICKET-A, got {other:?}"),
    }
    assert!(snapshot.blocked_work_items.is_empty());
}

// ===== Bug 1: dispatch_reason scoping for fix retry cap =====
// Internal OpenHands retries (attempts_started > 0 within one dispatch)
// must NOT consume the post-review fix retry budget.
fn needs_fix_mr(branch: &str, work_id: &str) -> crate::sync::SyncMrJson {
    crate::sync::SyncMrJson {
        profile: None,
        branch: branch.into(),
        work_id: Some(work_id.into()),
        id: None,
        url: None,
        state: Some("opened".into()),
        draft: true,
        merge_status: Some("can_be_merged".into()),
        merged: false,
        merged_at: None,
        ci_passed: false,
        ci_pending: false,
        title: None,
        effective_backend: None,
        effective_model: None,
        review_verdict: Some("NEEDS_FIX".into()),
        review_gate_reason: None,
        source_sha: None,
        merge_commit_sha: None,
        review_contract_version: crate::ledger::REVIEW_CONTRACT_VERSION,
        review_generation: Some("review-v1:current-head:sha256:current-metadata".into()),
        review_generation_status: None,
        classification: "NEEDS_FIX".into(),
        recommended_action: crate::sync::RecommendedAction::ReuseBranch,
    }
}

#[test]
fn internal_retries_do_not_consume_fix_retry_budget() {
    let mut snapshot = empty_snapshot();
    snapshot.fix_attempt_counts.insert("branch-A".into(), 0);
    snapshot
        .merge_requests
        .push(needs_fix_mr("branch-A", "TICKET-A"));
    let action = decide_next_action(&snapshot);
    match action {
        NextAction::FixMr { branch, .. } => assert_eq!(branch, "branch-A"),
        other => panic!("expected FixMr, got {other:?}"),
    }
}

// First NEEDS_FIX review permits the first repair dispatch.
#[test]
fn first_needs_fix_permits_first_repair_dispatch() {
    let mut snapshot = empty_snapshot();
    snapshot.fix_attempt_counts.insert("branch-A".into(), 0);
    snapshot
        .merge_requests
        .push(needs_fix_mr("branch-A", "TICKET-A"));
    let action = decide_next_action(&snapshot);
    match action {
        NextAction::FixMr { .. } => {}
        other => panic!("expected FixMr for first repair, got {other:?}"),
    }
}

// Actual repair dispatches increment the count exactly once each.
// After AUTO_RETRY_CAP (2) repairs, HumanRequired fires.
#[test]
fn retry_cap_triggers_after_configured_post_review_repairs() {
    let mut snapshot = empty_snapshot();
    snapshot.fix_attempt_counts.insert("branch-A".into(), 2);
    snapshot
        .merge_requests
        .push(needs_fix_mr("branch-A", "TICKET-A"));
    let action = decide_next_action(&snapshot);
    assert!(matches!(
        action,
        NextAction::HumanRequired {
            reason_code: Some(ref code),
            ..
        } if code == "fix_retry_cap_exceeded"
    ));
}

// One repair used, one more allowed.
#[test]
fn one_repair_used_still_permits_second() {
    let mut snapshot = empty_snapshot();
    snapshot.fix_attempt_counts.insert("branch-A".into(), 1);
    snapshot
        .merge_requests
        .push(needs_fix_mr("branch-A", "TICKET-A"));
    let action = decide_next_action(&snapshot);
    match action {
        NextAction::FixMr { .. } => {}
        other => panic!("expected FixMr after 1 repair (cap=2), got {other:?}"),
    }
}

#[test]
fn configured_fix_cap_allows_requested_number_of_repairs() {
    let mut snapshot = empty_snapshot();
    snapshot.profile.max_fix_attempts_per_mr = 4;
    snapshot.fix_attempt_counts.insert("branch-A".into(), 3);
    snapshot
        .merge_requests
        .push(needs_fix_mr("branch-A", "TICKET-A"));
    assert!(matches!(
        decide_next_action(&snapshot),
        NextAction::FixMr { .. }
    ));

    snapshot.fix_attempt_counts.insert("branch-A".into(), 4);
    assert!(matches!(
        decide_next_action(&snapshot),
        NextAction::HumanRequired {
            reason_code: Some(ref code),
            ..
        } if code == "fix_retry_cap_exceeded"
    ));
}

// ===== Bug 2: stuck-loop gate persists to ledger and skips ticket =====
#[test]
fn stuck_loop_gated_ticket_is_skipped() {
    let mut snapshot = empty_snapshot();
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-A-x.md",
        Some("TICKET-A"),
        0,
        None,
        false,
        true,
    ));
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-B-x.md",
        Some("TICKET-B"),
        0,
        None,
        false,
        false,
    ));
    let action = decide_next_action(&snapshot);
    match action {
        NextAction::DispatchTicket { work_id, .. } => {
            assert_eq!(work_id.as_deref(), Some("TICKET-B"))
        }
        other => panic!("expected DispatchTicket for TICKET-B (A gated), got {other:?}"),
    }
}

#[test]
fn stuck_loop_gated_ticket_remains_blocked() {
    let mut snapshot = empty_snapshot();
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-A-x.md",
        Some("TICKET-A"),
        0,
        None,
        false,
        true,
    ));
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "no_op");
}

#[test]
fn stuck_loop_gate_unrelated_ticket_eligible() {
    let mut snapshot = empty_snapshot();
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-A-x.md",
        Some("TICKET-A"),
        0,
        None,
        false,
        true,
    ));
    snapshot.available_tickets.push(ticket(
        "docs/tickets/TICKET-C-x.md",
        Some("TICKET-C"),
        0,
        None,
        false,
        false,
    ));
    let action = decide_next_action(&snapshot);
    match action {
        NextAction::DispatchTicket { work_id, .. } => {
            assert_eq!(work_id.as_deref(), Some("TICKET-C"))
        }
        other => panic!("expected DispatchTicket for TICKET-C, got {other:?}"),
    }
}

#[test]
fn stuck_loop_gated_needs_fix_mr_is_not_selected_again() {
    let mut snapshot = empty_snapshot();
    snapshot.merge_requests.push(mr("branch-A", "NEEDS_FIX"));
    snapshot.blocked_work_items.push(Blocker {
        kind: "human_required".into(),
        reason: Some("stuck_loop_gate".into()),
        message: Some("repair repeatedly selected without progress".into()),
        backend: None,
        model: None,
        quota_pool: None,
        until: None,
        source_reference: Some("TICKET-branch-A".into()),
        reason_code: Some("stuck_loop_gate".into()),
        remediation_plan: None,
    });

    assert!(matches!(
        decide_next_action(&snapshot),
        NextAction::HumanRequired {
            reason_code: Some(ref code),
            ..
        } if code == "stuck_loop_gate"
    ));
}

#[test]
fn stuck_loop_gated_mr_does_not_block_unrelated_mr() {
    let mut snapshot = empty_snapshot();
    snapshot.merge_requests.push(mr("branch-A", "NEEDS_FIX"));
    snapshot.merge_requests.push(mr("branch-B", "NEEDS_REVIEW"));
    snapshot.blocked_work_items.push(Blocker {
        kind: "human_required".into(),
        reason: Some("stuck_loop_gate".into()),
        message: Some("repair repeatedly selected without progress".into()),
        backend: None,
        model: None,
        quota_pool: None,
        until: None,
        source_reference: Some("TICKET-branch-A".into()),
        reason_code: Some("stuck_loop_gate".into()),
        remediation_plan: None,
    });

    match decide_next_action(&snapshot) {
        NextAction::ReviewMr { branch, .. } => assert_eq!(branch, "branch-B"),
        other => panic!("expected unrelated ReviewMr, got {other:?}"),
    }
}

// ===== Bug 3: retry-cap HumanRequired projects into blocked_work_items =====
#[test]
fn retry_cap_projects_into_blocked_work_items() {
    let mut snapshot = empty_snapshot();
    snapshot.fix_attempt_counts.insert("branch-A".into(), 2);
    snapshot
        .merge_requests
        .push(needs_fix_mr("branch-A", "TICKET-A"));
    // Simulate what status.rs does: project retry-cap into blocked_work_items
    const AUTO_RETRY_CAP: usize = 2;
    for mr in &snapshot.merge_requests {
        if matches!(mr.classification.as_str(), "CI_FAILED" | "NEEDS_FIX") {
            let attempts = snapshot
                .fix_attempt_counts
                .get(&mr.branch)
                .copied()
                .unwrap_or(0);
            if attempts >= AUTO_RETRY_CAP {
                snapshot.blocked_work_items.push(crate::status::Blocker {
                    kind: "human_required".into(),
                    reason: Some("fix_retry_cap_exceeded".into()),
                    message: Some("cap exceeded".into()),
                    backend: None,
                    model: None,
                    quota_pool: None,
                    until: None,
                    source_reference: Some(mr.branch.clone()),
                    reason_code: None,
                    remediation_plan: None,
                });
            }
        }
    }
    assert!(!snapshot.blocked_work_items.is_empty());
    assert_eq!(
        snapshot.blocked_work_items[0].reason.as_deref(),
        Some("fix_retry_cap_exceeded")
    );
}

#[test]
fn idle_profile_with_unrelated_known_reset_is_noop() {
    let mut snapshot = empty_snapshot();
    snapshot.availability.push(ScopeStatusJson {
        backend_instance: None,
        backend: "claude".into(),
        model: None,
        quota_pool: None,
        eligible_now: false,
        reason: Some("rate_limited".into()),
        unavailable_until: Some("2026-07-06T00:00:00Z".into()),
        source: None,
        last_error_summary: None,
        observed_at: None,
        scope: None,
    });
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "no_op");
    assert!(action.reason().contains("nothing actionable"));
}

#[test]
fn failed_infrastructure_ticket_with_known_reset_waits() {
    let mut snapshot = empty_snapshot();
    snapshot.available_tickets.push(ticket(
        "466",
        Some("#466"),
        1,
        Some("backend_error"),
        false,
        false,
    ));
    snapshot.availability.push(ScopeStatusJson {
        backend_instance: None,
        backend: "claude".into(),
        model: None,
        quota_pool: None,
        eligible_now: false,
        reason: Some("rate_limited".into()),
        unavailable_until: Some("2026-07-06T00:00:00Z".into()),
        source: None,
        last_error_summary: None,
        observed_at: None,
        scope: None,
    });

    let action = decide_next_action(&snapshot);
    match action {
        NextAction::WaitUntil { until, .. } => assert_eq!(until, "2026-07-06T00:00:00Z"),
        other => panic!("expected WaitUntil, got {other:?}"),
    }
}

#[test]
fn nothing_actionable_is_noop() {
    let snapshot = empty_snapshot();
    let action = decide_next_action(&snapshot);
    assert_eq!(action.kind(), "no_op");
}

// TICKET-505: Table-driven test that proves every current HumanRequired
// constructor/transition maps to exactly one reason code.
#[test]
fn every_human_required_constructor_has_a_reason_code() {
    use super::super::HumanRequiredReason;
    let mut cases: Vec<(HumanRequiredReason, StatusSnapshot)> = vec![];

    let mut profile_blocker = empty_snapshot();
    profile_blocker.blockers.push(Blocker {
        kind: "backend_unavailable".into(),
        reason: Some("no capacity".into()),
        message: Some("infrastructure unavailable".into()),
        backend: Some("claude".into()),
        model: None,
        quota_pool: None,
        until: None,
        source_reference: None,
        reason_code: None,
        remediation_plan: None,
    });
    cases.push((HumanRequiredReason::ConfigurationInfra, profile_blocker));

    let mut merge_policy = empty_snapshot();
    merge_policy.profile.merge_policy = crate::config::MergePolicy::StopForHuman;
    merge_policy
        .merge_requests
        .push(mr_with_ci("gah/ready-still", "READY_FOR_HUMAN", true));
    cases.push((HumanRequiredReason::MergePolicy, merge_policy));

    let mut publishing_restricted = empty_snapshot();
    publishing_restricted.publishing_allow_pr = false;
    publishing_restricted.merge_requests.push(mr_with_ci(
        "gah/ready-publish",
        "READY_FOR_HUMAN",
        true,
    ));
    cases.push((
        HumanRequiredReason::PublishingRestriction,
        publishing_restricted,
    ));

    let mut review_evidence = empty_snapshot();
    review_evidence.profile.merge_policy = crate::config::MergePolicy::StopForHuman;
    review_evidence.blocked_work_items.push(Blocker {
        kind: "human_required".into(),
        reason: Some("review hold".into()),
        message: Some("review hold active".into()),
        backend: None,
        model: None,
        quota_pool: None,
        until: None,
        source_reference: Some("TICKET-EVIDENCE".into()),
        reason_code: None,
        remediation_plan: None,
    });
    let mut review_mr = mr("gah/evidence", "NEEDS_REVIEW");
    review_mr.work_id = Some("TICKET-EVIDENCE".into());
    review_evidence.merge_requests.push(review_mr);
    cases.push((HumanRequiredReason::ReviewEvidenceGate, review_evidence));
    let mut fix_retry_exhausted = empty_snapshot();
    fix_retry_exhausted.profile.merge_policy = crate::config::MergePolicy::StopForHuman;
    fix_retry_exhausted.fix_attempt_counts.insert(
        "gah/fix".into(),
        fix_retry_exhausted.profile.max_fix_attempts_per_mr as usize,
    );
    let mut failed = mr("gah/fix", "CI_FAILED");
    failed.review_generation = Some("review-v1:current-head:sha256:current-metadata".into());
    failed.review_verdict = Some("NEEDS_FIX".into());
    fix_retry_exhausted.merge_requests.push(failed);
    cases.push((
        HumanRequiredReason::FixRetryCapExceeded,
        fix_retry_exhausted,
    ));
    let mut merge_retry_exhausted = empty_snapshot();
    merge_retry_exhausted.profile.merge_policy = crate::config::MergePolicy::StopForHuman;
    merge_retry_exhausted
        .merge_attempt_counts
        .insert("gah/merge".into(), super::AUTO_RETRY_CAP);
    merge_retry_exhausted
        .merge_requests
        .push(mr_with_ci("gah/merge", "READY_FOR_HUMAN", true));
    cases.push((
        HumanRequiredReason::MergeRetryCapExceeded,
        merge_retry_exhausted,
    ));
    let mut retry_budget = empty_snapshot();
    retry_budget.available_tickets.push(ticket(
        "docs/tickets/TICKET-RETRY.md",
        Some("TICKET-RETRY"),
        retry_budget.profile.max_implementation_failures_per_ticket as usize,
        Some("agent_no_progress"),
        false,
        false,
    ));
    cases.push((HumanRequiredReason::RetryBudgetExhausted, retry_budget));

    for (expected, snapshot) in cases {
        let action = decide_next_action(&snapshot);
        let NextAction::HumanRequired { reason_code, .. } = action else {
            panic!("expected HumanRequired, got {action:?}");
        };
        assert_eq!(
            reason_code,
            Some(expected.as_str().to_string()),
            "snapshot expected {expected:?} but got {reason_code:?}"
        );
    }
}
