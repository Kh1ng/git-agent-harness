use anyhow::{Context, Result};
use std::io::Write;
use std::process::{Command, Stdio};

const STATUS_MARKER: &str = "__GAH_HTTP_STATUS__:";

pub struct CurlResponse {
    pub status: u16,
    pub body: Vec<u8>,
}

fn config_value(value: &str) -> String {
    value
        .replace('\\', "\\\\")
        .replace('"', "\\\"")
        .replace('\r', "\\r")
        .replace('\n', "\\n")
}

/// Sends one coordinator HTTP request without placing credentials or JSON in argv.
pub fn request(
    method: &str,
    url: &str,
    body: Option<&str>,
    token: Option<&str>,
    timeout_secs: u32,
) -> Result<CurlResponse> {
    request_with_idempotency_key(method, url, body, token, timeout_secs, None)
}

pub fn request_with_idempotency_key(
    method: &str,
    url: &str,
    body: Option<&str>,
    token: Option<&str>,
    timeout_secs: u32,
    idempotency_key: Option<&str>,
) -> Result<CurlResponse> {
    if idempotency_key.is_some_and(|key| {
        !(16..=128).contains(&key.len())
            || !key
                .bytes()
                .all(|byte| byte.is_ascii_alphanumeric() || byte == b'_' || byte == b'-')
    }) {
        anyhow::bail!("invalid idempotency key")
    }
    let headers = idempotency_key
        .map(|key| vec![("Idempotency-Key", key)])
        .unwrap_or_default();
    request_internal(method, url, body, token, timeout_secs, &headers, true)
}

/// Sends a TLS-verified cloud request; coordinator TLS overrides never apply.
pub fn cloud_request(
    url: &str,
    body: &str,
    token: Option<&str>,
    api_key: &str,
) -> Result<CurlResponse> {
    cloud_request_with_timeout(url, body, token, Some(api_key), 5)
}

/// Cloud Auth and RPC requests use the same strict TLS and secret-safe transport.
pub fn cloud_request_with_timeout(
    url: &str,
    body: &str,
    token: Option<&str>,
    api_key: Option<&str>,
    timeout_secs: u32,
) -> Result<CurlResponse> {
    let headers = api_key.map(|key| vec![("apikey", key)]).unwrap_or_default();
    request_internal(
        "POST",
        url,
        Some(body),
        token,
        timeout_secs,
        &headers,
        false,
    )
    .map_err(|_| anyhow::anyhow!("cloud transport failed"))
}

/// Calls an owner-configured inference endpoint, stopping curl when authorization
/// is revoked. Neither the credential nor an upstream error body reaches logs.
pub fn cloud_provider_request(
    url: &str,
    body: &str,
    token: &str,
    authorized: impl Fn() -> bool,
) -> Result<CurlResponse> {
    if token.is_empty() || token.contains(['\r', '\n']) {
        anyhow::bail!("invalid inference credential");
    }
    let response = tempfile::NamedTempFile::new()?;
    let status = tempfile::NamedTempFile::new()?;
    let mut cmd = Command::new("curl");
    cmd.args([
        "-q",
        "-sS",
        "--max-time",
        "100",
        "--max-filesize",
        "1048576",
        "-K",
        "-",
        "-w",
        "%{http_code}",
    ])
    .arg("--output")
    .arg(response.path())
    .stdin(Stdio::piped())
    .stdout(status.reopen()?)
    .stderr(Stdio::null());
    crate::runner::prepare_process_group(&mut cmd);
    crate::runner::process::arm_child_pdeathsig(&mut cmd);
    if !authorized() {
        anyhow::bail!("inference access denied");
    }
    let mut child = cmd
        .spawn()
        .map_err(|_| anyhow::anyhow!("inference transport failed"))?;
    let config = format!("url = \"{}\"\nrequest = \"POST\"\nheader = \"Content-Type: application/json\"\nheader = \"Authorization: Bearer {}\"\ndata = \"{}\"\n", config_value(url), config_value(token), config_value(body));
    if child
        .stdin
        .take()
        .unwrap()
        .write_all(config.as_bytes())
        .is_err()
    {
        crate::runner::kill_process_group(&mut child);
        let _ = child.wait();
        anyhow::bail!("inference transport failed");
    }
    let mut checked = std::time::Instant::now();
    loop {
        if crate::runner::shutdown_requested() || checked.elapsed().as_secs() >= 5 && !authorized()
        {
            crate::runner::kill_process_group(&mut child);
            let _ = child.wait();
            anyhow::bail!("inference access denied");
        }
        if checked.elapsed().as_secs() >= 5 {
            checked = std::time::Instant::now();
        }
        match child.try_wait() {
            Ok(Some(exit)) => {
                if !exit.success() {
                    anyhow::bail!("inference transport failed");
                }
                let body = std::fs::read(response.path())?;
                if body.len() > 1048576 {
                    anyhow::bail!("inference response too large");
                }
                return Ok(CurlResponse {
                    status: std::fs::read_to_string(status.path())?.trim().parse()?,
                    body,
                });
            }
            Ok(None) => std::thread::sleep(std::time::Duration::from_millis(100)),
            Err(_) => {
                crate::runner::kill_process_group(&mut child);
                let _ = child.wait();
                anyhow::bail!("inference transport failed");
            }
        }
    }
}

fn request_internal(
    method: &str,
    url: &str,
    body: Option<&str>,
    token: Option<&str>,
    timeout_secs: u32,
    headers: &[(&str, &str)],
    coordinator_tls: bool,
) -> Result<CurlResponse> {
    if token.is_some_and(|value| value.contains(['\r', '\n']))
        || headers.iter().any(|(name, value)| {
            !name
                .bytes()
                .all(|byte| byte.is_ascii_alphanumeric() || byte == b'-')
                || value.contains(['\r', '\n'])
        })
    {
        anyhow::bail!("invalid HTTP header")
    }
    let mut cmd = Command::new("curl");
    cmd.args([
        "-q", // Ignore user curlrc options, including redirect and TLS overrides.
        "-sS",
        "--max-time",
        &timeout_secs.to_string(),
        "-K",
        "-",
        "-w",
        &format!("\n{STATUS_MARKER}%{{http_code}}\n"),
    ])
    .stdin(Stdio::piped())
    .stdout(Stdio::piped())
    .stderr(Stdio::piped());
    crate::runner::process::arm_child_pdeathsig(&mut cmd);
    let mut child = cmd
        .spawn()
        .context("spawning curl for coordinator request")?;
    if let Some(mut stdin) = child.stdin.take() {
        let mut config = format!(
            "silent\nurl = \"{}\"\nrequest = \"{}\"\n",
            config_value(url),
            config_value(method)
        );
        if let Some(body) = body {
            config.push_str("header = \"Content-Type: application/json\"\n");
            config.push_str(&format!("data = \"{}\"\n", config_value(body)));
        }
        if !coordinator_tls {
            config.push_str("max-filesize = 2097152\n");
        }
        if let Some(ca) = coordinator_tls
            .then(|| std::env::var("GAH_COORDINATOR_CA_CERT").ok())
            .flatten()
            .filter(|value| !value.is_empty())
        {
            config.push_str(&format!("cacert = \"{}\"\n", config_value(&ca)));
        } else if coordinator_tls
            && std::env::var("GAH_COORDINATOR_INSECURE_TLS").as_deref() == Ok("1")
        {
            config.push_str("insecure\n");
        }
        if let Some(token) = token {
            config.push_str(&format!(
                "header = \"Authorization: Bearer {}\"\n",
                config_value(token)
            ));
        }
        for (name, value) in headers {
            config.push_str(&format!("header = \"{}: {}\"\n", name, config_value(value)));
        }
        stdin.write_all(config.as_bytes())?;
    }
    let output = child.wait_with_output().context("waiting for curl")?;
    if !output.status.success() {
        anyhow::bail!(
            "coordinator request failed (curl exit {:?}): {}",
            output.status.code(),
            String::from_utf8_lossy(&output.stderr)
        );
    }
    let stdout = String::from_utf8_lossy(&output.stdout);
    let marker = stdout
        .rfind(STATUS_MARKER)
        .ok_or_else(|| anyhow::anyhow!("curl output missing status marker"))?;
    Ok(CurlResponse {
        status: stdout[marker + STATUS_MARKER.len()..]
            .trim()
            .parse()
            .context("parsing HTTP status from curl output")?,
        body: stdout[..marker].trim_end().as_bytes().to_vec(),
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn curl_config_values_cannot_inject_directives() {
        assert_eq!(config_value("a\nheader = \"x\""), "a\\nheader = \\\"x\\\"");
    }

    #[test]
    fn idempotency_keys_are_restricted_before_reaching_curl() {
        assert!(request_with_idempotency_key(
            "POST",
            "http://unused",
            None,
            None,
            1,
            Some("short")
        )
        .is_err());
        assert!(request_with_idempotency_key(
            "POST",
            "http://unused",
            None,
            None,
            1,
            Some("invalid-key-000\nheader")
        )
        .is_err());
    }
}
