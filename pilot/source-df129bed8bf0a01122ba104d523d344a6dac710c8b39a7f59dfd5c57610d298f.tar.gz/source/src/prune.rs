use crate::config::{self, GahConfig, Profile};
use crate::sync::{self, SyncMr};
use anyhow::Result;
use std::collections::HashSet;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::time::{Duration, SystemTime};

pub fn run(
    profile_name: Option<&str>,
    config_path: Option<&str>,
    older_than_days: Option<u64>,
    dry_run: bool,
) -> Result<()> {
    let cfg = config::load(config_path)?;
    let profiles = selected_profiles(&cfg, profile_name)?;

    for (name, profile) in profiles {
        prune_profile(&cfg, &name, profile, older_than_days, dry_run, true, None)?;
    }
    Ok(())
}

/// Run the same conservative maintenance used by `gah prune` for one
/// controller profile. The controller supplies its bounded active-MR and
/// live-claim observations so this never needs full provider history.
pub fn run_automatic(
    cfg: &GahConfig,
    profile_name: &str,
    ledger_entries: &[crate::ledger::LedgerEntry],
    snapshot: &crate::status::StatusSnapshot,
) -> Result<()> {
    let profile = config::get_profile(cfg, profile_name)?;
    let active_mrs =
        (snapshot.observations.sync.status == "ok").then_some(snapshot.merge_requests.as_slice());
    let active_claims = (!snapshot
        .errors
        .iter()
        .any(|error| error.subsystem == "claims" && error.incomplete_snapshot))
    .then_some(snapshot.active_claims.as_slice());
    let observed = automatic_worktree_sets(
        ledger_entries,
        profile_name,
        &profile.repo_id,
        active_mrs,
        active_claims,
    );
    prune_profile(
        cfg,
        profile_name,
        profile,
        None,
        false,
        false,
        Some(&observed),
    )
}

#[derive(Default)]
struct AutomaticWorktreeSets {
    done: HashSet<String>,
    abandoned_open: HashSet<String>,
    protected: HashSet<String>,
}

fn automatic_worktree_sets(
    ledger_entries: &[crate::ledger::LedgerEntry],
    profile_name: &str,
    repo_id: &str,
    active_mrs: Option<&[crate::sync::SyncMrJson]>,
    active_claims: Option<&[crate::status::ActiveClaimSnapshot]>,
) -> AutomaticWorktreeSets {
    let dispatch_prefixes = [format!("gah/{repo_id}-"), format!("gah/exp/{repo_id}-")];
    let published = ledger_entries
        .iter()
        .filter(|entry| entry.profile == profile_name && entry.repo_id == repo_id)
        .filter(|entry| entry.mr_created)
        .filter_map(|entry| Some((entry.branch.as_deref()?, entry.work_id.as_deref()?)))
        .filter(|(branch, _)| {
            dispatch_prefixes
                .iter()
                .any(|prefix| branch.starts_with(prefix))
        })
        .collect::<Vec<_>>();
    let active_branches = active_mrs.map(|mrs| {
        mrs.iter()
            .map(|mr| mr.branch.as_str())
            .collect::<HashSet<_>>()
    });

    let mut sets = AutomaticWorktreeSets::default();
    match active_claims {
        Some(claims) => {
            let live_work_ids = claims
                .iter()
                .map(|claim| crate::work_claim::normalize_work_identity(&claim.work_id))
                .collect::<HashSet<_>>();
            sets.protected.extend(
                published
                    .iter()
                    .filter(|(_, work_id)| {
                        live_work_ids.contains(&crate::work_claim::normalize_work_identity(work_id))
                    })
                    .map(|(branch, _)| worktree_name_for_branch(branch)),
            );
        }
        None => {
            // Claim state is part of the same snapshot. If it was unreadable,
            // retain every published dispatch worktree rather than guessing
            // that none has a live owner.
            sets.protected.extend(
                published
                    .iter()
                    .map(|(branch, _)| worktree_name_for_branch(branch)),
            );
        }
    }

    let Some(active_branches) = active_branches else {
        // Absence is terminal evidence only when the active-MR observation
        // completed successfully.
        return sets;
    };
    sets.done.extend(
        published
            .iter()
            .filter(|(branch, _)| !active_branches.contains(branch))
            .map(|(branch, _)| worktree_name_for_branch(branch)),
    );
    sets.abandoned_open.extend(
        published
            .iter()
            .filter(|(branch, _)| active_branches.contains(branch))
            .map(|(branch, _)| worktree_name_for_branch(branch))
            .filter(|name| !sets.protected.contains(name)),
    );
    sets
}

fn prune_profile(
    cfg: &GahConfig,
    name: &str,
    profile: &Profile,
    older_than_days: Option<u64>,
    dry_run: bool,
    announce: bool,
    observed: Option<&AutomaticWorktreeSets>,
) -> Result<()> {
    // CLI --older-than overrides the per-profile retention window.
    let retention = older_than_days.unwrap_or_else(|| profile.effective_prune_older_than_days());
    let cutoff = SystemTime::now()
        .checked_sub(Duration::from_secs(retention.saturating_mul(86_400)))
        .unwrap_or(SystemTime::UNIX_EPOCH);
    if announce {
        println!("[{name}] retention={retention}d");
    }
    prune_sessions(profile, cutoff, dry_run)?;
    crate::build_cache::prune_inactive(&profile.artifact_root, dry_run)?;
    let provider_done;
    let empty = HashSet::new();
    let (done, abandoned_open, protected) = if let Some(observed) = observed {
        (
            &observed.done,
            &observed.abandoned_open,
            &observed.protected,
        )
    } else if announce {
        provider_done = done_worktree_names(profile);
        (&provider_done, &empty, &empty)
    } else {
        (&empty, &empty, &empty)
    };
    prune_worktrees(
        cfg,
        profile,
        cutoff,
        dry_run,
        done,
        abandoned_open,
        protected,
    )?;
    // Remote branch deletion still requires explicit full provider history;
    // recurring maintenance only reuses the controller observation above.
    if announce {
        prune_remote_gah_branches(profile, dry_run)?;
    }
    Ok(())
}

/// Deletes the remote branch for any MERGED/CLOSED_UNMERGED PR/MR whose
/// branch matches gah's own dispatch naming convention (`gah/...` --
/// `format!("gah/{}-{}", profile.repo_id, ts)` in dispatch/workflows).
/// Scoped to that prefix deliberately: this must never touch a
/// human-authored branch just because its PR happened to merge. GitHub/
/// GitLab's own "delete branch on merge" doesn't always fire (e.g. `gh pr
/// merge --admin` merges outside the normal UI flow), which is how ~280
/// stale branches accumulated on this repo before this existed.
fn prune_remote_gah_branches(profile: &Profile, dry_run: bool) -> Result<()> {
    let mrs = match sync::fetch_mrs(profile) {
        Ok(mrs) => mrs,
        Err(_) => return Ok(()), // best-effort, matches done_worktree_names
    };
    let push_url = profile.push_url()?;
    let pat = profile.pat();
    let repo_path = Path::new(&profile.local_path);
    for (branch, class) in remote_gah_branches_to_delete(&mrs) {
        if dry_run {
            println!("  would delete remote branch {branch} ({class})");
            continue;
        }
        match crate::worktree::delete_remote_branch(repo_path, branch, &push_url, &pat) {
            Ok(()) => println!("  deleted remote branch {branch} ({class})"),
            Err(err) => println!("  failed to delete remote branch {branch}: {err}"),
        }
    }
    Ok(())
}

/// Pure subset of `prune_remote_gah_branches`: which branches are safe to
/// delete on the remote, and why. Scoped to gah's own dispatch naming
/// convention (`gah/...`) deliberately -- this must never touch a
/// human-authored branch just because its PR happened to merge.
pub(crate) fn remote_gah_branches_to_delete(mrs: &[SyncMr]) -> Vec<(&str, &'static str)> {
    mrs.iter()
        .filter(|mr| mr.branch.starts_with("gah/"))
        .filter_map(|mr| match sync::classify(mr) {
            class @ ("MERGED" | "CLOSED_UNMERGED") => Some((mr.branch.as_str(), class)),
            _ => None,
        })
        .collect()
}

/// Resolve either one named profile or every configured profile, sorted.
/// Shared with anything that needs "operate on this profile, or all of
/// them" instead of a hardcoded host-local list (e.g. `gah watchdog-check`).
pub(crate) fn selected_profiles<'a>(
    cfg: &'a GahConfig,
    profile_name: Option<&str>,
) -> Result<Vec<(String, &'a Profile)>> {
    if let Some(name) = profile_name {
        return Ok(vec![(name.to_string(), config::get_profile(cfg, name)?)]);
    }
    let mut profiles: Vec<_> = cfg.profiles.iter().map(|(k, v)| (k.clone(), v)).collect();
    profiles.sort_by(|a, b| a.0.cmp(&b.0));
    Ok(profiles)
}

/// Map a PR/MR branch name to the on-disk worktree directory name. Mirrors
/// `worktree::create` / `worktree::create_existing`, which call
/// `worktree_base.join(branch.replace('/', "-"))`. Pure and testable.
pub(crate) fn worktree_name_for_branch(branch: &str) -> String {
    branch.replace('/', "-")
}

/// Returns the set of worktree directory names that correspond to branches
/// whose PR/MR is MERGED or CLOSED_UNMERGED. These worktrees are safe to prune
/// immediately (they are already terminal upstream), regardless of the
/// retention window. Best-effort: any fetch error yields an empty set so pruning
/// never blocks on transient provider/network failure.
fn done_worktree_names(profile: &Profile) -> HashSet<String> {
    match sync::fetch_mrs(profile) {
        Ok(mrs) => done_worktree_names_from_mrs(&mrs),
        Err(_) => HashSet::new(),
    }
}

/// Pure subset of `done_worktree_names`: maps a list of fetched PRs/MRs to the
/// set of on-disk worktree names that are safe to prune immediately.
pub(crate) fn done_worktree_names_from_mrs(mrs: &[SyncMr]) -> HashSet<String> {
    let mut done = HashSet::new();
    for mr in mrs {
        let class = sync::classify(mr);
        if class == "MERGED" || class == "CLOSED_UNMERGED" {
            // Worktree directory names are the branch name with '/' replaced by '-'
            // (see worktree::create / worktree::create_existing). The prune prefix
            // filter already scopes results to this profile's `gah-{repo_id}-` /
            // `gah-exp-{repo_id}-` names, so the bare transformed branch is enough.
            done.insert(worktree_name_for_branch(&mr.branch));
        }
    }
    done
}

fn prune_sessions(profile: &Profile, cutoff: SystemTime, dry_run: bool) -> Result<()> {
    let root = Path::new(&profile.artifact_root).join("sessions");
    if !root.exists() {
        println!("  sessions: none");
        return Ok(());
    }
    for entry in fs::read_dir(&root)? {
        let entry = entry?;
        let path = entry.path();
        if !is_older_than(&path, cutoff) {
            continue;
        }
        if dry_run {
            println!("  would remove session {}", path.display());
        } else if path.is_dir() {
            fs::remove_dir_all(&path)?;
            println!("  removed session {}", path.display());
        } else {
            fs::remove_file(&path)?;
            println!("  removed file {}", path.display());
        }
    }
    Ok(())
}

fn prune_worktrees(
    cfg: &GahConfig,
    profile: &Profile,
    cutoff: SystemTime,
    dry_run: bool,
    done: &HashSet<String>,
    abandoned_open: &HashSet<String>,
    protected: &HashSet<String>,
) -> Result<()> {
    if cfg.defaults.worktree_base.trim().is_empty() {
        println!("  worktrees: skipped (no defaults.worktree_base)");
        return Ok(());
    }
    let root = Path::new(&cfg.defaults.worktree_base);
    if !root.exists() {
        println!("  worktrees: none");
        return Ok(());
    }
    let prefixes = [
        format!("gah-{}-", profile.repo_id),
        format!("gah-exp-{}-", profile.repo_id),
        // Chat-session worktrees (apps/server chatSessions.ts). Same base,
        // same age+clean rules: an idle-but-clean chat worktree is safe to
        // reclaim because the session's durable state (log + branch) survives
        // and the worktree rematerializes on resume; a dirty one is retained
        // for the session's own archive-with-patch step, never force-removed.
        format!("gah-chat-{}-", profile.repo_id),
    ];
    for entry in fs::read_dir(root)? {
        let entry = entry?;
        let path = entry.path();
        let name = entry.file_name().to_string_lossy().to_string();
        if !prefixes.iter().any(|prefix| name.starts_with(prefix)) {
            continue;
        }
        if protected.contains(name.as_str()) {
            continue;
        }
        // A worktree tied to a merged/closed PR/MR is safe to prune
        // immediately, even if it is newer than the retention cutoff. Local
        // branch topology is deliberately not enough: a fresh worktree has a
        // default-branch tip until its agent makes the first commit, so using
        // that signal would race an in-flight manual dispatch.
        let is_done = done.contains(name.as_str());
        let is_abandoned_open = abandoned_open.contains(name.as_str());
        let is_old = is_older_than(&path, cutoff);
        if !is_done && !is_abandoned_open && !is_old {
            continue;
        }
        // Never force-remove a dirty worktree. A terminal PR can still have
        // local, unpublished recovery work, and a failed worker can leave a
        // useful patch behind. This is intentionally fail-closed: if Git
        // cannot establish cleanliness, retain the worktree for inspection.
        if !worktree_is_clean(&path) {
            println!("  retained dirty worktree {}", path.display());
            continue;
        }
        if dry_run {
            println!(
                "  would remove worktree {}",
                if is_done {
                    format!("{} (MERGED/CLOSED)", path.display())
                } else if is_abandoned_open {
                    format!("{} (OPEN/ABANDONED)", path.display())
                } else {
                    path.display().to_string()
                }
            );
        } else {
            let git_result = crate::worktree::git(
                &["worktree", "remove", "-f", path.to_str().unwrap_or("")],
                Path::new(&profile.local_path),
            );
            // `git worktree remove` fails outright ("is not a working tree")
            // once git's own admin metadata for this worktree is already
            // gone -- e.g. left behind by a prior interrupted/partial
            // removal. Previously that failure was silently discarded and
            // "removed" printed anyway, so the directory (and its disk
            // usage) never actually went away despite being logged as
            // pruned on every run. Fall back to a direct removal whenever
            // the directory is still there, since `worktree_is_clean`
            // already confirmed above it's safe to delete.
            if path.exists() {
                if let Err(err) = fs::remove_dir_all(&path) {
                    println!(
                        "  failed to remove worktree {}: {}{}",
                        path.display(),
                        err,
                        git_result
                            .err()
                            .map(|e| format!(" (git worktree remove also failed: {e})"))
                            .unwrap_or_default()
                    );
                    continue;
                }
            }
            println!(
                "  removed worktree {}",
                if is_done {
                    format!("{} (MERGED/CLOSED)", path.display())
                } else if is_abandoned_open {
                    format!("{} (OPEN/ABANDONED)", path.display())
                } else {
                    path.display().to_string()
                }
            );
        }
    }
    if !dry_run {
        let _ = crate::worktree::git(&["worktree", "prune"], Path::new(&profile.local_path));
    }
    Ok(())
}

fn worktree_is_clean(worktree: &Path) -> bool {
    Command::new("git")
        .args(["status", "--porcelain"])
        .current_dir(worktree)
        .output()
        .map(|out| out.status.success() && out.stdout.is_empty())
        .unwrap_or(false)
}

fn is_older_than(path: &PathBuf, cutoff: SystemTime) -> bool {
    fs::metadata(path)
        .and_then(|m| m.modified())
        .map(|modified| modified <= cutoff)
        .unwrap_or(false)
}

#[cfg(test)]
mod tests {
    use super::{
        automatic_worktree_sets, done_worktree_names_from_mrs, is_older_than, prune_worktrees,
        remote_gah_branches_to_delete, worktree_name_for_branch,
    };
    use crate::config::{tests::test_profile_for_notifications, Defaults, GahConfig};
    use crate::sync::SyncMr;
    use std::collections::{HashMap, HashSet};
    use std::fs;
    use std::path::PathBuf;
    use std::time::{Duration, SystemTime};

    /// Regression for the "removed worktree" log lying about success: a
    /// worktree directory whose git admin metadata is already gone (e.g.
    /// left behind by a prior interrupted removal) makes `git worktree
    /// remove -f` fail with "is not a working tree" every single run. The
    /// old code discarded that error and printed "removed" unconditionally,
    /// so the directory (and its disk usage) never actually went away.
    #[test]
    fn prune_worktrees_falls_back_to_direct_removal_when_git_no_longer_tracks_it() {
        let worktree_base = tempfile::tempdir().unwrap();
        let repo_id = "repo";
        let stale = worktree_base.path().join(format!("gah-{repo_id}-orphaned"));
        fs::create_dir_all(&stale).unwrap();
        std::process::Command::new("git")
            .args(["init", "--quiet"])
            .current_dir(&stale)
            .output()
            .unwrap();
        // Old enough to be eligible for pruning, and not registered as a
        // linked worktree of any repo -- reproducing the real orphaned state.
        std::process::Command::new("touch")
            .args(["-t", "202401010000", stale.to_str().unwrap()])
            .output()
            .unwrap();

        let local_path = tempfile::tempdir().unwrap();
        std::process::Command::new("git")
            .args(["init", "--quiet"])
            .current_dir(local_path.path())
            .output()
            .unwrap();

        let cfg = GahConfig {
            defaults: Defaults {
                worktree_base: worktree_base.path().to_string_lossy().to_string(),
                ..Default::default()
            },
            profiles: HashMap::new(),
            context: Default::default(),
        };
        let mut profile = test_profile_for_notifications();
        profile.repo_id = repo_id.to_string();
        profile.local_path = local_path.path().to_string_lossy().to_string();

        let cutoff = SystemTime::now()
            .checked_sub(Duration::from_secs(86_400))
            .unwrap();
        prune_worktrees(
            &cfg,
            &profile,
            cutoff,
            false,
            &HashSet::new(),
            &HashSet::new(),
            &HashSet::new(),
        )
        .unwrap();

        assert!(
            !stale.exists(),
            "orphaned worktree directory should be removed even when `git worktree remove` fails"
        );
    }

    #[test]
    fn older_than_uses_file_mtime() {
        let tmp = tempfile::tempdir().unwrap();
        let path = PathBuf::from(tmp.path()).join("old");
        fs::write(&path, "x").unwrap();
        std::process::Command::new("touch")
            .args(["-t", "202401010000", path.to_str().unwrap()])
            .output()
            .unwrap();
        assert!(is_older_than(
            &path,
            SystemTime::now()
                .checked_sub(Duration::from_secs(86_400))
                .unwrap()
        ));
    }

    /// Chat-session worktrees share the worktree base and the gah-chat-<repo>-
    /// naming prefix (apps/server chatSessions.ts); the same age+clean prune
    /// that reclaims dispatch worktrees must reclaim idle chat ones too --
    /// and must never touch a directory that doesn't carry the prefix.
    #[test]
    fn prune_worktrees_reclaims_idle_chat_worktrees_and_ignores_foreign_dirs() {
        let worktree_base = tempfile::tempdir().unwrap();
        let repo_id = "repo";
        let chat = worktree_base
            .path()
            .join(format!("gah-chat-{repo_id}-abc123"));
        let foreign = worktree_base.path().join("someone-elses-worktree");
        for dir in [&chat, &foreign] {
            fs::create_dir_all(dir).unwrap();
            std::process::Command::new("git")
                .args(["init", "--quiet"])
                .current_dir(dir)
                .output()
                .unwrap();
            std::process::Command::new("touch")
                .args(["-t", "202401010000", dir.to_str().unwrap()])
                .output()
                .unwrap();
        }

        let local_path = tempfile::tempdir().unwrap();
        std::process::Command::new("git")
            .args(["init", "--quiet"])
            .current_dir(local_path.path())
            .output()
            .unwrap();

        let cfg = GahConfig {
            defaults: Defaults {
                worktree_base: worktree_base.path().to_string_lossy().to_string(),
                ..Default::default()
            },
            profiles: HashMap::new(),
            context: Default::default(),
        };
        let mut profile = test_profile_for_notifications();
        profile.repo_id = repo_id.to_string();
        profile.local_path = local_path.path().to_string_lossy().to_string();

        let cutoff = SystemTime::now()
            .checked_sub(Duration::from_secs(86_400))
            .unwrap();
        prune_worktrees(
            &cfg,
            &profile,
            cutoff,
            false,
            &HashSet::new(),
            &HashSet::new(),
            &HashSet::new(),
        )
        .unwrap();

        assert!(!chat.exists(), "idle chat worktree should be reclaimed");
        assert!(
            foreign.exists(),
            "a directory without a gah prefix must never be touched"
        );
    }

    #[test]
    fn worktree_name_mirrors_branch_slash_replacement() {
        assert_eq!(worktree_name_for_branch("gah/real-123"), "gah-real-123");
        assert_eq!(worktree_name_for_branch("feature/fix"), "feature-fix");
    }

    fn published_entry(branch: &str, work_id: &str) -> crate::ledger::LedgerEntry {
        let mut profile = test_profile_for_notifications();
        profile.repo_id = "real".into();
        let mut entry = crate::ledger::LedgerEntry::new(
            "real", &profile, "codex", "improve", work_id, None, None,
        );
        entry.work_id = Some(work_id.into());
        entry.branch = Some(branch.into());
        entry.mr_created = true;
        entry
    }

    fn active_mr(branch: &str, work_id: &str) -> crate::sync::SyncMrJson {
        let mut mr = mr(branch, false, Some("open"));
        mr.work_id = Some(work_id.into());
        crate::sync::sync_mr_to_json(&mr, None, &Default::default())
    }

    #[test]
    fn automatic_sets_protect_every_published_worktree_for_a_live_claim() {
        let entries = vec![
            published_entry("gah/real-prior", "#915"),
            published_entry("gah/real-active", "TICKET-915"),
        ];
        let mrs = vec![active_mr("gah/real-active", "#915")];
        let claims = vec![crate::status::ActiveClaimSnapshot {
            work_id: "#915".into(),
            pid: std::process::id(),
            scope: "real@real".into(),
            hostname: "test".into(),
            claimed_at: "2099-01-01T00:00:00Z".into(),
            age_seconds: 0,
        }];

        let sets = automatic_worktree_sets(&entries, "real", "real", Some(&mrs), Some(&claims));

        assert_eq!(
            sets.protected,
            HashSet::from(["gah-real-active".into(), "gah-real-prior".into()])
        );
        assert!(sets.done.contains("gah-real-prior"));
        assert!(sets.abandoned_open.is_empty());
    }

    #[test]
    fn automatic_sets_do_not_infer_state_from_an_incomplete_mr_observation() {
        let entries = vec![published_entry("gah/real-915", "#915")];

        let sets = automatic_worktree_sets(&entries, "real", "real", None, Some(&[]));

        assert!(sets.done.is_empty());
        assert!(sets.abandoned_open.is_empty());
    }

    #[test]
    fn automatic_sets_fail_closed_when_claim_observation_is_incomplete() {
        let entries = vec![published_entry("gah/real-915", "#915")];
        let mrs = vec![active_mr("gah/real-915", "#915")];

        let sets = automatic_worktree_sets(&entries, "real", "real", Some(&mrs), None);

        assert_eq!(sets.protected, HashSet::from(["gah-real-915".into()]));
        assert!(sets.abandoned_open.is_empty());
    }

    #[test]
    fn automatic_sets_never_classify_the_manager_chat_namespace() {
        let entries = vec![published_entry("gah/chat/real-session", "#915")];
        let mrs = vec![active_mr("gah/chat/real-session", "#915")];

        let sets = automatic_worktree_sets(&entries, "real", "real", Some(&mrs), None);

        assert!(sets.done.is_empty());
        assert!(sets.abandoned_open.is_empty());
        assert!(sets.protected.is_empty());
    }

    fn mr(branch: &str, merged: bool, state: Option<&str>) -> SyncMr {
        SyncMr {
            title: String::new(),
            body: None,
            branch: branch.to_string(),
            labels: Vec::new(),
            url: None,
            id: None,
            state: state.map(|s| s.to_string()),
            draft: false,
            source_sha: None,
            merge_commit_sha: None,
            merge_status: None,
            merged,
            updated_at: None,
            merged_at: None,
            ci_failed: false,
            ci_passed: false,
            ci_pending: false,
            work_id: None,
        }
    }

    #[test]
    fn done_set_covers_merged_and_closed_unmerged_only() {
        let mrs = vec![
            mr("gah/real-1", true, None),            // MERGED
            mr("gah/real-2", false, Some("closed")), // CLOSED_UNMERGED
            mr("gah/real-3", false, Some("open")),   // open -> not done
            mr("gah/real-4", false, None),           // open -> not done
        ];
        let done = done_worktree_names_from_mrs(&mrs);
        assert!(done.contains("gah-real-1"));
        assert!(done.contains("gah-real-2"));
        assert!(!done.contains("gah-real-3"));
        assert!(!done.contains("gah-real-4"));
    }

    #[test]
    fn remote_delete_covers_merged_and_closed_unmerged_gah_branches_only() {
        let mrs = vec![
            mr("gah/real-1", true, None),            // MERGED, gah/ -> delete
            mr("gah/real-2", false, Some("closed")), // CLOSED_UNMERGED, gah/ -> delete
            mr("gah/real-3", false, Some("open")),   // open, gah/ -> not terminal
            mr("gah/real-4", false, None),           // open, gah/ -> not terminal
        ];
        let to_delete = remote_gah_branches_to_delete(&mrs);
        assert_eq!(
            to_delete,
            vec![("gah/real-1", "MERGED"), ("gah/real-2", "CLOSED_UNMERGED")]
        );
    }

    #[test]
    fn remote_delete_never_touches_a_human_authored_branch_even_when_merged() {
        // A human's own merged PR must never be auto-deleted just because
        // it shares a repo with gah's dispatch branches -- only the exact
        // `gah/` naming convention is eligible.
        let mrs = vec![
            mr("feat/my-manual-work", true, None),
            mr("chore/cleanup", false, Some("closed")),
            mr("fix/something", true, None),
        ];
        assert!(remote_gah_branches_to_delete(&mrs).is_empty());
    }

    #[test]
    fn remote_delete_prefix_check_is_exact_not_substring() {
        // "not-gah/foo" contains "gah/" as a substring but does not START
        // with it -- must not match.
        let mrs = vec![mr("not-gah/foo", true, None)];
        assert!(remote_gah_branches_to_delete(&mrs).is_empty());
    }
}
