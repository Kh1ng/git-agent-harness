// Command execution for controller-facing `gah` subcommands (ticket #408).

use anyhow::Result;

use crate::cli::args::{HoldCommands, RouteApprovalCommands};
use crate::{config, controller as controller_runtime, events, ledger, runner, status, sync};

pub struct LoopArgs {
    pub profile: String,
    pub config_path: Option<String>,
    pub json: bool,
    pub once: bool,
    pub parallel: usize,
    pub skip_validation_gate: bool,
}

pub struct EventsArgs {
    pub config_path: Option<String>,
    pub profile: Option<String>,
    pub json: bool,
    pub since: String,
}

pub struct StatusArgs {
    pub profile: Option<String>,
    pub role: bool,
    pub light: bool,
    pub json: bool,
    pub config_path: Option<String>,
}

pub struct SyncArgs {
    pub profile: String,
    pub config_path: Option<String>,
    pub json: bool,
}

pub fn run_hold(command: HoldCommands) -> Result<()> {
    match command {
        HoldCommands::Set {
            profile,
            work_id,
            reason,
            config_path,
        } => {
            let cfg = config::load(config_path.as_deref())?;
            let prof = config::get_profile(&cfg, &profile)?;
            let entry = ledger::LedgerEntry::new_review_hold(&profile, prof, &work_id, reason);
            let path = ledger::append(&cfg, &entry)?;
            println!(
                "Review hold set for work_id '{}' on profile '{}' ({})",
                work_id,
                profile,
                path.display()
            );
        }
        HoldCommands::Clear {
            profile,
            work_id,
            config_path,
        } => {
            let cfg = config::load(config_path.as_deref())?;
            let prof = config::get_profile(&cfg, &profile)?;
            let entry = ledger::LedgerEntry::new_review_hold_release(&profile, prof, &work_id);
            let path = ledger::append(&cfg, &entry)?;
            println!(
                "Review hold cleared for work_id '{}' on profile '{}' ({})",
                work_id,
                profile,
                path.display()
            );
        }
    }
    Ok(())
}

pub fn run_route_approval(command: RouteApprovalCommands) -> Result<()> {
    let (profile, work_id, backend, instance, model, config_path, granted) = match command {
        RouteApprovalCommands::List {
            profile,
            config_path,
        } => {
            let cfg = config::load(config_path.as_deref())?;
            let prof = config::get_profile(&cfg, &profile)?;
            let rows = ledger::paid_route_approvals_from_entries(
                &ledger::read_entries(&cfg)?,
                &profile,
                prof,
                &cfg.defaults,
            );
            println!("{}", serde_json::to_string(&rows)?);
            return Ok(());
        }
        RouteApprovalCommands::Grant {
            profile,
            work_id,
            backend,
            instance,
            model,
            config_path,
        } => (
            profile,
            work_id,
            backend,
            instance,
            model,
            config_path,
            true,
        ),
        RouteApprovalCommands::Revoke {
            profile,
            work_id,
            backend,
            instance,
            model,
            config_path,
        } => (
            profile,
            work_id,
            backend,
            instance,
            model,
            config_path,
            false,
        ),
    };
    let cfg = config::load(config_path.as_deref())?;
    let prof = config::get_profile(&cfg, &profile)?;
    // Existing grants remain revocable after an instance is removed from config.
    if let Some(instance_name) = instance.as_deref().filter(|_| granted) {
        let routing = prof.effective_routing(&cfg.defaults);
        let declared = routing
            .backend_instances
            .get(instance_name)
            .ok_or_else(|| {
                anyhow::anyhow!(
                    "unknown backend instance '{instance_name}' for profile '{profile}'"
                )
            })?;
        let logical_backend = declared
            .logical_backend
            .as_deref()
            .unwrap_or(declared.runner_kind.as_str());
        if logical_backend != backend {
            anyhow::bail!(
                "backend instance '{}' belongs to logical backend '{}', not '{}'",
                instance_name,
                logical_backend,
                backend
            );
        }
    }
    let entry = ledger::LedgerEntry::new_paid_route_approval_for_instance(
        &profile,
        prof,
        &work_id,
        &backend,
        instance.as_deref(),
        model.as_deref(),
        granted,
    );
    let path = ledger::append(&cfg, &entry)?;
    println!(
        "Paid route approval {} for work_id '{}' on {}{}/{} ({})",
        if granted { "granted" } else { "revoked" },
        work_id,
        backend,
        instance
            .as_deref()
            .map(|instance| format!(" [{instance}]"))
            .unwrap_or_default(),
        model.as_deref().unwrap_or("default"),
        path.display()
    );
    Ok(())
}

pub fn run_loop(args: LoopArgs) -> Result<()> {
    runner::install_shutdown_handler()?;
    let cfg = config::load(args.config_path.as_deref())?;
    let resolved_config_path = config::resolve_config_path(args.config_path.as_deref());

    // Issue #881: advisory only -- unset registry_central_url skips this
    // entirely. See crate::fleet_preflight module docs for why it can't
    // (and doesn't try to) guarantee two nodes never dispatch the same
    // profile concurrently.
    if let Some(central_url) = &cfg.defaults.registry_central_url {
        let token = std::env::var("COORDINATOR_TOKEN").ok();
        // Issue #944: make sure this node is registered (and thus
        // claim-eligible) before starting work. Advisory only -- a failed
        // registration warns loudly but never blocks startup. Transport mode
        // and secret reference are env-driven like the rest of the fleet
        // config (COORDINATOR_TOKEN, GAH_COORDINATOR_INSECURE_TLS).
        let transport_mode = std::env::var("GAH_REGISTRY_TRANSPORT_MODE")
            .unwrap_or_else(|_| "trusted_lan".to_string());
        let secret_ref = std::env::var("GAH_REGISTRY_SECRET_REF")
            .unwrap_or_else(|_| "env:COORDINATOR_TOKEN".to_string());
        crate::node_register::register_advisory(
            central_url,
            &transport_mode,
            &secret_ref,
            token.as_deref(),
            args.config_path.as_deref(),
        );
        crate::fleet_preflight::check(
            &crate::fleet_preflight::CurlFleetQuerier,
            central_url,
            &args.profile,
            token.as_deref(),
            cfg.defaults.registry_preflight_mode,
        )?;
    }
    let parallel = controller_runtime::loop_parallel_argument(
        args.once,
        args.parallel,
        config::get_profile(&cfg, &args.profile)?.max_parallel_workers() as usize,
    );
    if args.once {
        // `--once` still does real execution (spawns backends, claims tickets,
        // writes ledger entries) so it must coordinate via the same profile
        // lock as the daemon (`gah loop` with no `--once`).
        let _lock = controller_runtime::acquire_profile_lock(&args.profile, &resolved_config_path)?;
        // Issue #761: a bounded `--once` iteration skips the periodic
        // availability/quota probes (see controller/runtime/probe.rs) --
        // finishes long before their intervals would matter anyway, and
        // several test fixtures spawn `gah loop --once` against a fake
        // codex/vibe binary that reacts to any invocation.
        controller_runtime::run_once(
            &cfg,
            &args.profile,
            args.json,
            parallel,
            args.skip_validation_gate,
            false,
        )?;
    } else {
        controller_runtime::run_loop(
            &cfg,
            &args.profile,
            args.json,
            parallel,
            args.skip_validation_gate,
            &resolved_config_path,
        )?;
    }
    Ok(())
}

pub fn run_events(args: EventsArgs) -> Result<()> {
    let cfg = config::load(args.config_path.as_deref())?;
    events::run(&cfg, &args.since, args.profile.as_deref(), args.json)?;
    Ok(())
}

pub fn run_status(args: StatusArgs) -> Result<()> {
    let cfg = config::load(args.config_path.as_deref())?;
    if args.role {
        let node = crate::node_role::NodeRoleStatus::resolve(&cfg.defaults)?;
        if args.json {
            println!("{}", serde_json::to_string_pretty(&node)?);
        } else {
            println!(
                "Role: {:?}\nCentral URL: {}",
                node.role,
                node.central_url.as_deref().unwrap_or("(unset)")
            );
        }
    } else {
        status::run(
            &cfg,
            args.profile
                .as_deref()
                .ok_or_else(|| anyhow::anyhow!("--profile is required unless --role is used"))?,
            args.json,
            args.light,
        )?;
    }
    Ok(())
}

pub fn run_sync(args: SyncArgs) -> Result<()> {
    let cfg = config::load(args.config_path.as_deref())?;
    sync::run(&cfg, &args.profile, args.json)?;
    Ok(())
}
