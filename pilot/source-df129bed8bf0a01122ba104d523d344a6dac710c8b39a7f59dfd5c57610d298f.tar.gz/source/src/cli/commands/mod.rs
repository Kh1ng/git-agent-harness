// Command-execution modules for individual `gah` subcommand families
// (ticket #407). Parser definitions stay in `crate::cli::args`; each module
// here owns only the dispatch body that used to live inline in
// `crate::cli::run`.

pub mod availability;
pub mod candidates;
pub mod claims;
pub mod cloud;
pub mod config;
pub mod controller;
pub mod credentials;
pub mod dispatch;
pub mod doctor;
pub mod external_approval;
pub mod init;
pub mod ledger;
pub mod network;
pub mod node;
pub mod pm;
pub mod policy;
pub mod price_guard;
pub mod profile;
pub mod prompt_policies;
pub mod prune;
pub mod quota;
pub mod report;
pub mod routing_candidates;
pub mod server;
pub mod setup;
pub mod skills;
pub mod telemetry;
pub mod tui;
pub mod update;
pub mod watchdog;

pub mod route;

pub mod memory;
