use crate::cli::args::CloudCommands;
use crate::cloud::{
    client::{private_write, CloudClient, Device},
    worker::{run_worker, WorkerOptions},
};
use anyhow::{bail, Result};
use serde_json::json;

pub fn run(command: CloudCommands) -> Result<()> {
    if let CloudCommands::Worker {
        device_file,
        config_path,
        profiles,
        backend,
        max_concurrent,
        memory_budget_mb,
        reserve_memory_mb,
        allow_inference_relay,
        inference_models,
        once,
    } = command
    {
        return run_worker(WorkerOptions {
            device: Device::load(&device_file)?,
            config_path,
            profiles,
            backend,
            max_concurrent,
            memory_budget_mb,
            reserve_memory_mb,
            allow_inference_relay,
            inference_models,
            once,
        });
    }
    let config_path = match &command {
        CloudCommands::Enroll { config_path, .. } => config_path.as_deref(),
        _ => None,
    };
    let cfg = crate::config::load(config_path)?;
    let client = CloudClient::from_config(&cfg.defaults.orchestration)?;
    match command {
        CloudCommands::Login { email, password } => {
            use crate::setup::wizard::Prompter;
            let email = match email {
                Some(value) => value,
                None => crate::setup::TerminalPrompter.text("Email address", None)?,
            };
            let email = email.trim();
            let valid = email.split_once('@').is_some_and(|(name, domain)| {
                !name.is_empty() && !domain.is_empty() && !domain.contains('@')
            }) && !email.chars().any(char::is_whitespace);
            if !valid {
                bail!("Enter your account's email address, not the YOUR_EMAIL placeholder.");
            }
            if password {
                let secret = crate::setup::TerminalPrompter.secret("Password")?;
                client.login_password(email, &secret)?;
            } else {
                client.login(email)?;
            }
            println!("Cloud session saved privately.");
        }
        CloudCommands::Share {
            node,
            member,
            resource,
            permission,
            models,
        } => {
            if resource == "inference" && (permission != "use" || models.is_empty()) {
                bail!("inference sharing requires --permission use and --models");
            }
            let base = json!({"p_workspace_id":client.workspace,"p_node_id":node,
                "p_user_id":member.to_string(),"p_permission":permission});
            if resource == "compute" {
                client.user_rpc("set_cloud_node_grant", base)?;
                client.user_rpc(
                    "manage_cloud_node",
                    json!({"p_workspace_id":client.workspace,
                    "p_node_id":node,"p_action":"selected"}),
                )?;
            } else {
                client.user_rpc("set_cloud_inference_grant", base)?;
                client.user_rpc(
                    "configure_cloud_inference",
                    json!({"p_workspace_id":client.workspace,
                    "p_node_id":node,"p_scope":"selected","p_models":models}),
                )?;
            }
            println!("Selected member sharing configured.");
        }
        CloudCommands::Enroll {
            node,
            name,
            profiles,
            inference_models,
            max_concurrent,
            memory_budget_mb,
            device_file,
            ..
        } => {
            for profile in &profiles {
                if !cfg.profiles.contains_key(profile) {
                    bail!("profile is not configured on this worker");
                }
            }
            if device_file.exists() {
                bail!("device file already exists; revoke the old device before replacing it");
            }
            client.user_rpc("register_cloud_node",json!({"p_workspace_id":client.workspace,"p_node_id":node,"p_display_name":name,
                "p_advertised_url":"http://127.0.0.1","p_version":env!("CARGO_PKG_VERSION"),"p_schema_digest":"cloud-worker-v1",
                "p_transport_mode":"authenticated_remote","p_profiles":profiles}))?;
            if !inference_models.is_empty() {
                client.user_rpc(
                    "configure_cloud_inference",
                    json!({"p_workspace_id":client.workspace,"p_node_id":node,
                    "p_scope":"private","p_models":inference_models}),
                )?;
            }
            let mut value = client.user_rpc(
                "enroll_cloud_device",
                json!({"p_workspace_id":client.workspace,"p_node_id":node,
                "p_max_concurrent":max_concurrent,"p_memory_budget_mb":memory_budget_mb}),
            )?;
            value["origin"] = json!(client.origin);
            value["key"] = json!(client.key);
            private_write(&device_file, &serde_json::to_vec(&value)?)?;
            println!(
                "Device enrolled. Keep its credential file private; choose sharing in the console."
            );
        }
        CloudCommands::Submit {
            node,
            profile,
            mode,
            target,
            memory_mb,
            idempotency_key,
            inference_node,
            inference_model,
        } => {
            let result=client.user_rpc("enqueue_cloud_work",json!({"p_workspace_id":client.workspace,"p_node_id":node,
                "p_profile":profile,"p_mode":mode,"p_target":target,"p_memory_mb":memory_mb,"p_idempotency_key":idempotency_key.to_string(),
                "p_inference_node_id":inference_node,"p_inference_model":inference_model}))?;
            println!(
                "{}",
                result
                    .as_str()
                    .ok_or_else(|| anyhow::anyhow!("invalid work identifier"))?
            );
        }
        CloudCommands::Cancel { work } => {
            client.user_rpc(
                "cancel_cloud_work",
                json!({"p_workspace_id":client.workspace,"p_work_id":work.to_string()}),
            )?;
            println!("Cancellation requested.");
        }
        CloudCommands::RevokeDevice { device } => {
            client.user_rpc(
                "revoke_cloud_device",
                json!({"p_workspace_id":client.workspace,"p_device_id":device.to_string()}),
            )?;
            println!("Device revoked.");
        }
        CloudCommands::Worker { .. } => unreachable!(),
    }
    Ok(())
}
