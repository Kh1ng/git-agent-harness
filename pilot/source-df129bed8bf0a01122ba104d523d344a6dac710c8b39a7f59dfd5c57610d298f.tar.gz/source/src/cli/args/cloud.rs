use clap::Subcommand;
use std::path::PathBuf;

#[derive(Subcommand)]
pub enum CloudCommands {
    /// Sign in to an existing account with an email code or a hidden password prompt.
    Login {
        #[arg(long)]
        /// Account email. When omitted, prompt for it before requesting a password or code.
        email: Option<String>,
        /// Prompt for a password instead of sending an email code. Never pass the password as an argument.
        #[arg(long)]
        password: bool,
    },
    /// Share an owned resource with a specific workspace member.
    Share {
        #[arg(long)]
        node: String,
        #[arg(long)]
        member: uuid::Uuid,
        #[arg(long, default_value = "compute", value_parser = ["compute", "inference"])]
        resource: String,
        #[arg(long, default_value = "use", value_parser = ["use", "manage"])]
        permission: String,
        #[arg(long, value_delimiter = ',')]
        models: Vec<String>,
    },
    /// Register owned profiles and save a revocable node credential in a private file.
    Enroll {
        #[arg(long)]
        node: String,
        #[arg(long)]
        name: String,
        #[arg(long, value_delimiter = ',')]
        profiles: Vec<String>,
        #[arg(long, value_delimiter = ',')]
        inference_models: Vec<String>,
        #[arg(long, default_value_t = 1, value_parser=clap::value_parser!(u32).range(1..=32))]
        max_concurrent: u32,
        #[arg(long, default_value_t = 4096, value_parser=clap::value_parser!(u32).range(64..=1048576))]
        memory_budget_mb: u32,
        #[arg(long)]
        device_file: PathBuf,
        #[arg(long = "config")]
        config_path: Option<String>,
    },
    /// Poll Supabase for authorized compute jobs and optional inference requests.
    Worker {
        #[arg(long)]
        device_file: PathBuf,
        #[arg(long = "config")]
        config_path: Option<String>,
        #[arg(long, value_delimiter = ',')]
        profiles: Vec<String>,
        #[arg(long, default_value = "opencode")]
        backend: String,
        #[arg(long, default_value_t = 1, value_parser=clap::value_parser!(u32).range(1..=32))]
        max_concurrent: u32,
        #[arg(long, default_value_t = 4096, value_parser=clap::value_parser!(u32).range(64..=1048576))]
        memory_budget_mb: u32,
        #[arg(long, default_value_t = 1024)]
        reserve_memory_mb: u32,
        /// Explicitly let compute jobs use separately authorized remote inference.
        #[arg(long)]
        allow_inference_relay: bool,
        /// Serve only these models using owner-configured provider environment values.
        #[arg(long, value_delimiter = ',')]
        inference_models: Vec<String>,
        /// Poll once, finish accepted jobs, then exit.
        #[arg(long)]
        once: bool,
    },
    /// Submit an issue or merge-request number; no shell or environment payloads.
    Submit {
        #[arg(long)]
        node: String,
        #[arg(long)]
        profile: String,
        #[arg(long, value_parser=["improve", "review"])]
        mode: String,
        #[arg(long, value_parser=clap::value_parser!(u32).range(1..=2147483647))]
        target: u32,
        #[arg(long, default_value_t = 4096, value_parser=clap::value_parser!(u32).range(64..=1048576))]
        memory_mb: u32,
        /// Reuse the same UUID when retrying a submission.
        #[arg(long)]
        idempotency_key: uuid::Uuid,
        #[arg(long, requires = "inference_model")]
        inference_node: Option<String>,
        #[arg(long, requires = "inference_node")]
        inference_model: Option<String>,
    },
    Cancel {
        #[arg(long)]
        work: uuid::Uuid,
    },
    RevokeDevice {
        #[arg(long)]
        device: uuid::Uuid,
    },
}
