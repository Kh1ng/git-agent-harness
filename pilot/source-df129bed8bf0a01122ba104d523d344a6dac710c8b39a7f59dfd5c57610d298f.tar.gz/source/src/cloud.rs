//! Optional Supabase directory, execution, and inference coordination.
//! Local registration is advisory; authorized cloud execution fails closed.

use anyhow::{bail, Result};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use url::Url;

pub mod client;
mod proxy;
pub mod worker;

/// A shared-inference job cannot escalate to the compute node's native provider.
pub(crate) fn validate_relay_identity(
    identity: &crate::execution_identity::ExecutionIdentity,
    config: &str,
) -> anyhow::Result<()> {
    let config: serde_json::Value = serde_json::from_str(config)
        .map_err(|_| anyhow::anyhow!("invalid cloud relay configuration"))?;
    let model = config["model"]
        .as_str()
        .filter(|model| model.starts_with("gah-cloud/"))
        .ok_or_else(|| anyhow::anyhow!("invalid cloud relay model"))?;
    if identity.runner_kind != "opencode" || identity.effective_model.as_deref() != Some(model) {
        anyhow::bail!("cloud inference cannot substitute a backend or model");
    }
    Ok(())
}

#[derive(Debug, Default, Clone, Copy, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "kebab-case")]
pub enum OrchestrationMode {
    #[default]
    Local,
    Hosted,
    SelfHosted,
}

#[derive(Debug, Default, Clone, Deserialize, Serialize)]
#[serde(default, deny_unknown_fields)]
pub struct OrchestrationConfig {
    pub mode: OrchestrationMode,
    pub workspace_id: Option<String>,
}

fn endpoint(raw: &str, mode: OrchestrationMode) -> Result<Url> {
    let url = Url::parse(raw).map_err(|_| anyhow::anyhow!("invalid cloud URL"))?;
    let local = mode == OrchestrationMode::SelfHosted
        && matches!(url.host_str(), Some("localhost" | "127.0.0.1" | "[::1]"));
    if !(url.scheme() == "https" || local && url.scheme() == "http")
        || !url.username().is_empty()
        || url.password().is_some()
        || url.query().is_some()
        || url.fragment().is_some()
        || url.path() != "/"
        || url.host_str().is_none()
    {
        bail!("cloud URL must be an HTTPS origin; self-hosted loopback may use HTTP");
    }
    Ok(url)
}

fn required(env: &impl Fn(&str) -> Option<String>, name: &str) -> Result<String> {
    env(name)
        .filter(|value| !value.trim().is_empty() && !value.contains(['\r', '\n']))
        .ok_or_else(|| anyhow::anyhow!("missing or invalid {name}"))
}

/// Builds the allowlisted cloud record. Local secret references never leave the node.
fn registration(workspace: &str, local: &Value) -> Value {
    serde_json::json!({
        "p_workspace_id": workspace,
        "p_node_id": local["node_id"],
        "p_display_name": local["display_name"],
        "p_advertised_url": local["advertised_url"],
        "p_version": local["version"],
        "p_schema_digest": local["schema_digest"],
        "p_transport_mode": local["transport_mode"],
        "p_profiles": local["profiles"],
    })
}

/// Syncs using the account's JWT, never a service-role credential.
/// The database, not the client mode, decides whether payment is required.
fn sync_with(
    config: &OrchestrationConfig,
    local: &Value,
    env: &impl Fn(&str) -> Option<String>,
    post: &impl Fn(&str, &str, Option<&str>, &str) -> Result<crate::curl_http::CurlResponse>,
) -> Result<()> {
    let mode = match env("GAH_ORCHESTRATION_MODE") {
        Some(value) => match value.as_str() {
            "local" => OrchestrationMode::Local,
            "hosted" => OrchestrationMode::Hosted,
            "self-hosted" => OrchestrationMode::SelfHosted,
            _ => bail!("unknown GAH_ORCHESTRATION_MODE"),
        },
        None => config.mode,
    };
    if mode == OrchestrationMode::Local {
        return Ok(());
    }
    let workspace = env("GAH_SUPABASE_WORKSPACE_ID")
        .or_else(|| config.workspace_id.clone())
        .ok_or_else(|| anyhow::anyhow!("missing cloud workspace ID"))?;
    uuid::Uuid::parse_str(&workspace).map_err(|_| anyhow::anyhow!("invalid cloud workspace ID"))?;
    let base = endpoint(&required(env, "GAH_SUPABASE_URL")?, mode)?;
    let key = required(env, "GAH_SUPABASE_ANON_KEY")?;
    if key.starts_with("sb_secret_") {
        bail!("cloud registration requires a publishable or anon key");
    }
    let token = required(env, "GAH_SUPABASE_ACCESS_TOKEN")?;
    let response = post(
        base.join("rest/v1/rpc/register_cloud_node")?.as_str(),
        &registration(&workspace, local).to_string(),
        Some(&token),
        &key,
    )?;
    if response.status != 200 && response.status != 204 {
        bail!("cloud registration rejected (HTTP {})", response.status);
    }
    Ok(())
}

/// Attempts cloud sync after local success, reporting only secret-safe warnings.
pub fn sync_advisory(config: &OrchestrationConfig, local: &Value) {
    if let Err(error) = sync_with(
        config,
        local,
        &|name| {
            std::env::var(name).ok().or_else(|| {
                (name == "GAH_SUPABASE_ACCESS_TOKEN")
                    .then(|| {
                        client::CloudClient::from_config(config)
                            .and_then(|client| client.user_token())
                            .ok()
                    })
                    .flatten()
            })
        },
        &crate::curl_http::cloud_request,
    ) {
        eprintln!("gah: cloud directory sync failed ({error}); local registration remains active");
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::cell::RefCell;

    #[test]
    fn modes_are_explicit_and_default_local() {
        assert_eq!(
            toml::from_str::<OrchestrationConfig>("").unwrap().mode,
            OrchestrationMode::Local
        );
        assert!(toml::from_str::<OrchestrationConfig>("mode = 'unknown'").is_err());
        assert!(toml::from_str::<OrchestrationConfig>("service_role_key = 'secret'").is_err());
        sync_with(
            &OrchestrationConfig::default(),
            &Value::Null,
            &|_| None,
            &|_, _, _, _| panic!("local mode must not access network"),
        )
        .unwrap();
    }

    #[test]
    fn endpoints_require_tls_and_reject_embedded_secrets() {
        for raw in [
            "http://example.com",
            "https://user:secret@example.com",
            "https://example.com?key=secret",
            "https://example.com/path",
            "file:///etc/passwd",
        ] {
            assert!(endpoint(raw, OrchestrationMode::SelfHosted).is_err());
        }
        assert!(endpoint("http://127.0.0.1:54321", OrchestrationMode::SelfHosted).is_ok());
        assert!(endpoint("http://127.0.0.1:54321", OrchestrationMode::Hosted).is_err());
        assert!(endpoint("https://example.com", OrchestrationMode::Hosted).is_ok());
    }

    #[test]
    fn relay_jobs_cannot_escalate_to_native_credentials_or_another_model() {
        use crate::execution_identity::ExecutionIdentity;
        let config = r#"{"model":"gah-cloud/pilot"}"#;
        let identity = |backend: &str, model: &str| {
            ExecutionIdentity::legacy_candidate(backend, Some(model), None::<String>)
        };
        assert!(validate_relay_identity(&identity("opencode", "gah-cloud/pilot"), config).is_ok());
        assert!(validate_relay_identity(&identity("claude", "gah-cloud/pilot"), config).is_err());
        assert!(validate_relay_identity(&identity("opencode", "local/model"), config).is_err());
        assert!(validate_relay_identity(&identity("opencode", "gah-cloud/other"), config).is_err());
        assert!(validate_relay_identity(&identity("opencode", "gah-cloud/pilot"), "{}").is_err());
    }

    #[test]
    fn authenticated_rpc_omits_secrets_and_redacts_rejection() {
        let calls = RefCell::new(Vec::new());
        let config = OrchestrationConfig {
            mode: OrchestrationMode::Hosted,
            workspace_id: Some("00000000-0000-0000-0000-000000000001".into()),
        };
        let env = |name: &str| match name {
            "GAH_SUPABASE_URL" => Some("https://example.com".into()),
            "GAH_SUPABASE_ANON_KEY" => Some("public-key".into()),
            "GAH_SUPABASE_ACCESS_TOKEN" => Some("user-jwt".into()),
            "GAH_SUPABASE_SERVICE_ROLE_KEY" => panic!("worker must never read service key"),
            _ => None,
        };
        let local =
            serde_json::json!({"node_id": "test", "secret_ref": "env:SECRET", "token": "private"});
        let error = sync_with(&config, &local, &env, &|url, body, token, key| {
            calls.borrow_mut().push((
                url.to_owned(),
                body.to_owned(),
                token.unwrap().to_owned(),
                key.to_owned(),
            ));
            Ok(crate::curl_http::CurlResponse {
                status: 403,
                body: b"sensitive response".to_vec(),
            })
        })
        .unwrap_err();
        assert_eq!(error.to_string(), "cloud registration rejected (HTTP 403)");
        let calls = calls.borrow();
        assert_eq!(
            calls[0].0,
            "https://example.com/rest/v1/rpc/register_cloud_node"
        );
        assert_eq!(calls[0].2, "user-jwt");
        assert!(!calls[0].1.contains("secret_ref"));
        assert!(!calls[0].1.contains("private"));
    }
}
