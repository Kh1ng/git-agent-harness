//! Candidate construction and deterministic routing-policy ordering.

use super::diagnostics::{describe_candidate, DiagnosticCandidate};
use super::types::{CandidateIdentity, RoutingRuntimeState, TaskRoutingContext};
use crate::config::{Defaults, Profile, RoutingPolicy, TaskRoutingRule};
use crate::execution_identity::ExecutionIdentity;
use crate::job_kind::{JobFamily, JobKind};
use crate::quota::{self, PaceBand};
use std::cmp::Ordering;
use std::collections::HashSet;

#[cfg(test)]
mod tests;

#[derive(Debug, Clone)]
pub(super) struct RouteCandidate {
    pub(super) identity: ExecutionIdentity,
    pub(super) priority: i32,
    pub(super) included_in_quota: bool,
    pub(super) marginal_cost_usd: Option<f64>,
    pub(super) quota_usage_percent: Option<f64>,
    pub(super) quota_days_remaining: Option<f64>,
    pub(super) requires_approval: bool,
    pub(super) original_order: usize,
}

impl DiagnosticCandidate for RouteCandidate {
    fn backend(&self) -> &str {
        &self.identity.logical_backend
    }

    fn backend_instance(&self) -> Option<&str> {
        Some(&self.identity.backend_instance)
    }

    fn reviewer_identity_backend(&self) -> &str {
        if self.identity.explicit_instance {
            &self.identity.backend_instance
        } else {
            &self.identity.logical_backend
        }
    }

    fn model(&self) -> Option<&str> {
        self.identity.effective_model.as_deref()
    }

    fn quota_pool(&self) -> Option<&str> {
        self.identity.quota_pool.as_deref()
    }

    fn priority(&self) -> i32 {
        self.priority
    }

    fn included_in_quota(&self) -> bool {
        self.included_in_quota
    }

    fn marginal_cost_usd(&self) -> Option<f64> {
        self.marginal_cost_usd
    }

    fn quota_usage_percent(&self) -> Option<f64> {
        self.quota_usage_percent
    }

    fn quota_days_remaining(&self) -> Option<f64> {
        self.quota_days_remaining
    }

    fn requires_approval(&self) -> bool {
        self.requires_approval
    }

    fn original_order(&self) -> usize {
        self.original_order
    }
}

#[derive(Debug, Clone)]
pub(super) struct ReorderDecision {
    pub(super) selected_over: Vec<String>,
    pub(super) escalated: bool,
    pub(super) outcome_aware: bool,
}

pub(super) fn append_reorder_reason(
    mut base: String,
    selected: &RouteCandidate,
    reorder: &ReorderDecision,
    pacing: &crate::quota::PacingConfig,
) -> String {
    if reorder.escalated {
        base.push_str("; escalated to stronger model after genuine agent failure, selected ");
    } else if reorder.outcome_aware {
        base.push_str("; outcome-aware reviewer history selected ");
    } else {
        base.push_str("; cost-aware reorder selected ");
    }
    base.push_str(&describe_candidate(selected, pacing));
    base.push_str(" over ");
    base.push_str(&reorder.selected_over.join(", "));
    base
}

pub(super) fn auto_candidates(
    routing: &RoutingPolicy,
    mode: &str,
    primary: &RouteCandidate,
) -> Vec<RouteCandidate> {
    let mut candidates = vec![primary.clone()];
    if is_review_mode(mode) {
        if let Some(weak_backend) = review_fallback_backend_name(routing) {
            let weak_model = review_fallback_model(routing)
                .map(str::to_string)
                .or_else(|| primary.identity.effective_model.clone());
            let quota_pool = routing.find_quota_pool(mode, weak_backend, weak_model.as_deref());
            candidates.push(RouteCandidate {
                identity: ExecutionIdentity::legacy_candidate(weak_backend, weak_model, quota_pool),
                priority: 0,
                included_in_quota: false,
                marginal_cost_usd: None,
                quota_usage_percent: None,
                quota_days_remaining: None,
                requires_approval: false,
                original_order: candidates.len(),
            });
        }
    }
    extend_default_backend_candidates(routing, &mut candidates, mode);
    dedupe_candidates(candidates)
}

fn extend_default_backend_candidates(
    routing: &RoutingPolicy,
    candidates: &mut Vec<RouteCandidate>,
    mode: &str,
) {
    for backend in mode_backend_preference(mode) {
        let quota_pool = routing.find_quota_pool(mode, backend, None);
        candidates.push(RouteCandidate {
            identity: ExecutionIdentity::legacy_candidate(backend, None::<String>, quota_pool),
            priority: 0,
            included_in_quota: false,
            marginal_cost_usd: None,
            quota_usage_percent: None,
            quota_days_remaining: None,
            requires_approval: false,
            original_order: candidates.len(),
        });
    }
}

fn dedupe_candidates(candidates: Vec<RouteCandidate>) -> Vec<RouteCandidate> {
    let mut seen = HashSet::new();
    let mut out = Vec::new();
    for candidate in candidates {
        let identity = CandidateIdentity::from_execution_identity(&candidate.identity);
        let key = format!(
            "{}\u{0}{}",
            identity.backend,
            identity.model.as_deref().unwrap_or("")
        );
        if seen.insert(key) {
            out.push(candidate);
        }
    }
    out
}

/// TICKET-089 AC7/8: only a genuine agent-capability failure justifies
/// escalating toward a stronger (likely costlier) model. Harness/environment
/// failures, backend errors (which cover the AGY/Codex/Claude quota and auth
/// classifications from TICKET-102/107), and unknown/human-blocked states
/// must not -- a stronger model doesn't fix a broken auth token.
pub(super) fn is_genuine_agent_failure(last_failure_class: Option<&str>) -> bool {
    matches!(
        last_failure_class,
        Some("agent_failure") | Some("agent_no_progress") | Some("validation_failure")
    )
}

pub(super) fn order_candidates(
    profile: &Profile,
    candidates: Vec<RouteCandidate>,
    escalate: bool,
    runtime: &RoutingRuntimeState,
    mode: &str,
) -> (Vec<RouteCandidate>, Option<ReorderDecision>) {
    let mut candidates = with_original_order(candidates);
    let has_review_history = is_review_mode(mode) && !runtime.reviewer_outcomes.is_empty();
    if !escalate
        && !is_load_balanced_mode(mode)
        && !has_review_history
        && !candidates.iter().any(RouteCandidate::has_cost_policy)
    {
        return (candidates, None);
    }

    let original = candidates.clone();
    let now = time::OffsetDateTime::now_utc();
    let records = if is_load_balanced_mode(mode) {
        crate::quota_store::load_account_observations()
    } else {
        vec![]
    };
    let capacities = candidates
        .iter()
        .map(|candidate| {
            (
                CandidateIdentity::from_execution_identity(&candidate.identity),
                super::subscription::capacity(&candidate.identity, &records, now),
            )
        })
        .collect::<std::collections::HashMap<_, _>>();
    candidates.sort_by(|left, right| {
        compare_candidates(
            left,
            right,
            &profile.pacing,
            escalate,
            runtime,
            mode,
            &capacities,
        )
    });
    let before_history = candidates
        .iter()
        .map(|candidate| CandidateIdentity::from_execution_identity(&candidate.identity))
        .collect::<Vec<_>>();
    if is_review_mode(mode) && !escalate {
        apply_reviewer_history(&mut candidates, runtime, &profile.pacing);
    }
    let outcome_aware = before_history
        != candidates
            .iter()
            .map(|candidate| CandidateIdentity::from_execution_identity(&candidate.identity))
            .collect::<Vec<_>>();

    let Some(selected) = candidates.first() else {
        return (candidates, None);
    };
    let selected_over = original
        .iter()
        .take_while(|candidate| !same_destination(candidate, selected))
        .map(|candidate| describe_candidate(candidate, &profile.pacing))
        .collect::<Vec<_>>();

    let reorder = if selected_over.is_empty() && !outcome_aware {
        None
    } else {
        Some(ReorderDecision {
            selected_over,
            escalated: escalate,
            outcome_aware,
        })
    };
    (candidates, reorder)
}

const REVIEWER_MIN_OUTCOME_SAMPLES: u64 = 5;

fn apply_reviewer_history(
    candidates: &mut [RouteCandidate],
    runtime: &RoutingRuntimeState,
    pacing: &crate::quota::PacingConfig,
) {
    let configured_last = candidates
        .iter()
        .map(|candidate| candidate.original_order)
        .max()
        .unwrap_or_default();
    let mut start = 0;
    while start < candidates.len() {
        let priority = candidates[start].priority;
        let economic = economic_rank(&candidates[start], pacing);
        let approval = candidates[start].requires_approval;
        let end = candidates[start..]
            .iter()
            .position(|candidate| {
                candidate.priority != priority
                    || economic_rank(candidate, pacing) != economic
                    || candidate.requires_approval != approval
            })
            .map_or(candidates.len(), |offset| start + offset);
        let positions = (start..end)
            .filter(|index| {
                !approval && !glm_is_configured_last(&candidates[*index], configured_last)
            })
            .collect::<Vec<_>>();
        if positions.len() > 1
            && positions.iter().all(|index| {
                reviewer_metrics(&candidates[*index], runtime)
                    .is_some_and(|metrics| metrics.outcome_samples >= REVIEWER_MIN_OUTCOME_SAMPLES)
            })
        {
            let mut ranked = positions
                .iter()
                .map(|index| candidates[*index].clone())
                .collect::<Vec<_>>();
            ranked.sort_by(|left, right| compare_reviewer_history(left, right, runtime));
            for (index, candidate) in positions.into_iter().zip(ranked) {
                candidates[index] = candidate;
            }
        }
        start = end;
    }
}

fn glm_is_configured_last(candidate: &RouteCandidate, configured_last: usize) -> bool {
    candidate.original_order == configured_last
        && format!(
            "{} {}",
            candidate.identity.logical_backend,
            candidate
                .identity
                .effective_model
                .as_deref()
                .unwrap_or_default()
        )
        .to_ascii_lowercase()
        .contains("glm")
}

fn reviewer_metrics<'a>(
    candidate: &RouteCandidate,
    runtime: &'a RoutingRuntimeState,
) -> Option<&'a super::types::ReviewerOutcomeMetrics> {
    runtime
        .reviewer_outcomes
        .get(&CandidateIdentity::from_execution_identity(
            &candidate.identity,
        ))
}

fn compare_reviewer_history(
    left: &RouteCandidate,
    right: &RouteCandidate,
    runtime: &RoutingRuntimeState,
) -> Ordering {
    let left_metrics = reviewer_metrics(left, runtime).expect("sample-gated reviewer metrics");
    let right_metrics = reviewer_metrics(right, runtime).expect("sample-gated reviewer metrics");
    (right_metrics.successful_outcomes * left_metrics.outcome_samples)
        .cmp(&(left_metrics.successful_outcomes * right_metrics.outcome_samples))
        .then_with(|| {
            (left_metrics.false_approvals * right_metrics.outcome_samples)
                .cmp(&(right_metrics.false_approvals * left_metrics.outcome_samples))
        })
        .then_with(|| {
            compare_when_both_known(
                left_metrics.average_api_cost_usd(),
                right_metrics.average_api_cost_usd(),
            )
        })
        .then_with(|| {
            compare_when_both_known(
                left_metrics.average_latency_seconds(),
                right_metrics.average_latency_seconds(),
            )
        })
        .then_with(|| left.original_order.cmp(&right.original_order))
}

fn compare_when_both_known(left: Option<f64>, right: Option<f64>) -> Ordering {
    match (left, right) {
        (Some(left), Some(right)) => left.total_cmp(&right),
        _ => Ordering::Equal,
    }
}

fn is_strong_candidate(candidate: &RouteCandidate) -> bool {
    candidate
        .identity
        .effective_model
        .as_deref()
        .map(crate::ledger::is_strong_model)
        .unwrap_or(true)
}

/// Load-balancing by recent execution count is scoped to implementation
/// dispatch (improve/fix/experiment) -- the only modes `routing_runtime_state`
/// (src/dispatch.rs) collects `recent_runs` for with balancing in mind.
/// Applying it to review/pm candidate ordering too would silently reorder
/// those pools by usage, contradicting the deterministic-order guarantee
/// review's own escalation chain relies on. Also reused wherever the same
/// improve/fix/experiment grouping was independently re-matched.
fn is_load_balanced_mode(mode: &str) -> bool {
    JobKind::parse(mode).map(|kind| kind.family()) == Ok(JobFamily::ImproveLike)
}

fn is_review_mode(mode: &str) -> bool {
    JobKind::parse(mode).map(|kind| kind.family()) == Ok(JobFamily::Review)
}

fn compare_candidates(
    left: &RouteCandidate,
    right: &RouteCandidate,
    pacing: &crate::quota::PacingConfig,
    escalate: bool,
    runtime: &RoutingRuntimeState,
    mode: &str,
    capacities: &std::collections::HashMap<
        CandidateIdentity,
        super::subscription::SubscriptionCapacity,
    >,
) -> Ordering {
    right
        .priority
        .cmp(&left.priority)
        .then_with(|| {
            if is_load_balanced_mode(mode) {
                super::subscription::compare(
                    &left.identity,
                    &capacities[&CandidateIdentity::from_execution_identity(&left.identity)],
                    &right.identity,
                    &capacities[&CandidateIdentity::from_execution_identity(&right.identity)],
                )
            } else {
                Ordering::Equal
            }
        })
        .then_with(|| {
            if is_load_balanced_mode(mode) {
                candidate_run_count(left, runtime).cmp(&candidate_run_count(right, runtime))
            } else {
                Ordering::Equal
            }
        })
        .then_with(|| {
            if escalate {
                is_strong_candidate(right).cmp(&is_strong_candidate(left))
            } else {
                Ordering::Equal
            }
        })
        .then_with(|| economic_rank(left, pacing).cmp(&economic_rank(right, pacing)))
        .then_with(|| compare_optional_f64(left.marginal_cost_usd, right.marginal_cost_usd))
        .then_with(|| left.original_order.cmp(&right.original_order))
}

fn candidate_run_count(candidate: &RouteCandidate, runtime: &RoutingRuntimeState) -> u64 {
    runtime
        .recent_runs
        .get(&CandidateIdentity::from_execution_identity(
            &candidate.identity,
        ))
        .copied()
        .unwrap_or(0)
}

fn economic_rank(candidate: &RouteCandidate, pacing: &crate::quota::PacingConfig) -> u8 {
    if !candidate.included_in_quota {
        return 1;
    }

    match quota::quota_pace(
        candidate.quota_usage_percent,
        candidate.quota_days_remaining,
        pacing,
    )
    .unwrap_or(PaceBand::HardConserve)
    {
        PaceBand::AggressiveBurn | PaceBand::MildBurn | PaceBand::Normal => 0,
        PaceBand::Conserve => 2,
        PaceBand::HardConserve => 3,
    }
}

fn compare_optional_f64(left: Option<f64>, right: Option<f64>) -> Ordering {
    match (left, right) {
        (Some(left), Some(right)) => left.total_cmp(&right),
        (Some(_), None) => Ordering::Less,
        (None, Some(_)) => Ordering::Greater,
        (None, None) => Ordering::Equal,
    }
}

fn with_original_order(candidates: Vec<RouteCandidate>) -> Vec<RouteCandidate> {
    candidates
        .into_iter()
        .enumerate()
        .map(|(idx, mut candidate)| {
            candidate.original_order = idx;
            candidate
        })
        .collect()
}

pub(super) fn policy_backend_model<'a>(
    policy: &'a RoutingPolicy,
    mode: &str,
) -> (Option<&'a str>, Option<&'a str>) {
    match JobKind::parse(mode).map(|kind| kind.family()) {
        Ok(JobFamily::Pm) => (
            policy
                .pm_backend
                .as_deref()
                .or(policy.default_backend.as_deref()),
            policy
                .pm_model
                .as_deref()
                .or(policy.default_model.as_deref()),
        ),
        Ok(JobFamily::Review) => (
            policy
                .strong_review_backend
                .as_deref()
                .or(policy.review_backend.as_deref())
                .or(policy.default_backend.as_deref()),
            policy
                .strong_review_model
                .as_deref()
                .or(policy.review_model.as_deref())
                .or(policy.default_model.as_deref()),
        ),
        Ok(JobFamily::ImproveLike) => (
            policy
                .improve_backend
                .as_deref()
                .or(policy.default_backend.as_deref()),
            policy
                .improve_model
                .as_deref()
                .or(policy.default_model.as_deref()),
        ),
        _ => (
            policy.default_backend.as_deref(),
            policy.default_model.as_deref(),
        ),
    }
}

pub(super) fn policy_candidates(policy: &RoutingPolicy, mode: &str) -> Option<Vec<RouteCandidate>> {
    let raw = match JobKind::parse(mode).map(|kind| kind.family()) {
        Ok(JobFamily::Pm) => policy.pm_candidates.as_ref(),
        Ok(JobFamily::Review) => policy.review_candidates.as_ref(),
        Ok(JobFamily::ImproveLike) => policy.improve_candidates.as_ref(),
        _ => None,
    };
    raw.map(|list| route_candidates(policy, list))
}

/// Return true when this exact backend/model is configured as an
/// operator-approved-only route anywhere applicable to `mode`.
///
/// Internal escalation uses the explicit-route path. That path must retain
/// the same paid-route guard as normal auto routing instead of rebuilding the
/// candidate with `requires_approval = false`.
pub(super) fn configured_route_requires_approval(
    routing: &RoutingPolicy,
    mode: &str,
    backend: &str,
    model: Option<&str>,
) -> bool {
    let matches = |candidate: &crate::config::CandidateConfig| {
        candidate.backend == backend && candidate.model.as_deref() == model
    };

    let mode_candidates_require_approval = match JobKind::parse(mode).map(|kind| kind.family()) {
        Ok(JobFamily::Pm) => routing.pm_candidates.as_ref(),
        Ok(JobFamily::Review) => routing.review_candidates.as_ref(),
        Ok(JobFamily::ImproveLike) => routing.improve_candidates.as_ref(),
        _ => None,
    }
    .is_some_and(|candidates| {
        candidates
            .iter()
            .any(|candidate| matches(candidate) && candidate.requires_approval)
    });

    mode_candidates_require_approval
        || (is_review_mode(mode)
            && routing
                .escalatory_reviewers
                .iter()
                .any(|candidate| matches(candidate) && candidate.requires_approval))
        || (is_load_balanced_mode(mode)
            && routing.task_routing_rules.iter().any(|rule| {
                (rule.modes.is_empty()
                    || rule
                        .modes
                        .iter()
                        .any(|configured_mode| configured_mode.eq_ignore_ascii_case(mode)))
                    && rule
                        .candidates
                        .iter()
                        .any(|candidate| matches(candidate) && candidate.requires_approval)
            }))
}

pub(super) fn task_rule_candidates(
    routing: &RoutingPolicy,
    mode: &str,
    task: Option<TaskRoutingContext<'_>>,
) -> Option<(usize, Vec<RouteCandidate>)> {
    if !is_load_balanced_mode(mode) {
        return None;
    }
    let task = task?;
    routing
        .task_routing_rules
        .iter()
        .enumerate()
        .find(|(_, rule)| task_rule_matches(rule, mode, task))
        .map(|(idx, rule)| (idx, route_candidates(routing, &rule.candidates)))
}

fn task_rule_matches(rule: &TaskRoutingRule, mode: &str, task: TaskRoutingContext<'_>) -> bool {
    task_rule_dimension_matches(&rule.modes, Some(mode))
        && task_rule_dimension_matches(&rule.task_classes, task.task_class)
        && task_rule_dimension_matches(&rule.difficulties, task.difficulty)
        && task_rule_dimension_matches(&rule.risks, task.risk)
}

fn task_rule_dimension_matches(values: &[String], value: Option<&str>) -> bool {
    values.is_empty()
        || value.is_some_and(|value| values.iter().any(|item| item.eq_ignore_ascii_case(value)))
}

fn route_candidates(
    routing: &RoutingPolicy,
    raw: &[crate::config::CandidateConfig],
) -> Vec<RouteCandidate> {
    let now = time::OffsetDateTime::now_utc();
    // Issue #761: an operator opting a candidate into quota-aware pacing
    // (included_in_quota: true) previously had no way to get live
    // quota_usage_percent/quota_days_remaining short of hand-typing static
    // numbers into config.toml that immediately go stale -- quota_pace()
    // silently no-ops (PaceBand::Normal) on missing data, so this candidate
    // never actually got paced. Loaded lazily: only candidates that are
    // opted in AND missing an explicit config value ever touch the store.
    let mut quota_observations: Option<Vec<crate::quota_store::QuotaObservationRecord>> = None;
    raw.iter()
        .enumerate()
        .map(|(idx, c)| {
            let identity = routing.execution_identity_for_candidate(c);
            let (live_usage_percent, live_days_remaining) = if c.included_in_quota
                && (c.quota_usage_percent.is_none() || c.quota_days_remaining.is_none())
            {
                let observations = quota_observations
                    .get_or_insert_with(crate::quota_store::load_account_observations);
                live_quota_pacing_inputs(observations, &identity, now)
            } else {
                (None, None)
            };
            RouteCandidate {
                identity,
                priority: c.priority,
                included_in_quota: c.included_in_quota,
                marginal_cost_usd: c.marginal_cost_usd,
                // An explicit config value is an operator override and
                // always wins; live data only fills a genuine gap.
                quota_usage_percent: c.quota_usage_percent.or(live_usage_percent),
                quota_days_remaining: c.quota_days_remaining.or(live_days_remaining),
                requires_approval: c.requires_approval,
                original_order: idx,
            }
        })
        .collect()
}

/// Derives quota_pace()'s two inputs from the latest quota_store observation
/// for this exact identity. `quota_used_percent` is preferred; falls back to
/// deriving it from `quota_remaining_percent` when only that was recorded
/// (vibe's Mistral Admin spend-limit reading uses remaining, not used).
/// `quota_days_remaining` is quota_pace()'s "days until the quota window
/// resets", derived from `quota_reset_at` relative to `now`. Only fresh,
/// current weekly budgets belong in the weekly pacing formula.
fn live_quota_pacing_inputs(
    observations: &[crate::quota_store::QuotaObservationRecord],
    identity: &ExecutionIdentity,
    now: time::OffsetDateTime,
) -> (Option<f64>, Option<f64>) {
    let Some(record) = crate::quota_store::latest_windows_for_identity(observations, identity)
        .into_iter()
        .filter(|record| {
            matches!(
                record.quota_window.as_deref(),
                Some("weekly" | "seven_day" | "seven-day" | "7d" | "10080m")
            )
        })
        .filter(|record| {
            record
                .observed_at
                .as_deref()
                .and_then(|observed| {
                    time::OffsetDateTime::parse(
                        observed,
                        &time::format_description::well_known::Rfc3339,
                    )
                    .ok()
                })
                .is_some_and(|observed| {
                    observed <= now && now - observed <= time::Duration::minutes(30)
                })
        })
        .filter(|record| {
            record
                .quota_reset_at
                .as_deref()
                .and_then(|reset| {
                    time::OffsetDateTime::parse(
                        reset,
                        &time::format_description::well_known::Rfc3339,
                    )
                    .ok()
                })
                .is_some_and(|reset| reset > now)
        })
        .max_by(|left, right| left.observed_at.cmp(&right.observed_at))
    else {
        return (None, None);
    };
    let usage_percent = record.quota_used_percent.or_else(|| {
        record
            .quota_remaining_percent
            .map(|remaining| (100.0 - remaining).clamp(0.0, 100.0))
    });
    let days_remaining = record
        .quota_reset_at
        .as_deref()
        .and_then(|reset_at| {
            time::OffsetDateTime::parse(reset_at, &time::format_description::well_known::Rfc3339)
                .ok()
        })
        .map(|reset_at| ((reset_at - now).as_seconds_f64() / 86_400.0).max(0.0));
    (usage_percent, days_remaining)
}

/// Recover the billing/quota metadata for an explicitly selected backend/model.
///
/// Billing identity does not change with dispatch mode. A model configured as
/// subscription-backed for implementation is still subscription-backed when an
/// operator directly dogfoods it as a reviewer. Prefer the current mode's
/// declaration, then search the remaining configured pools. This keeps direct
/// CLI dispatches from silently degrading to `standard`/unknown attribution.
pub(super) fn configured_route_candidate(
    routing: &RoutingPolicy,
    mode: &str,
    backend: &str,
    model: Option<&str>,
) -> Option<RouteCandidate> {
    let matches = |candidate: &&crate::config::CandidateConfig| {
        candidate.backend == backend && candidate.model.as_deref() == model
    };
    let mode_candidates = match JobKind::parse(mode).map(|kind| kind.family()) {
        Ok(JobFamily::Pm) => routing.pm_candidates.as_deref(),
        Ok(JobFamily::Review) => routing.review_candidates.as_deref(),
        Ok(JobFamily::ImproveLike) => routing.improve_candidates.as_deref(),
        _ => None,
    };

    let configured = mode_candidates
        .into_iter()
        .flatten()
        .find(matches)
        .or_else(|| {
            routing
                .pm_candidates
                .iter()
                .chain(routing.improve_candidates.iter())
                .chain(routing.review_candidates.iter())
                .flat_map(|candidates| candidates.iter())
                .find(matches)
        })
        .or_else(|| routing.routine_reviewer.iter().find(matches))
        .or_else(|| routing.escalatory_reviewers.iter().find(matches))
        .or_else(|| {
            routing
                .task_routing_rules
                .iter()
                .flat_map(|rule| rule.candidates.iter())
                .find(matches)
        })?;

    route_candidates(routing, std::slice::from_ref(configured)).pop()
}

impl RouteCandidate {
    pub(super) fn backend(&self) -> &str {
        &self.identity.logical_backend
    }

    pub(super) fn model(&self) -> Option<&str> {
        self.identity.effective_model.as_deref()
    }

    fn has_cost_policy(&self) -> bool {
        self.priority != 0
            || self.included_in_quota
            || self.marginal_cost_usd.is_some()
            || self.quota_usage_percent.is_some()
            || self.quota_days_remaining.is_some()
    }
}

pub(super) fn same_destination(left: &RouteCandidate, right: &RouteCandidate) -> bool {
    CandidateIdentity::from_execution_identity(&left.identity)
        == CandidateIdentity::from_execution_identity(&right.identity)
}

fn review_fallback_backend_name(routing: &RoutingPolicy) -> Option<&str> {
    // Issue #123: prefer the new ESCALATORY_REVIEW list; fall back to the
    // deprecated single `weak_review_backend` so legacy configs keep working.
    routing
        .escalatory_reviewers
        .first()
        .map(|c| c.backend.as_str())
        .or(routing.weak_review_backend.as_deref())
}

pub(super) fn review_fallback_backend<F>(
    defaults: &Defaults,
    profile: &Profile,
    backend_available: F,
) -> Option<String>
where
    F: Fn(&str) -> bool + Copy,
{
    review_fallback_backend_name(&profile.effective_routing(defaults))
        .map(str::to_string)
        .or_else(|| any_available_backend("review", backend_available))
}

pub(super) fn review_fallback_model(routing: &RoutingPolicy) -> Option<&str> {
    routing
        .escalatory_reviewers
        .first()
        .and_then(|c| c.model.as_deref())
        .or(routing.weak_review_model.as_deref())
}

pub(super) fn builtin_backend<F>(mode: &str, backend_available: F) -> String
where
    F: Fn(&str) -> bool + Copy,
{
    mode_backend_preference(mode)
        .into_iter()
        .find(|backend| backend_available(backend))
        .unwrap_or("openhands")
        .to_string()
}

pub(super) fn any_available_backend<F>(mode: &str, backend_available: F) -> Option<String>
where
    F: Fn(&str) -> bool + Copy,
{
    mode_backend_preference(mode)
        .into_iter()
        .find(|backend| backend_available(backend))
        .map(str::to_string)
}

fn mode_backend_preference(mode: &str) -> [&'static str; 3] {
    match JobKind::parse(mode).map(|kind| kind.family()) {
        Ok(JobFamily::Pm) | Ok(JobFamily::Review) => ["claude", "codex", "openhands"],
        _ => ["openhands", "codex", "claude"],
    }
}
