//! Rust-side client for the TDAI memory gateway's ticket-scoped recall
//! (issue #830: "shared long-term memory across all dispatch backends, not
//! just manager chat"). Mirrors `apps/server/src/managerChat/memoryGatewayClient.ts`'s
//! `recallForTicket`/`sessionKeyForTicket` -- session keys MUST match that
//! side exactly (`gah:worker:{project_key}:{ticket_id}`) or a repair/review
//! agent and manager chat land in different memory spaces for the same
//! ticket, defeating the point of a shared store.
//!
//! **Fail open, deliberately the opposite of manager-chat's policy.**
//! `memoryGatewayClient.ts`'s own doc comment says recall/capture
//! "hard-block the turn on failure (throw) rather than degrading silently"
//! for manager chat (issue #849) -- but that same file's `recallForTicket`
//! doc comment says wiring it into dispatch is "issue #830's scope, gated
//! on #878 landing first," where #878 is specifically about manager-chat's
//! hard-block being wrong for *its* use case. A dispatch attempt has a
//! human-approved ticket and existing verification gates regardless of
//! memory; the gateway being down must never block real work from
//! starting. Every function here returns `Option`/best-effort and logs
//! (never panics/bails) on any failure -- missing env config, unreachable
//! gateway, malformed response.
//!
//! HTTP calls shell out to `curl` (config via stdin, matching
//! `src/central_claims.rs`'s established pattern for keeping a bearer
//! token out of argv/ps) rather than adding a Rust HTTP client dependency
//! -- this codebase has none today, and the dispatch pipeline is
//! synchronous throughout.

use crate::node_role::NodeRole;
use anyhow::{Context, Result};
use serde::Deserialize;
use std::io::Write;
use std::process::{Command, Stdio};

const STATUS_MARKER: &str = "__GAH_MEMORY_GATEWAY_STATUS__:";
const DEFAULT_GATEWAY_URL: &str = "http://127.0.0.1:8420";
const RECALL_TIMEOUT_SECONDS: u32 = 10;

/// All GAH clients use the process key first, then the private gateway env file.
pub fn gateway_api_key(home: &std::path::Path) -> Result<Option<String>> {
    let key = std::env::var("TDAI_GATEWAY_API_KEY")
        .ok()
        .filter(|key| !key.is_empty())
        .or_else(|| {
            crate::installer::files::env_get(
                &home.join(".config/gah/tdai-gateway.env"),
                "TDAI_GATEWAY_API_KEY",
            )
        })
        .filter(|key| !key.is_empty());
    if let Some(key) = &key {
        crate::installer::files::check_value("TDAI_GATEWAY_API_KEY", key)?;
    }
    Ok(key)
}

pub trait MemoryGatewayTransport {
    /// Returns `(http_status, response_body)` on any completed HTTP
    /// exchange; `Err` only for a transport-level failure (can't connect,
    /// timeout, DNS).
    fn post(
        &self,
        url: &str,
        body: &str,
        token: Option<&str>,
        timeout_secs: u32,
    ) -> Result<(u16, Vec<u8>)>;
}

pub struct CurlMemoryGatewayTransport;

impl MemoryGatewayTransport for CurlMemoryGatewayTransport {
    fn post(
        &self,
        url: &str,
        body: &str,
        token: Option<&str>,
        timeout_secs: u32,
    ) -> Result<(u16, Vec<u8>)> {
        let mut cmd = Command::new("curl");
        cmd.args([
            "-sS",
            "--max-time",
            &timeout_secs.to_string(),
            "-K",
            "-",
            "-w",
            &format!("\n{STATUS_MARKER}%{{http_code}}\n"),
        ])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::null());
        crate::runner::process::arm_child_pdeathsig(&mut cmd);
        let mut child = cmd
            .spawn()
            .context("spawning curl for memory gateway call")?;
        if let Some(mut stdin) = child.stdin.take() {
            let escaped_url = url.replace('\\', "\\\\").replace('"', "\\\"");
            let escaped_body = body.replace('\\', "\\\\").replace('"', "\\\"");
            let mut config = format!(
                "silent\nurl = \"{escaped_url}\"\nheader = \"Content-Type: application/json\"\nheader = \"X-GAH-Caller: cli\"\ndata = \"{escaped_body}\"\n"
            );
            if let Some(t) = token {
                let escaped_token = t.replace('\\', "\\\\").replace('"', "\\\"");
                config.push_str(&format!(
                    "header = \"Authorization: Bearer {escaped_token}\"\n"
                ));
            }
            stdin.write_all(config.as_bytes())?;
        }
        let output = child.wait_with_output().context("waiting for curl")?;
        if !output.status.success() {
            anyhow::bail!(
                "memory gateway request failed (curl exit {:?}): {}",
                output.status.code(),
                String::from_utf8_lossy(&output.stderr)
            );
        }
        let stdout = String::from_utf8_lossy(&output.stdout);
        let marker_idx = stdout.rfind(STATUS_MARKER).ok_or_else(|| {
            anyhow::anyhow!("curl output missing status marker (malformed response?)")
        })?;
        let status: u16 = stdout[marker_idx + STATUS_MARKER.len()..]
            .trim()
            .parse()
            .context("parsing HTTP status from curl output")?;
        let response_body = stdout[..marker_idx].trim_end().as_bytes().to_vec();
        Ok((status, response_body))
    }
}

#[derive(Debug, Deserialize)]
struct RecallResponse {
    context: String,
    code: i64,
    #[serde(default)]
    message: String,
}

#[derive(Debug, Deserialize)]
struct CaptureResponse {
    l0_recorded: u64,
    #[serde(default)]
    code: i64,
    #[serde(default)]
    message: String,
}

/// Workers always use central's authenticated relay, including when a caller used --config.
fn gateway_connection(
    defaults: &crate::config::Defaults,
) -> Result<(String, Option<String>, NodeRole)> {
    let node = crate::node_role::NodeRoleStatus::resolve(defaults)?;
    if node.role == NodeRole::Worker {
        let token = std::env::var("COORDINATOR_TOKEN").ok().filter(|token| !token.is_empty())
            .or_else(|| crate::installer::files::env_get(&crate::setup::host::home().join(".config/gah/gah-loop.env"), "COORDINATOR_TOKEN"))
            .context("worker memory requires COORDINATOR_TOKEN in the environment or ~/.config/gah/gah-loop.env")?;
        if token.trim().is_empty() || token.chars().any(char::is_control) {
            anyhow::bail!(
                "worker memory requires a nonempty COORDINATOR_TOKEN without control characters"
            );
        }
        return Ok((
            format!(
                "{}/api/worker-memory",
                node.central_url.unwrap().trim_end_matches('/')
            ),
            Some(token),
            node.role,
        ));
    }
    Ok((
        configured_gateway_url(),
        gateway_api_key(&crate::setup::host::home())?,
        node.role,
    ))
}

/// The setup hook settings already hold the Mac's remote gateway URL.
fn configured_gateway_url() -> String {
    std::env::var("TDAI_GATEWAY_URL")
        .ok()
        .filter(|url| !url.is_empty())
        .or_else(|| {
            let home = crate::setup::host::home();
            [
                home.join(".config/gah/gateway-settings.json"),
                home.join(".config/gah/memory-hooks.json"),
            ]
            .iter()
            .find_map(|file| {
                let value: serde_json::Value =
                    serde_json::from_slice(&std::fs::read(file).ok()?).ok()?;
                value
                    .get("url")
                    .or_else(|| value.get("gateway_url"))?
                    .as_str()
                    .filter(|url| !url.is_empty())
                    .map(str::to_owned)
            })
        })
        .unwrap_or_else(|| DEFAULT_GATEWAY_URL.into())
}

/// User-requested operations report failures; only automatic memory calls fail open.
pub fn project_request(
    defaults: &crate::config::Defaults,
    profile_name: &str,
    local_path: &str,
    operation: &str,
    mut payload: serde_json::Value,
) -> Result<serde_json::Value> {
    anyhow::ensure!(
        matches!(
            operation,
            "recall"
                | "session/end"
                | "memories/list"
                | "memories/delete"
                | "memories/migrate-english"
                | "profiles/read"
        ),
        "Unsupported memory operation"
    );
    let project = resolve_project_key(profile_name, local_path);
    anyhow::ensure!(
        !project.is_empty() && project.len() <= 2000 && !project.chars().any(char::is_control),
        "Invalid project key"
    );
    let (url, key, role) = gateway_connection(defaults)?;
    payload["session_key"] = serde_json::json!(format!("gah:manager:{project}"));
    if role == NodeRole::Worker {
        payload["profile"] = serde_json::json!(profile_name);
    }
    let (status, response) = CurlMemoryGatewayTransport.post(
        &format!("{}/{operation}", url.trim_end_matches('/')),
        &serde_json::to_string(&payload)?,
        key.as_deref(),
        300,
    )?;
    anyhow::ensure!(
        status != 401,
        "Memory gateway authentication failed; repair ~/.config/gah/tdai-gateway.env"
    );
    anyhow::ensure!(
        (200..300).contains(&status),
        "Memory gateway returned HTTP {status}"
    );
    let result: serde_json::Value =
        serde_json::from_slice(&response).context("Invalid memory gateway response")?;
    anyhow::ensure!(
        result.get("code").and_then(|v| v.as_i64()).unwrap_or(0) == 0,
        "Memory operation failed: {}",
        result
            .get("message")
            .and_then(|v| v.as_str())
            .unwrap_or("unknown error")
    );
    Ok(result)
}

/// Same normalization as `memoryGatewayClient.ts`'s `normalizeRemoteUrl`:
/// strips scheme, credentials, and a trailing `.git`, and converts
/// scp-style `host:path` to `host/path`. Must stay byte-for-byte
/// equivalent to the TS side -- this is the project half of the shared
/// session key.
pub(crate) fn normalize_remote_url(raw: &str) -> String {
    let mut s = raw.trim().to_lowercase();
    if let Some(idx) = s.find("://") {
        let scheme = &s[..idx];
        if scheme
            .chars()
            .all(|c| c.is_ascii_alphanumeric() || c == '+' || c == '.' || c == '-')
        {
            s = s[idx + 3..].to_string();
        }
    }
    if let Some(idx) = s.find('@') {
        if !s[..idx].contains('/') {
            s = s[idx + 1..].to_string();
        }
    }
    // scp-style host:path -> host/path, but don't touch a port (":NNN/").
    if let Some(idx) = s.find(':') {
        let after = &s[idx + 1..];
        let looks_like_port = after
            .split('/')
            .next()
            .is_some_and(|p| !p.is_empty() && p.chars().all(|c| c.is_ascii_digit()));
        if !looks_like_port {
            s = format!("{}/{}", &s[..idx], after);
        }
    }
    if let Some(stripped) = s.strip_suffix(".git") {
        s = stripped.to_string();
    }
    s.trim_end_matches('/').to_string()
}

/// Resolves this profile's project key by reading its git remote (same
/// approach `memoryGatewayClient.ts`'s `resolveProjectKey` takes via
/// `git remote get-url origin`), falling back to the raw profile name on
/// any failure -- not a git repo yet, no `origin` remote, git missing.
fn resolve_project_key(profile_name: &str, local_path: &str) -> String {
    let output = Command::new("git")
        .args(["-C", local_path, "remote", "get-url", "origin"])
        .output();
    match output {
        Ok(out) if out.status.success() => {
            let url = String::from_utf8_lossy(&out.stdout);
            let trimmed = url.trim();
            if trimmed.is_empty() {
                profile_name.to_string()
            } else {
                normalize_remote_url(trimmed)
            }
        }
        _ => profile_name.to_string(),
    }
}

/// `gah:worker:{project_key}:{ticket_id}` -- the leaf scope
/// `memoryGatewayClient.ts`'s `sessionKeyForTicket` already documents as
/// the target for this wiring (issue #885 shipped the TS half).
pub(crate) fn session_key_for_ticket(
    profile_name: &str,
    local_path: &str,
    work_id: &str,
) -> String {
    let project_key = resolve_project_key(profile_name, local_path);
    let ticket_id = crate::work_claim::normalize_work_identity(work_id);
    format!("gah:worker:{project_key}:{ticket_id}")
}

/// Best-effort recall for one ticket's dispatch prompt. Returns `None`
/// (never an error) when `TDAI_GATEWAY_URL` behavior can't be satisfied
/// for any reason -- gateway unset/unreachable, non-2xx, malformed
/// response, or a genuinely empty result. Caller injects the returned text
/// as an optional prompt section; nothing downstream treats its absence as
/// a failure.
pub fn recall_for_ticket(
    defaults: &crate::config::Defaults,
    profile_name: &str,
    local_path: &str,
    work_id: &str,
    query: &str,
) -> Option<String> {
    recall_for_ticket_with_transport(
        defaults,
        &CurlMemoryGatewayTransport,
        profile_name,
        local_path,
        work_id,
        query,
    )
}

fn recall_for_ticket_with_transport(
    defaults: &crate::config::Defaults,
    transport: &dyn MemoryGatewayTransport,
    profile_name: &str,
    local_path: &str,
    work_id: &str,
    query: &str,
) -> Option<String> {
    let session_key = session_key_for_ticket(profile_name, local_path, work_id);
    let (base_url, token, role) = match gateway_connection(defaults) {
        Ok(connection) => connection,
        Err(error) => {
            eprintln!("[gah] memory recall unavailable: {error:#}");
            return None;
        }
    };
    let url = format!("{}/recall", base_url.trim_end_matches('/'));
    let mut body = serde_json::json!({ "query": query, "session_key": session_key });
    if role == NodeRole::Worker {
        body["profile"] = profile_name.into();
    }
    let body = body.to_string();

    let (status, response_body) =
        match transport.post(&url, &body, token.as_deref(), RECALL_TIMEOUT_SECONDS) {
            Ok(result) => result,
            Err(err) => {
                eprintln!(
                    "[gah] memory gateway recall failed (swallowed, dispatch continues): {err:#}"
                );
                return None;
            }
        };
    if status != 200 {
        eprintln!(
            "[gah] memory gateway recall returned status {status} (swallowed): {}",
            String::from_utf8_lossy(&response_body)
        );
        return None;
    }
    let parsed: RecallResponse = match serde_json::from_slice(&response_body) {
        Ok(parsed) => parsed,
        Err(err) => {
            eprintln!("[gah] memory gateway recall returned unparseable JSON (swallowed): {err:#}");
            return None;
        }
    };
    if parsed.code != 0 {
        eprintln!(
            "[gah] memory gateway recall degraded (code={}, swallowed): {}",
            parsed.code, parsed.message
        );
        return None;
    }
    let trimmed = parsed.context.trim();
    if trimmed.is_empty() {
        None
    } else {
        Some(trimmed.to_string())
    }
}

/// Best-effort capture for one ticket's dispatch attempt. Returns `Some(l0_recorded)`
/// when successful, `None` when the gateway is unset/unreachable, non-2xx, malformed
/// response, or degraded. Caller logs the result; nothing downstream treats its
/// absence as a failure.
pub fn capture_for_ticket(
    defaults: &crate::config::Defaults,
    profile_name: &str,
    local_path: &str,
    work_id: &str,
    user_content: &str,
    assistant_content: &str,
) -> Option<u64> {
    capture_for_ticket_with_transport(
        defaults,
        &CurlMemoryGatewayTransport,
        profile_name,
        local_path,
        work_id,
        user_content,
        assistant_content,
    )
}

fn capture_for_ticket_with_transport(
    defaults: &crate::config::Defaults,
    transport: &dyn MemoryGatewayTransport,
    profile_name: &str,
    local_path: &str,
    work_id: &str,
    user_content: &str,
    assistant_content: &str,
) -> Option<u64> {
    let session_key = session_key_for_ticket(profile_name, local_path, work_id);
    let (base_url, token, role) = match gateway_connection(defaults) {
        Ok(connection) => connection,
        Err(error) => {
            eprintln!("[gah] memory capture unavailable: {error:#}");
            return None;
        }
    };
    let url = format!("{}/capture", base_url.trim_end_matches('/'));
    let mut body = serde_json::json!({
        "user_content": user_content,
        "assistant_content": assistant_content,
        "session_key": session_key
    });
    if role == NodeRole::Worker {
        body["profile"] = profile_name.into();
    }
    let body = body.to_string();

    let (status, response_body) =
        match transport.post(&url, &body, token.as_deref(), RECALL_TIMEOUT_SECONDS) {
            Ok(result) => result,
            Err(err) => {
                eprintln!(
                    "[gah] memory gateway capture failed (swallowed, dispatch continues): {err:#}"
                );
                return None;
            }
        };
    if status != 200 {
        eprintln!(
            "[gah] memory gateway capture returned status {status} (swallowed): {}",
            String::from_utf8_lossy(&response_body)
        );
        return None;
    }
    let parsed: CaptureResponse = match serde_json::from_slice(&response_body) {
        Ok(parsed) => parsed,
        Err(err) => {
            eprintln!(
                "[gah] memory gateway capture returned unparseable JSON (swallowed): {err:#}"
            );
            return None;
        }
    };
    if parsed.code != 0 {
        eprintln!(
            "[gah] memory gateway capture degraded (code={}, swallowed): {}",
            parsed.code, parsed.message
        );
        return None;
    }
    Some(parsed.l0_recorded)
}

/// Issue #915: Convenience function to capture attempt results and update ledger
pub fn capture_attempt_and_update_ledger(
    defaults: &crate::config::Defaults,
    profile_name: &str,
    local_path: &str,
    work_id: &str,
    user_content: &str,
    assistant_content: &str,
    ledger: &mut crate::ledger::LedgerEntry,
) -> Option<u64> {
    let l0_recorded = capture_for_ticket(
        defaults,
        profile_name,
        local_path,
        work_id,
        user_content,
        assistant_content,
    );
    if let Some(count) = l0_recorded {
        ledger.memory_gateway_capture_l0_recorded = Some(count);
    }
    l0_recorded
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::cell::RefCell;
    #[cfg(unix)]
    use std::{fs, path::Path};

    #[cfg(unix)]
    fn write_fake_curl(path: &Path, body: &str) {
        use std::os::unix::fs::PermissionsExt;
        fs::write(path, body).unwrap();
        let mut permissions = fs::metadata(path).unwrap().permissions();
        permissions.set_mode(0o755);
        fs::set_permissions(path, permissions).unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn real_curl_transport_is_hermetic_secret_safe_and_fail_open() {
        const TEST_NAME: &str =
            "memory_gateway::tests::real_curl_transport_is_hermetic_secret_safe_and_fail_open";
        if std::env::var_os("GAH_MEMORY_CURL_TEST_CHILD").is_none() {
            for env_key in [true, false] {
                let home = tempfile::tempdir().unwrap();
                crate::installer::files::env_set(
                    &home.path().join(".config/gah/tdai-gateway.env"),
                    "TDAI_GATEWAY_API_KEY",
                    if env_key {
                        "ignored-file-key"
                    } else {
                        "super-secret-token"
                    },
                )
                .unwrap();
                let mut command = std::process::Command::new(std::env::current_exe().unwrap());
                command
                    .args(["--exact", TEST_NAME, "--nocapture"])
                    .env("HOME", home.path())
                    .env("GAH_MEMORY_CURL_TEST_CHILD", "1")
                    .env("GAH_NODE_ROLE", "central")
                    .env("TDAI_GATEWAY_URL", "https://memory.test");
                if env_key {
                    command.env("TDAI_GATEWAY_API_KEY", "super-secret-token");
                } else {
                    command.env_remove("TDAI_GATEWAY_API_KEY");
                }
                let result = command.output().unwrap();
                assert!(
                    result.status.success(),
                    "{} {}",
                    String::from_utf8_lossy(&result.stdout),
                    String::from_utf8_lossy(&result.stderr)
                );
            }
            return;
        }

        let _exec_guard = crate::test_support::ExecGuard::new();
        let dir = tempfile::tempdir().unwrap();
        let argv_path = dir.path().join("argv.txt");
        let stdin_path = dir.path().join("stdin.txt");
        write_fake_curl(
            &dir.path().join("curl"),
            r#"#!/bin/sh
printf '%s\n' "$@" > "$FAKE_CURL_ARGV"
config=$(cat)
printf '%s' "$config" > "$FAKE_CURL_STDIN"
case "$FAKE_CURL_MODE" in
  recall) printf '%s\n__GAH_MEMORY_GATEWAY_STATUS__:200\n' '{"context":"remembered","code":0}' ;;
  capture) printf '%s\n__GAH_MEMORY_GATEWAY_STATUS__:200\n' '{"l0_recorded":2,"code":0}' ;;
  non_200) printf '%s\n__GAH_MEMORY_GATEWAY_STATUS__:503\n' '{"error":"offline"}' ;;
  transport_failure) exit 7 ;;
  malformed) printf '%s\n' 'garbage without a status marker' ;;
  *) exit 9 ;;
esac
"#,
        );
        std::env::set_var("FAKE_CURL_ARGV", &argv_path);
        std::env::set_var("FAKE_CURL_STDIN", &stdin_path);
        let _path_guard = crate::test_support::PathGuard::set(dir.path());
        let defaults = crate::config::Defaults::default();

        std::env::set_var("FAKE_CURL_MODE", "recall");
        assert_eq!(
            recall_for_ticket(&defaults, "gah", "/tmp", "#1247", "query"),
            Some("remembered".to_string())
        );
        let argv = fs::read_to_string(&argv_path).unwrap();
        let stdin = fs::read_to_string(&stdin_path).unwrap();
        assert!(!argv.contains("super-secret-token"), "got argv: {argv}");
        assert!(stdin.contains("Authorization: Bearer super-secret-token"));
        assert!(stdin.contains("gah:worker:gah:#1247"));

        std::env::set_var("FAKE_CURL_MODE", "capture");
        assert_eq!(
            capture_for_ticket(&defaults, "gah", "/tmp", "#1247", "task", "result"),
            Some(2)
        );

        std::env::set_var("FAKE_CURL_MODE", "non_200");
        assert_eq!(
            recall_for_ticket(&defaults, "gah", "/tmp", "#1247", "query"),
            None
        );

        std::env::set_var("FAKE_CURL_MODE", "transport_failure");
        assert_eq!(
            capture_for_ticket(&defaults, "gah", "/tmp", "#1247", "task", "result"),
            None
        );
        assert_eq!(
            recall_for_ticket(&defaults, "gah", "/tmp", "#1247", "query"),
            None
        );

        std::env::set_var("FAKE_CURL_MODE", "non_200");
        assert_eq!(
            capture_for_ticket(&defaults, "gah", "/tmp", "#1247", "task", "result"),
            None
        );

        std::env::set_var("FAKE_CURL_MODE", "malformed");
        assert_eq!(
            recall_for_ticket(&defaults, "gah", "/tmp", "#1247", "query"),
            None
        );
        assert_eq!(
            capture_for_ticket(&defaults, "gah", "/tmp", "#1247", "task", "result"),
            None
        );
    }

    #[test]
    fn normalize_remote_url_handles_https_and_scp_and_git_suffix() {
        assert_eq!(
            normalize_remote_url("https://github.com/Kh1ng/git-agent-harness.git"),
            "github.com/kh1ng/git-agent-harness"
        );
        assert_eq!(
            normalize_remote_url("git@github.com:Kh1ng/git-agent-harness.git"),
            "github.com/kh1ng/git-agent-harness"
        );
        assert_eq!(
            normalize_remote_url("http://gitlab.example.com:8080/group/project.git"),
            "gitlab.example.com:8080/group/project",
        );
    }

    #[test]
    fn session_key_uses_normalized_project_and_ticket_id() {
        // No git repo at this path, so resolve_project_key falls back to
        // the profile name -- exercises the same fallback path production
        // hits for a fresh worktree with no remote configured yet.
        let key = session_key_for_ticket("gah", "/nonexistent/path/for/test", "TICKET-0362");
        assert_eq!(key, "gah:worker:gah:#362");
    }

    type FakeResponse = std::result::Result<(u16, Vec<u8>), String>;

    struct FakeTransport {
        responses: RefCell<std::collections::VecDeque<FakeResponse>>,
        calls: RefCell<Vec<(String, String, Option<String>)>>,
    }

    impl FakeTransport {
        fn queue(responses: Vec<(u16, &str)>) -> Self {
            Self {
                responses: RefCell::new(
                    responses
                        .into_iter()
                        .map(|(s, b)| Ok((s, b.as_bytes().to_vec())))
                        .collect(),
                ),
                calls: RefCell::new(Vec::new()),
            }
        }
    }

    impl MemoryGatewayTransport for FakeTransport {
        fn post(
            &self,
            url: &str,
            body: &str,
            token: Option<&str>,
            _timeout_secs: u32,
        ) -> Result<(u16, Vec<u8>)> {
            self.calls.borrow_mut().push((
                url.to_string(),
                body.to_string(),
                token.map(String::from),
            ));
            match self.responses.borrow_mut().pop_front() {
                Some(Ok(r)) => Ok(r),
                Some(Err(e)) => anyhow::bail!("{e}"),
                None => anyhow::bail!("FakeTransport: no more queued responses"),
            }
        }
    }

    #[test]
    fn worker_capture_uses_central_relay_and_coordinator_token() {
        // Exercise real environment precedence in a child so other tests keep their environment.
        if std::env::var_os("GAH_MEMORY_ROLE_TEST_CHILD").is_none() {
            let result = std::process::Command::new(std::env::current_exe().unwrap())
                .args(["--exact", "memory_gateway::tests::worker_capture_uses_central_relay_and_coordinator_token", "--nocapture"])
                .env("GAH_MEMORY_ROLE_TEST_CHILD", "1")
                .env("GAH_NODE_ROLE", "worker")
                .env("COORDINATOR_TOKEN", "worker-token")
                .env("TDAI_GATEWAY_URL", "https://wrong-gateway.test")
                .env("TDAI_GATEWAY_API_KEY", "wrong-gateway-key")
                .output().unwrap();
            assert!(
                result.status.success(),
                "{} {}",
                String::from_utf8_lossy(&result.stdout),
                String::from_utf8_lossy(&result.stderr)
            );
            return;
        }
        let defaults = crate::config::Defaults {
            registry_central_url: Some("https://central.test".into()),
            ..Default::default()
        };
        let transport = FakeTransport::queue(vec![(200, r#"{"l0_recorded":1,"code":0}"#)]);
        assert_eq!(
            capture_for_ticket_with_transport(
                &defaults,
                &transport,
                "project",
                "/nonexistent/gah-memory-test",
                "#1",
                "task",
                "result"
            ),
            Some(1)
        );
        let calls = transport.calls.borrow();
        assert_eq!(calls[0].0, "https://central.test/api/worker-memory/capture");
        assert_eq!(calls[0].2.as_deref(), Some("worker-token"));
        let body: serde_json::Value = serde_json::from_str(&calls[0].1).unwrap();
        assert_eq!(body["profile"], "project");
    }

    #[test]
    fn recall_returns_context_on_success() {
        let t = FakeTransport::queue(vec![(
            200,
            r#"{"context":"relevant history","memory_count":2,"code":0,"message":""}"#,
        )]);
        let result = recall_for_ticket_with_transport(
            &crate::config::Defaults::default(),
            &t,
            "gah",
            "/tmp",
            "#362",
            "checkpoint resume",
        );
        assert_eq!(result, Some("relevant history".to_string()));
        assert_eq!(t.calls.borrow().len(), 1);
        assert!(t.calls.borrow()[0].0.ends_with("/recall"));
        let body: serde_json::Value = serde_json::from_str(&t.calls.borrow()[0].1).unwrap();
        assert!(
            body.get("profile").is_none(),
            "Direct gateway requests keep their existing contract"
        );
    }

    #[test]
    fn recall_returns_none_on_transport_failure_without_erroring() {
        let t = FakeTransport {
            responses: RefCell::new(vec![Err("connection refused".to_string())].into()),
            calls: RefCell::new(Vec::new()),
        };
        let result = recall_for_ticket_with_transport(
            &crate::config::Defaults::default(),
            &t,
            "gah",
            "/tmp",
            "#362",
            "checkpoint resume",
        );
        assert_eq!(result, None);
    }

    #[test]
    fn recall_returns_none_on_non_200_status() {
        let t = FakeTransport::queue(vec![(401, r#"{"error":"unauthorized"}"#)]);
        let result = recall_for_ticket_with_transport(
            &crate::config::Defaults::default(),
            &t,
            "gah",
            "/tmp",
            "#362",
            "checkpoint resume",
        );
        assert_eq!(result, None);
    }

    #[test]
    fn recall_returns_none_on_degraded_code() {
        let t = FakeTransport::queue(vec![(
            200,
            r#"{"context":"","memory_count":0,"code":1,"message":"degraded"}"#,
        )]);
        let result = recall_for_ticket_with_transport(
            &crate::config::Defaults::default(),
            &t,
            "gah",
            "/tmp",
            "#362",
            "checkpoint resume",
        );
        assert_eq!(result, None);
    }

    #[test]
    fn recall_returns_none_on_empty_context() {
        let t = FakeTransport::queue(vec![(
            200,
            r#"{"context":"   ","memory_count":0,"code":0,"message":""}"#,
        )]);
        let result = recall_for_ticket_with_transport(
            &crate::config::Defaults::default(),
            &t,
            "gah",
            "/tmp",
            "#362",
            "checkpoint resume",
        );
        assert_eq!(result, None);
    }

    #[test]
    fn capture_returns_l0_recorded_on_success() {
        let t = FakeTransport::queue(vec![(
            200,
            r#"{"l0_recorded":2,"scheduler_notified":true,"code":0,"message":""}"#,
        )]);
        let result = capture_for_ticket_with_transport(
            &crate::config::Defaults::default(),
            &t,
            "gah",
            "/tmp",
            "#362",
            "user prompt",
            "assistant response",
        );
        assert_eq!(result, Some(2));
        assert_eq!(t.calls.borrow().len(), 1);
        assert!(t.calls.borrow()[0].0.ends_with("/capture"));
    }

    #[test]
    fn capture_returns_none_on_transport_failure_without_erroring() {
        let t = FakeTransport {
            responses: RefCell::new(vec![Err("connection refused".to_string())].into()),
            calls: RefCell::new(Vec::new()),
        };
        let result = capture_for_ticket_with_transport(
            &crate::config::Defaults::default(),
            &t,
            "gah",
            "/tmp",
            "#362",
            "user prompt",
            "assistant response",
        );
        assert_eq!(result, None);
    }

    #[test]
    fn capture_returns_none_on_non_200_status() {
        let t = FakeTransport::queue(vec![(401, r#"{"error":"unauthorized"}"#)]);
        let result = capture_for_ticket_with_transport(
            &crate::config::Defaults::default(),
            &t,
            "gah",
            "/tmp",
            "#362",
            "user prompt",
            "assistant response",
        );
        assert_eq!(result, None);
    }

    #[test]
    fn capture_returns_none_on_degraded_code() {
        let t = FakeTransport::queue(vec![(
            200,
            r#"{"l0_recorded":0,"scheduler_notified":false,"code":1,"message":"degraded"}"#,
        )]);
        let result = capture_for_ticket_with_transport(
            &crate::config::Defaults::default(),
            &t,
            "gah",
            "/tmp",
            "#362",
            "user prompt",
            "assistant response",
        );
        assert_eq!(result, None);
    }
}
