use crate::job_kind::{JobFamily, JobKind};
use crate::provider_kind::{ProviderKind, UnknownProviderKind};
use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};
use std::{collections::HashMap, path::PathBuf};

mod backend_instances;
mod merge_policy;
pub use backend_instances::*;
pub use merge_policy::MergePolicy;
mod backend_paths;
mod issue_intake;
pub use issue_intake::IssueIntakeMode;
mod publishing;
pub use publishing::PublishingPolicy;
mod delivery;
pub use delivery::DeliveryMode;
mod autonomy;
pub use autonomy::WakeAutonomy;
mod external_credential_scopes;
pub use external_credential_scopes::ExternalCredentialScope;
mod routing_policy;
pub use routing_policy::{CandidateConfig, RoutingPolicy, TaskRoutingRule};

#[derive(Debug, Deserialize, Serialize, Clone)]
pub struct GahConfig {
    #[serde(default)]
    pub defaults: Defaults,
    #[serde(default)]
    pub profiles: HashMap<String, Profile>,
    #[serde(default)]
    pub context: crate::context::ContextConfig,
}

#[derive(Debug, Deserialize, Serialize, Default, Clone)]
#[serde(default)]
pub struct Defaults {
    pub artifact_root: String,
    pub worktree_base: String,
    pub llm_base_url: String,
    pub llm_model_local: String,
    pub llm_model_cloud: String,
    pub routing: RoutingPolicy,
    /// Which agent CLI ("claude" | "codex" | "hermes") is currently acting
    /// as the operator's manager across all profiles/projects. Read by the
    /// manager-wake feature (`Profile::manager_wake_autonomy`) to decide
    /// who to invoke when a notify-worthy event fires. Global, not per-profile:
    /// "who's on call" is a cross-project fact. `None`/unrecognized means no wake
    /// even if a profile has autonomy enabled.
    pub current_manager: Option<String>,
    /// See `crate::network_exposure` module docs (issue #879).
    pub network_exposure: crate::network_exposure::NetworkExposureLevel,
    /// See `crate::network_exposure` module docs.
    pub lan_cidrs: Vec<String>,
    /// See `crate::network_exposure` module docs.
    #[serde(default = "crate::network_exposure::default_tailscale_cidr")]
    pub tailscale_cidr: Option<String>,
    pub registry_central_url: Option<String>,
    /// Optional cloud directory. Credentials are read only from environment variables.
    pub orchestration: crate::cloud::OrchestrationConfig,
    /// Host responsibility. Worker services keep execution local and central state remote.
    pub node_role: crate::node_role::NodeRole,
    pub registry_preflight_mode: crate::fleet_preflight::PreflightMode,
    /// Issue #653: where notify-worthy events are delivered in addition to
    /// any per-profile `notify_command`. Credentials never live here: the
    /// Telegram bot token comes from `TELEGRAM_BOT_TOKEN`, the Discord
    /// webhook URL from `DISCORD_WEBHOOK_URL`, both read at send time.
    #[serde(default)]
    pub notification_channel: crate::notify_channels::NotificationChannel,
    /// Telegram chat to deliver to when the channel is `telegram`.
    #[serde(default)]
    pub telegram_chat_id: Option<String>,
}

impl Defaults {
    pub fn llm_base_url(&self) -> String {
        std::env::var("LLM_BASE_URL").unwrap_or_else(|_| self.llm_base_url.clone())
    }
    pub fn llm_api_key(&self) -> String {
        std::env::var("LLM_API_KEY").unwrap_or_default()
    }
    pub fn llm_model(&self, cloud: bool) -> String {
        if let Ok(m) = std::env::var("LLM_MODEL") {
            return m;
        }
        if cloud {
            self.llm_model_cloud.clone()
        } else {
            self.llm_model_local.clone()
        }
    }

    pub fn ledger_path(&self) -> PathBuf {
        if let Ok(path) = std::env::var("GAH_LEDGER_PATH") {
            return PathBuf::from(path);
        }
        if !self.artifact_root.trim().is_empty() {
            return PathBuf::from(self.artifact_root.trim()).join("ledger.jsonl");
        }
        default_config_dir().join("ledger.jsonl")
    }

    /// TICKET-072: separate append-only log from `ledger.jsonl` (never
    /// rewrites dispatch history), same directory/override convention as
    /// `GAH_LEDGER_PATH`.
    pub fn reconciliation_path(&self) -> PathBuf {
        if let Ok(path) = std::env::var("GAH_RECONCILIATION_PATH") {
            return PathBuf::from(path);
        }
        if !self.artifact_root.trim().is_empty() {
            return PathBuf::from(self.artifact_root.trim()).join("reconciliation.jsonl");
        }
        default_config_dir().join("reconciliation.jsonl")
    }

    /// TICKET-083: append-only controller event stream, same convention as
    /// `GAH_LEDGER_PATH`/`GAH_RECONCILIATION_PATH`.
    pub fn events_path(&self) -> PathBuf {
        if let Ok(path) = std::env::var("GAH_EVENTS_PATH") {
            return PathBuf::from(path);
        }
        if !self.artifact_root.trim().is_empty() {
            return PathBuf::from(self.artifact_root.trim()).join("events.jsonl");
        }
        default_config_dir().join("events.jsonl")
    }

    /// Directory `manager_wake_autonomy` audit logs are written under, same
    /// override convention as `GAH_LEDGER_PATH`/`GAH_EVENTS_PATH`.
    pub fn manager_wake_log_dir(&self) -> PathBuf {
        if let Ok(path) = std::env::var("GAH_MANAGER_WAKE_LOG_DIR") {
            return PathBuf::from(path);
        }
        if !self.artifact_root.trim().is_empty() {
            return PathBuf::from(self.artifact_root.trim()).join("manager-wake-logs");
        }
        default_config_dir().join("manager-wake-logs")
    }
}

#[derive(Debug, Deserialize, Serialize, Clone)]
pub struct Profile {
    pub display_name: String,
    pub repo_id: String,
    pub provider: String,
    pub repo: String,
    pub local_path: String,
    pub artifact_root: String,
    pub default_target_branch: String,
    #[serde(default)]
    pub provider_api_base: Option<String>,
    #[serde(default)]
    pub provider_project_id: Option<String>,
    /// OpenHands profile name (~/.openhands/profiles/<name>.json). Overrides default LLM config.
    #[serde(default)]
    pub oh_profile: Option<String>,
    /// Extra OpenHands CLI args; `--skills` is ignored in favor of central bindings.
    #[serde(default)]
    pub openhands_args: Vec<String>,
    /// Extra CLI args appended to `codex exec` for invariant non-model flags.
    #[serde(default)]
    pub codex_args: Vec<String>,
    /// Optional absolute/relative path to the Codex CLI executable.
    #[serde(default)]
    pub codex_path: Option<String>,
    /// Extra CLI args appended to `claude -p` (e.g. `--allowedTools Edit,Write,Bash`)
    #[serde(default)]
    pub claude_args: Vec<String>,
    /// Optional absolute/relative path to the Claude CLI executable.
    #[serde(default)]
    pub claude_path: Option<String>,
    /// Optional absolute/relative path to the Antigravity CLI executable.
    #[serde(default)]
    pub agy_path: Option<String>,
    /// Extra CLI args appended to `vibe -p` (e.g. `--max-turns 40 --max-price 2`).
    /// Applied to worker/fix and review execution.
    #[serde(default)]
    pub vibe_args: Vec<String>,
    /// Optional absolute/relative path to the Mistral Vibe CLI executable.
    #[serde(default)]
    pub vibe_path: Option<String>,
    /// Role-agnostic `opencode run` args for worker/fix and review execution;
    /// GAH owns and filters agent and model selection.
    #[serde(default)]
    pub opencode_args: Vec<String>,
    /// Optional absolute/relative path to the OpenCode CLI executable.
    #[serde(default)]
    pub opencode_path: Option<String>,
    /// Extra Hermes CLI args; `--skills` is ignored in favor of central bindings.
    #[serde(default)]
    pub hermes_args: Vec<String>,
    /// Optional absolute/relative path to the Hermes CLI executable.
    #[serde(default)]
    pub hermes_path: Option<String>,
    /// How long OpenCode can go without a durable worktree change before GAH
    /// considers it stalled and kills it, in seconds. OpenCode's narration
    /// and malformed tool-call output deliberately do not reset this window:
    /// only repository progress does. This retains an activity-based guard
    /// rather than imposing a flat dispatch deadline. Defaults to 300s when
    /// unset.
    #[serde(default)]
    pub opencode_idle_timeout_seconds: Option<u64>,
    /// Per-model override for `opencode_idle_timeout_seconds`, keyed by the
    /// exact model name passed to `opencode --model` (e.g.
    /// "litellm-lan/qwen3.6:35b-a3b"). Some models routed through opencode
    /// are genuinely slow-but-working (a self-hosted litellm proxy) rather
    /// than hung, while others (a free-tier rate-limited model) hang with
    /// zero output and should be killed fast -- one flat idle timeout for
    /// every opencode model is too coarse. Falls back to the flat
    /// `opencode_idle_timeout_seconds` when no entry matches. Same pattern
    /// as `agy_print_timeout_seconds` below.
    #[serde(default)]
    pub opencode_idle_timeout_seconds_by_model: HashMap<String, u64>,
    /// Per-backend/model concurrency caps keyed by `"{backend}/{model}"`.
    /// Missing keys are unlimited. Enforcement is process-local; the profile
    /// lock guarantees one dispatching GAH process per profile.
    #[serde(default)]
    pub max_concurrent_per_model: HashMap<String, u32>,
    /// OpenHands idle-output timeout in seconds. Defaults to 300s; active
    /// worktree progress keeps a quiet process alive.
    #[serde(default)]
    pub openhands_idle_timeout_seconds: Option<u64>,
    /// How long Vibe's own log output can go quiet before GAH considers it
    /// stalled and kills it, in seconds. Same rationale and mechanism as
    /// `opencode_idle_timeout_seconds` -- added after a live dispatch hung
    /// for 15+ minutes with vibe as the backend and `run_vibe_with_executable`
    /// had zero supervision of any kind. Defaults to 300s when unset.
    #[serde(default)]
    pub vibe_idle_timeout_seconds: Option<u64>,
    /// How long Codex's own log output can go quiet before GAH considers it
    /// stalled and kills it, in seconds. Same rationale and mechanism as
    /// `opencode_idle_timeout_seconds`. Defaults to 300s when unset.
    #[serde(default)]
    pub codex_idle_timeout_seconds: Option<u64>,
    /// How long Claude Code's own log output can go quiet before GAH
    /// considers it stalled and kills it, in seconds. Same rationale and
    /// mechanism as `opencode_idle_timeout_seconds`. Defaults to 300s when
    /// unset.
    #[serde(default)]
    pub claude_idle_timeout_seconds: Option<u64>,
    /// How long Hermes's own log output can go quiet before GAH considers it
    /// stalled and kills it, in seconds. Same rationale and mechanism as
    /// `opencode_idle_timeout_seconds`. Defaults to 300s when unset.
    #[serde(default)]
    pub hermes_idle_timeout_seconds: Option<u64>,
    /// How many tickets `gah loop` may execute concurrently for this profile.
    /// The native recurring loop owns this worker pool; the shell supervisor
    /// is only a compatibility launcher. Defaults to 1 when unset.
    #[serde(default)]
    pub max_parallel_workers: Option<u32>,
    /// Open managed PRs/MRs plus pre-publication dispatches allowed before
    /// implementation intake pauses. Defaults to `max_parallel_workers`.
    #[serde(default)]
    pub max_open_managed_mrs: Option<u32>,
    /// HOME override for the `agy-second` backend name only -- a distinct
    /// authenticated Antigravity account/quota pool from the default `agy`
    /// backend, which otherwise runs under the process's real $HOME. Same
    /// executable (`agy_path`), different account state directory.
    #[serde(default)]
    pub agy_second_home: Option<String>,
    /// Per-model override for AGY's own `--print-timeout` (default 5m0s in
    /// the `agy` CLI itself). Keyed by the exact AGY model name (e.g.
    /// "Gemini 3.5 Flash (Medium)"). This is now an outer safety backstop
    /// only -- the primary enforcement is `agy_idle_timeout_seconds` below,
    /// which kills based on whether AGY is still producing output, not a
    /// flat wall-clock budget. AGY is the only backend GAH invokes that
    /// exposes a print-timeout flag today, so this stays scoped to AGY
    /// rather than a generic cross-backend timeout abstraction.
    #[serde(default)]
    pub agy_print_timeout_seconds: HashMap<String, u64>,
    /// How long AGY's own log output can go quiet before GAH considers it
    /// stalled and kills it, in seconds. Deliberately not per-model: a
    /// working model of any speed should produce *some* log output
    /// periodically as it takes actions, so a flat idle threshold is the
    /// right granularity here (unlike agy_print_timeout_seconds, which is
    /// about total budget and genuinely varies by model). Defaults to 120s
    /// when unset (see `Profile::agy_idle_timeout_seconds`).
    #[serde(default)]
    pub agy_idle_timeout_seconds: Option<u64>,
    /// Optional shell command that GAH pipes a one-line notification message to
    /// (via stdin) on key controller/dispatch events (MR created, human required,
    /// review verdict, terminal dispatch failure). When unset GAH produces no
    /// notification output at all. Notification failures are always swallowed and
    /// logged to stderr -- they never fail the operation.
    #[serde(default)]
    pub notify_command: Option<String>,
    /// How much a woken manager agent is allowed to do on its own for this
    /// profile, when a notify-worthy event fires. See `WakeAutonomy` and
    /// `Defaults::current_manager`. Defaults to `Off` -- an operator opts a
    /// specific profile into this.
    #[serde(default)]
    pub manager_wake_autonomy: WakeAutonomy,
    /// Delivery mode for work results: `pr` (default) | `handoff`.
    #[serde(default)]
    pub delivery_mode: DeliveryMode,
    /// Path to a policy TOML file (see gah policy-check). When set, dispatch
    /// enforces permissions before provisioning any worktree.
    #[serde(default)]
    pub policy_path: Option<String>,
    /// Optional path to a KEY=VALUE env file sourced before running any backend
    /// in dev mode (default). Contains dev/api keys, never prod credentials.
    #[serde(default)]
    pub env_file: Option<String>,
    /// Path to a production KEY=VALUE env file. Only loaded when --prod is passed
    /// to dispatch. Keeps prod credentials isolated from dev runs.
    #[serde(default)]
    pub env_file_prod: Option<String>,
    /// Commands run in the worktree after each agent attempt; all must pass before commit/push.
    /// Example: ["cargo test --quiet", "cargo clippy -- -D warnings"]
    #[serde(default)]
    pub validation_commands: Vec<String>,
    /// Best-effort mechanical fixups run before validation on every attempt.
    /// Example: ["cargo fmt"].
    #[serde(default)]
    pub auto_fix_commands: Vec<String>,
    #[serde(default)]
    pub test_file_patterns: Vec<String>,
    /// Explicit case-insensitive markers for known baseline failures.
    #[serde(default)]
    pub known_baseline_failure_markers: Vec<String>,
    /// Model override for `improve`/`fix` mode (heavy lifting)
    #[serde(default)]
    pub model_improve: Option<String>,
    /// Model override for `pm` mode (ticket decomposition, cheap/fast)
    #[serde(default)]
    pub model_pm: Option<String>,
    /// Model override for `review` mode
    #[serde(default)]
    pub model_review: Option<String>,
    /// Review idle timeout in seconds (default 300).
    #[serde(default)]
    pub review_timeout_seconds: Option<u64>,
    #[serde(default)]
    pub review_hard_timeout_seconds: Option<u64>,
    /// Per-command validation timeout in seconds (default 300).
    #[serde(default)]
    pub validation_timeout_seconds: Option<u64>,
    #[serde(default)]
    pub routing: RoutingPolicy,
    /// TICKET-128: per-profile policy for human-facing repository messaging.
    /// Independent of reviewer routing and merge authorization; defaults to
    /// allowing PR/MR text, commit messages, and issue comments.
    #[serde(default)]
    pub publishing: PublishingPolicy,
    #[serde(default)]
    #[allow(dead_code)]
    pub pacing: crate::quota::PacingConfig,
    /// TICKET-158: per-profile retention window (days) for `gah prune`.
    /// High-churn self-hosting profiles can prune aggressively (e.g. 3-7)
    /// while low-churn profiles keep the 30-day default. The CLI
    /// `--older-than` flag overrides this per invocation.
    #[serde(default)]
    pub prune_older_than_days: Option<u64>,
    /// Idle chat sessions are archived by the daily chat-maintenance sweep
    /// after this many days without a completed turn. Unlike worktree prune,
    /// archive preserves dirty work as a patch and always keeps the branch.
    #[serde(default)]
    pub chat_session_idle_days: Option<u64>,
    #[serde(default)]
    pub external_credential_scopes: HashMap<String, ExternalCredentialScope>,
}

fn normalize_repo_path(repo: &str) -> String {
    let repo = repo.trim_matches('/');
    if repo.ends_with(".git") {
        repo.to_string()
    } else {
        format!("{}.git", repo)
    }
}

/// Canonicalizes `--backend` aliases that execute the same backend but were
/// being recorded under their literal alias string, producing duplicate
/// cards for one backend on the quota page (e.g. "openhands" and
/// "cloud-coder" both run OpenHands via `runner::backend_command_name`, but
/// only "openhands" was ever normalized there -- the raw CLI string was
/// still what got written to `requested_backend`/`effective_backend` and
/// from there into the ledger). Applied both where new dispatches are
/// routed (dispatch.rs) and when grouping the ledger for the quota page
/// (ledger/mod.rs), so it also merges pre-existing historical entries recorded
/// under the old alias rather than only preventing new duplicates.
/// Deliberately does NOT touch "auto": that backend's *effective* backend
/// is resolved dynamically per-attempt by `routing::decide`, not a fixed
/// alias, so it must pass through unchanged.
pub fn canonical_backend_name(name: &str) -> &str {
    if name == "cloud-coder" {
        "openhands"
    } else {
        name
    }
}

pub fn default_config_dir() -> PathBuf {
    let home = std::env::var_os("HOME").or_else(|| std::env::var_os("USERPROFILE"));
    home.map_or_else(|| PathBuf::from("/root"), PathBuf::from)
        .join(".config/gah")
}

pub fn default_config_path() -> PathBuf {
    default_config_dir().join("config.toml")
}

pub fn resolve_config_path(config_path: Option<&str>) -> PathBuf {
    config_path
        .map(PathBuf::from)
        .or_else(|| std::env::var("GAH_CONFIG").ok().map(PathBuf::from))
        .unwrap_or_else(default_config_path)
}

/// TICKET-106: shared canonical routing policy, inherited by every repo's
/// config unless explicitly overridden. Separate file from the per-repo
/// config (`GAH_CANONICAL_CONFIG` override, else `~/.config/gah/canonical.toml`
/// -- same `~/.config/gah/` convention as the default repo config path).
pub fn canonical_config_path() -> PathBuf {
    #[cfg(test)]
    {
        if let Some(path) = CANONICAL_CONFIG_TEST_OVERRIDE.with(|cell| cell.borrow().clone()) {
            return path;
        }
    }
    std::env::var("GAH_CANONICAL_CONFIG")
        .map(PathBuf::from)
        .unwrap_or_else(|_| default_config_dir().join("canonical.toml"))
}

// Tests used to coordinate this via a process-global env var (GAH_CANONICAL_CONFIG)
// guarded by a mutex, but that only serialized the tests that *set* the var --
// any other test calling `load()` concurrently on a different thread could still
// read the env var mid-mutation. A thread-local override sidesteps the race
// entirely: cargo test gives each running test exclusive use of its own thread.
#[cfg(test)]
thread_local! {
    static CANONICAL_CONFIG_TEST_OVERRIDE: std::cell::RefCell<Option<PathBuf>> =
        const { std::cell::RefCell::new(None) };
}

#[cfg(test)]
pub(crate) fn set_canonical_config_override(path: impl Into<PathBuf>) {
    CANONICAL_CONFIG_TEST_OVERRIDE.with(|cell| *cell.borrow_mut() = Some(path.into()));
}

#[cfg(test)]
pub(crate) fn clear_canonical_config_override() {
    CANONICAL_CONFIG_TEST_OVERRIDE.with(|cell| *cell.borrow_mut() = None);
}

#[derive(Debug, Deserialize, Default)]
struct CanonicalConfig {
    #[serde(default)]
    routing: RoutingPolicy,
}

/// `Ok(None)` when no canonical file exists (legacy standalone behavior).
/// Malformed canonical config is a hard error, never silently ignored --
/// an operator's shared policy must not silently fail to apply.
fn load_canonical_routing() -> Result<Option<RoutingPolicy>> {
    let path = canonical_config_path();
    if !path.exists() {
        return Ok(None);
    }
    let text =
        std::fs::read_to_string(&path).with_context(|| format!("reading {}", path.display()))?;
    let canonical: CanonicalConfig =
        toml::from_str(&text).with_context(|| format!("parsing {}", path.display()))?;
    Ok(Some(canonical.routing))
}

/// Field-level merge: `repo`'s own explicit values win; unset fields
/// inherit from `canonical`. Candidate lists (Vec) replace wholesale when
/// the repo sets them (not concatenate); the capability map merges by key
/// so a repo declaring one backend's capabilities doesn't erase another
/// backend's canonical-declared ones.
fn merge_routing_policy(canonical: RoutingPolicy, mut repo: RoutingPolicy) -> RoutingPolicy {
    repo.backend_instances =
        backend_instances::merge_instance_maps(canonical.backend_instances, repo.backend_instances);
    repo.default_backend = repo.default_backend.or(canonical.default_backend);
    repo.default_model = repo.default_model.or(canonical.default_model);
    repo.pm_backend = repo.pm_backend.or(canonical.pm_backend);
    repo.pm_model = repo.pm_model.or(canonical.pm_model);
    repo.improve_backend = repo.improve_backend.or(canonical.improve_backend);
    repo.improve_model = repo.improve_model.or(canonical.improve_model);
    repo.review_backend = repo.review_backend.or(canonical.review_backend);
    repo.review_model = repo.review_model.or(canonical.review_model);
    repo.strong_review_backend = repo
        .strong_review_backend
        .or(canonical.strong_review_backend);
    repo.strong_review_model = repo.strong_review_model.or(canonical.strong_review_model);
    repo.weak_review_backend = repo.weak_review_backend.or(canonical.weak_review_backend);
    repo.weak_review_model = repo.weak_review_model.or(canonical.weak_review_model);
    repo.routine_reviewer = repo.routine_reviewer.or(canonical.routine_reviewer);
    if repo.escalatory_reviewers.is_empty() {
        repo.escalatory_reviewers = canonical.escalatory_reviewers.clone();
    }
    repo.pm_candidates = repo.pm_candidates.or(canonical.pm_candidates);
    repo.improve_candidates = repo.improve_candidates.or(canonical.improve_candidates);
    if repo.pm_guidance_paths.is_empty() {
        repo.pm_guidance_paths = canonical.pm_guidance_paths;
    }
    if repo.task_routing_rules.is_empty() {
        repo.task_routing_rules = canonical.task_routing_rules.clone();
    }
    repo.review_candidates = repo.review_candidates.or(canonical.review_candidates);
    repo.allow_review_fallback = repo.allow_review_fallback || canonical.allow_review_fallback;
    repo.allow_implementation_fallback =
        repo.allow_implementation_fallback || canonical.allow_implementation_fallback;
    repo.max_runs_per_backend_per_week = repo
        .max_runs_per_backend_per_week
        .or(canonical.max_runs_per_backend_per_week);
    repo.max_runs_per_backend_per_session = repo
        .max_runs_per_backend_per_session
        .or(canonical.max_runs_per_backend_per_session);
    repo.max_total_strong_model_runs_per_week = repo
        .max_total_strong_model_runs_per_week
        .or(canonical.max_total_strong_model_runs_per_week);
    repo.max_total_strong_model_runs_per_session = repo
        .max_total_strong_model_runs_per_session
        .or(canonical.max_total_strong_model_runs_per_session);
    repo.max_known_estimated_cost_per_week = repo
        .max_known_estimated_cost_per_week
        .or(canonical.max_known_estimated_cost_per_week);
    repo.max_known_actual_cost_per_week = repo
        .max_known_actual_cost_per_week
        .or(canonical.max_known_actual_cost_per_week);
    repo.max_review_cycles_per_ticket = repo
        .max_review_cycles_per_ticket
        .or(canonical.max_review_cycles_per_ticket);
    repo.max_fix_attempts_per_mr = repo
        .max_fix_attempts_per_mr
        .or(canonical.max_fix_attempts_per_mr);
    repo.max_paid_reviews_per_ticket = repo
        .max_paid_reviews_per_ticket
        .or(canonical.max_paid_reviews_per_ticket);
    repo.max_implementation_failures_per_ticket = repo
        .max_implementation_failures_per_ticket
        .or(canonical.max_implementation_failures_per_ticket);
    let mut capabilities = canonical.review_required_capabilities;
    capabilities.extend(repo.review_required_capabilities);
    repo.review_required_capabilities = capabilities;
    repo.merge_policy = repo.merge_policy.or(canonical.merge_policy);
    repo
}

pub fn check_profile_candidate_model_consistency(
    defaults: &Defaults,
    profile: &Profile,
) -> Result<(), Vec<String>> {
    let routing = profile.effective_routing(defaults);
    let mut candidates = Vec::new();
    if let Some(ref c) = routing.routine_reviewer {
        candidates.push(("routine_reviewer", c));
    }
    for c in &routing.escalatory_reviewers {
        candidates.push(("escalatory_reviewer", c));
    }
    if let Some(ref list) = routing.pm_candidates {
        for c in list {
            candidates.push(("pm_candidate", c));
        }
    }
    if let Some(ref list) = routing.improve_candidates {
        for c in list {
            candidates.push(("improve_candidate", c));
        }
    }
    for rule in &routing.task_routing_rules {
        for candidate in &rule.candidates {
            candidates.push(("task_routing_rule", candidate));
        }
    }
    if let Some(ref list) = routing.review_candidates {
        for c in list {
            candidates.push(("review_candidate", c));
        }
    }

    let mut errors = Vec::new();
    for (label, candidate) in candidates {
        let args = match candidate.backend.as_str() {
            "codex" => &profile.codex_args,
            "opencode" => &profile.opencode_args,
            "claude" => &profile.claude_args,
            _ => continue,
        };
        if let Some(pinned) =
            crate::runner::extract_model_from_backend_args(&candidate.backend, args)
        {
            if candidate.model.as_deref() != Some(&pinned) {
                errors.push(format!(
                    "candidate {} (backend '{}', label '{}') has mismatch with profile backend args model pin '{}'",
                    label,
                    candidate.backend,
                    candidate.model.as_deref().unwrap_or("None"),
                    pinned
                ));
            }
        }
    }

    if errors.is_empty() {
        Ok(())
    } else {
        Err(errors)
    }
}

pub fn load(config_path: Option<&str>) -> Result<GahConfig> {
    let path = resolve_config_path(config_path);
    if !path.exists() {
        anyhow::bail!(
            "no config found; set GAH_CONFIG or create {}",
            default_config_path().display()
        );
    }

    let text =
        std::fs::read_to_string(&path).with_context(|| format!("reading {}", path.display()))?;
    let mut cfg: GahConfig =
        toml::from_str(&text).with_context(|| format!("parsing {}", path.display()))?;
    if let Some(canonical_routing) = load_canonical_routing()? {
        cfg.defaults.routing = merge_routing_policy(canonical_routing, cfg.defaults.routing);
    }

    // Lint candidate model consistency
    for (name, profile) in &cfg.profiles {
        if let Err(mismatches) = check_profile_candidate_model_consistency(&cfg.defaults, profile) {
            for m in mismatches {
                eprintln!("WARNING: Profile '{}': {}", name, m);
            }
        }
    }

    Ok(cfg)
}

pub fn get_profile<'a>(config: &'a GahConfig, name: &str) -> Result<&'a Profile> {
    config.profiles.get(name).ok_or_else(|| {
        let mut names: Vec<&str> = config.profiles.keys().map(String::as_str).collect();
        names.sort_unstable();
        anyhow::anyhow!(
            "profile '{}' not found; available: {}",
            name,
            names.join(", ")
        )
    })
}

/// Save the config back to the TOML file
pub fn save(config: &GahConfig, path: Option<&str>) -> Result<()> {
    let target_path = resolve_config_path(path);

    // Ensure parent directory exists
    if let Some(parent) = target_path.parent() {
        std::fs::create_dir_all(parent).context("creating config directory")?;
    }

    let toml_string = toml::to_string(config).context("serializing config to TOML")?;
    std::fs::write(&target_path, toml_string).context("writing config file")?;
    Ok(())
}

/// Add a new profile to the config
pub fn add_profile(config: &mut GahConfig, name: &str, profile: Profile) -> Result<()> {
    if config.profiles.contains_key(name) {
        anyhow::bail!("profile '{}' already exists", name);
    }
    config.profiles.insert(name.to_string(), profile);
    Ok(())
}

/// Remove a profile from the config
pub fn remove_profile(config: &mut GahConfig, name: &str) -> Result<()> {
    if !config.profiles.contains_key(name) {
        anyhow::bail!("profile '{}' not found", name);
    }
    config.profiles.remove(name);
    Ok(())
}

/// Get a mutable reference to a profile for in-place modification
pub fn get_profile_mut<'a>(config: &'a mut GahConfig, name: &str) -> Result<&'a mut Profile> {
    if !config.profiles.contains_key(name) {
        let names: Vec<String> = config.profiles.keys().cloned().collect();
        anyhow::bail!(
            "profile '{}' not found; available: {}",
            name,
            names.join(", ")
        );
    }
    Ok(config.profiles.get_mut(name).unwrap())
}

#[cfg(test)]
pub mod tests;
