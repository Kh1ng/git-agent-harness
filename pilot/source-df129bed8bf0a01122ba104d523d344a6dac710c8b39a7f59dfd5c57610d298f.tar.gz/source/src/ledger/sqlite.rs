use super::{jsonl, locking, LedgerEntry};
use crate::config::GahConfig;
use anyhow::{Context, Result};
use rusqlite::{params, Connection};
use std::fs::{self, File};
use std::io::{Read, Seek, SeekFrom};
use std::path::PathBuf;

pub fn db_path(cfg: &GahConfig) -> PathBuf {
    cfg.defaults.ledger_path().with_extension("db")
}

fn ensure_schema(conn: &Connection) -> Result<()> {
    conn.execute_batch(
        "CREATE TABLE IF NOT EXISTS ledger_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            profile TEXT NOT NULL,
            repo_id TEXT,
            work_id TEXT,
            mode TEXT NOT NULL,
            backend TEXT NOT NULL,
            effective_backend TEXT NOT NULL,
            effective_model TEXT,
            requested_model TEXT,
            validation_result TEXT,
            review_verdict TEXT,
            review_contract_version INTEGER,
            review_generation TEXT,
            human_required INTEGER NOT NULL,
            duration_seconds REAL,
            failure_class TEXT,
            total_tokens INTEGER,
            human_required_reason_code TEXT,
            actual_cost_usd REAL,
            estimated_cost_usd REAL,
            runner_kind TEXT,
            backend_instance TEXT,
            account_label TEXT,
            auth_source_label TEXT,
            model_provider TEXT,
            provider_attribution_source TEXT,
            auth_class TEXT,
            quota_pool TEXT,
            actual_model TEXT,
            raw_json TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS ledger_sync_state (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            synced_byte_len INTEGER NOT NULL,
            synced_entry_count INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_ledger_entries_profile_ts
            ON ledger_entries(profile, timestamp);
        CREATE INDEX IF NOT EXISTS idx_ledger_entries_work_id
            ON ledger_entries(work_id);",
    )?;
    ensure_human_required_reason_code_column(conn)?;
    ensure_review_generation_columns(conn)?;
    ensure_execution_identity_columns(conn)?;
    Ok(())
}

fn ensure_execution_identity_columns(conn: &Connection) -> Result<()> {
    for column in [
        "repo_id",
        "runner_kind",
        "backend_instance",
        "account_label",
        "auth_source_label",
        "model_provider",
        "provider_attribution_source",
        "auth_class",
        "quota_pool",
        "actual_model",
    ] {
        if !has_column(conn, "ledger_entries", column)? {
            conn.execute(
                &format!("ALTER TABLE ledger_entries ADD COLUMN {column} TEXT"),
                [],
            )?;
        }
    }
    conn.execute_batch(
        "CREATE INDEX IF NOT EXISTS idx_ledger_entries_identity
         ON ledger_entries(profile, repo_id, backend_instance, quota_pool);",
    )?;
    Ok(())
}

fn ensure_review_generation_columns(conn: &Connection) -> Result<()> {
    if !has_column(conn, "ledger_entries", "review_contract_version")? {
        conn.execute(
            "ALTER TABLE ledger_entries ADD COLUMN review_contract_version INTEGER",
            [],
        )?;
    }
    if !has_column(conn, "ledger_entries", "review_generation")? {
        conn.execute(
            "ALTER TABLE ledger_entries ADD COLUMN review_generation TEXT",
            [],
        )?;
    }
    Ok(())
}

fn ensure_human_required_reason_code_column(conn: &Connection) -> Result<()> {
    if !has_column(conn, "ledger_entries", "human_required_reason_code")? {
        conn.execute(
            "ALTER TABLE ledger_entries ADD COLUMN human_required_reason_code TEXT",
            [],
        )?;
    }
    Ok(())
}

fn has_column(conn: &Connection, table: &str, column: &str) -> Result<bool> {
    let pragma = format!("PRAGMA table_info({table})");
    let mut stmt = conn.prepare(&pragma)?;
    let mut rows = stmt.query([])?;
    while let Some(row) = rows.next()? {
        let name: String = row.get(1)?;
        if name == column {
            return Ok(true);
        }
    }
    Ok(false)
}

fn load_sync_state(conn: &Connection) -> Result<Option<(u64, u64)>> {
    let mut stmt = conn.prepare(
        "SELECT synced_byte_len, synced_entry_count FROM ledger_sync_state WHERE id = 1",
    )?;
    let mut rows = stmt.query([])?;
    if let Some(row) = rows.next()? {
        Ok(Some((row.get::<_, u64>(0)?, row.get::<_, u64>(1)?)))
    } else {
        Ok(None)
    }
}

fn store_sync_state(
    tx: &rusqlite::Transaction,
    synced_byte_len: u64,
    synced_entry_count: u64,
) -> Result<()> {
    tx.execute(
        "INSERT INTO ledger_sync_state (id, synced_byte_len, synced_entry_count)
         VALUES (1, ?1, ?2)
         ON CONFLICT(id) DO UPDATE SET
             synced_byte_len=excluded.synced_byte_len,
             synced_entry_count=excluded.synced_entry_count",
        params![synced_byte_len as i64, synced_entry_count as i64],
    )?;
    Ok(())
}

fn sync_full_from_entries(
    cfg: &GahConfig,
    entries: &[LedgerEntry],
    synced_byte_len: u64,
) -> Result<()> {
    let db_path = db_path(cfg);
    if let Some(parent) = db_path.parent() {
        fs::create_dir_all(parent).ok();
    }
    let mut conn = Connection::open(&db_path)
        .with_context(|| format!("opening sqlite ledger {}", db_path.display()))?;
    ensure_schema(&conn)?;
    let tx = conn.transaction().context("opening sqlite transaction")?;
    tx.execute("DELETE FROM ledger_entries", [])
        .context("clearing sqlite ledger mirror before resync")?;
    for entry in entries {
        insert_entry(&tx, entry)?;
    }
    store_sync_state(&tx, synced_byte_len, entries.len() as u64)?;
    tx.commit().context("committing sqlite ledger mirror")?;
    Ok(())
}

fn sync_incremental_from_jsonl(cfg: &GahConfig) -> Result<()> {
    let ledger_path = cfg.defaults.ledger_path();
    let db_path = db_path(cfg);
    if let Some(parent) = db_path.parent() {
        fs::create_dir_all(parent).ok();
    }
    let mut conn = Connection::open(&db_path)
        .with_context(|| format!("opening sqlite ledger {}", db_path.display()))?;
    ensure_schema(&conn)?;

    let sync_state = load_sync_state(&conn)?;
    let Some((synced_byte_len, synced_entry_count)) = sync_state else {
        let snapshot = jsonl::read_snapshot(cfg)?;
        return sync_full_from_entries(cfg, &snapshot.entries, snapshot.byte_len);
    };

    let ledger_lock = locking::shared(&ledger_path)?;
    let ledger_meta = match fs::metadata(&ledger_path) {
        Ok(meta) => meta,
        Err(err) if err.kind() == std::io::ErrorKind::NotFound => {
            drop(ledger_lock);
            let tx = conn.transaction().context("opening sqlite transaction")?;
            tx.execute("DELETE FROM ledger_entries", [])
                .context("clearing sqlite ledger mirror before resync")?;
            store_sync_state(&tx, 0, 0)?;
            tx.commit().context("committing sqlite ledger mirror")?;
            return Ok(());
        }
        Err(err) => return Err(err).with_context(|| format!("reading {}", ledger_path.display())),
    };

    let ledger_len = ledger_meta.len();
    if ledger_len < synced_byte_len {
        drop(ledger_lock);
        let snapshot = jsonl::read_snapshot(cfg)?;
        return sync_full_from_entries(cfg, &snapshot.entries, snapshot.byte_len);
    }

    if ledger_len == synced_byte_len {
        return Ok(());
    }

    let mut file =
        File::open(&ledger_path).with_context(|| format!("opening {}", ledger_path.display()))?;
    file.seek(SeekFrom::Start(synced_byte_len))
        .with_context(|| format!("seeking {}", ledger_path.display()))?;
    let mut tail = String::new();
    file.read_to_string(&mut tail)
        .with_context(|| format!("reading {}", ledger_path.display()))?;
    if tail.trim().is_empty() {
        return Ok(());
    }

    let entries = jsonl::parse_jsonl_entries(&tail, &ledger_path, synced_entry_count as usize)?;
    drop(ledger_lock);

    let mut conn = conn;
    let tx = conn.transaction().context("opening sqlite transaction")?;
    for entry in &entries {
        insert_entry(&tx, entry)?;
    }
    store_sync_state(&tx, ledger_len, synced_entry_count + entries.len() as u64)?;
    tx.commit().context("committing sqlite ledger mirror")?;
    Ok(())
}

fn insert_entry(tx: &rusqlite::Transaction, entry: &LedgerEntry) -> Result<()> {
    let entry = entry.normalized_for_persistence();
    let final_identity = entry
        .attempt_routing
        .iter()
        .rev()
        .find_map(|attempt| attempt.identity.as_ref());
    let raw_json = serde_json::to_string(&entry).context("serializing ledger entry")?;
    tx.execute(
        "INSERT INTO ledger_entries (
            timestamp, profile, repo_id, work_id, mode, backend, effective_backend,
            effective_model, requested_model, validation_result, review_verdict,
            review_contract_version, review_generation, human_required,
            duration_seconds, failure_class, total_tokens,
            human_required_reason_code, actual_cost_usd, estimated_cost_usd,
            runner_kind, backend_instance, account_label, auth_source_label,
            model_provider, provider_attribution_source, auth_class, quota_pool,
            actual_model, raw_json
        ) VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16,?17,?18,?19,?20,?21,?22,?23,?24,?25,?26,?27,?28,?29,?30)",
        params![
            entry.timestamp,
            entry.profile,
            entry.repo_id,
            entry.work_id,
            entry.mode,
            entry.backend,
            entry.effective_backend,
            entry.effective_model,
            entry.requested_model,
            entry.validation_result,
            entry.review_verdict,
            entry.review_contract_version.map(i64::from),
            entry.review_generation,
            entry.human_required as i64,
            entry.duration_seconds,
            entry.failure_class,
            entry.usage.total_tokens.map(|v| v as i64),
            entry.human_required_reason_code,
            entry.usage.actual_cost_usd,
            entry.usage.estimated_cost_usd,
            final_identity.map(|identity| identity.runner_kind.as_str()),
            entry.usage.backend_instance,
            entry.usage.account_label,
            entry.usage.auth_source_label,
            entry.usage.provider,
            entry.usage.provider_attribution_source,
            entry.usage.usage_classification,
            entry.usage.quota_pool,
            entry.usage.actual_model,
            raw_json,
        ],
    )?;
    Ok(())
}

/// Rebuild the mirror wholesale from the JSONL ledger (still
/// authoritative) rather than incrementally inserting/updating rows in
/// lockstep with `append`/`backfill_review_verdict`. A full rebuild
/// trivially can't drift from the JSONL it's derived from, which an
/// incremental dual-write easily could (e.g. `backfill_review_verdict`
/// rewrites an arbitrary earlier line, not just the latest one).
pub fn sync_from_jsonl(cfg: &GahConfig) -> Result<()> {
    let _mirror_lock = locking::mirror_exclusive(&cfg.defaults.ledger_path())?;
    sync_incremental_from_jsonl(cfg)
}

pub fn rebuild_from_jsonl(cfg: &GahConfig) -> Result<()> {
    let _mirror_lock = locking::mirror_exclusive(&cfg.defaults.ledger_path())?;
    let snapshot = jsonl::read_snapshot(cfg)?;
    sync_full_from_entries(cfg, &snapshot.entries, snapshot.byte_len)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ledger::append;
    use crate::ledger::test_util::{profile, test_config};

    #[test]
    fn schema_upgrade_adds_review_generation_columns_idempotently() {
        let conn = Connection::open_in_memory().unwrap();
        conn.execute_batch(
            "CREATE TABLE ledger_entries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                profile TEXT NOT NULL,
                work_id TEXT,
                mode TEXT NOT NULL,
                backend TEXT NOT NULL,
                effective_backend TEXT NOT NULL,
                human_required INTEGER NOT NULL,
                raw_json TEXT NOT NULL
            );",
        )
        .unwrap();

        ensure_schema(&conn).unwrap();
        ensure_schema(&conn).unwrap();

        assert!(has_column(&conn, "ledger_entries", "review_contract_version").unwrap());
        assert!(has_column(&conn, "ledger_entries", "review_generation").unwrap());
        assert!(has_column(&conn, "ledger_entries", "human_required_reason_code").unwrap());
        for column in [
            "repo_id",
            "runner_kind",
            "backend_instance",
            "account_label",
            "auth_source_label",
            "model_provider",
            "provider_attribution_source",
            "auth_class",
            "quota_pool",
            "actual_model",
        ] {
            assert!(
                has_column(&conn, "ledger_entries", column).unwrap(),
                "{column}"
            );
        }
    }

    #[test]
    fn sqlite_projects_canonical_identity_without_credentials_or_paths() {
        let (_tmp, cfg) = test_config();
        let mut entry =
            LedgerEntry::new("test", &profile(), "auto", "improve", "target", None, None);
        let mut identity = crate::execution_identity::ExecutionIdentity::legacy_route(
            "auto",
            Some("requested"),
            "opencode",
            Some("provider/model"),
            Some("paid-pool"),
        );
        identity.auth_source_label = Some("opencode-key-main".into());
        identity.set_executable(Some(PathBuf::from("/secret/home/bin/opencode")));
        entry
            .attempt_routing
            .push(crate::ledger::AttemptRoutingRecord {
                attempt_number: 1,
                backend_instance: identity.backend_instance.clone(),
                effective_model: identity.effective_model.clone(),
                identity: Some(identity),
                routing_diagnostics: None,
            });
        entry.usage = crate::ledger::LedgerUsage {
            backend_instance: Some("opencode:paid-pool".into()),
            account_label: Some("billing-main".into()),
            auth_source_label: Some("opencode-key-main".into()),
            provider: Some("openai".into()),
            provider_attribution_source: Some("backend_reported".into()),
            usage_classification: Some("api_key_backed".into()),
            quota_pool: Some("paid-pool".into()),
            actual_model: Some("gpt-5".into()),
            ..crate::ledger::LedgerUsage::default()
        };

        append(&cfg, &entry).unwrap();
        let conn = Connection::open(db_path(&cfg)).unwrap();
        let values: (
            String,
            String,
            String,
            String,
            String,
            String,
            String,
            String,
        ) = conn
            .query_row(
                "SELECT runner_kind, backend_instance, account_label, auth_source_label,
                        model_provider, auth_class, quota_pool, actual_model
                 FROM ledger_entries LIMIT 1",
                [],
                |row| {
                    Ok((
                        row.get(0)?,
                        row.get(1)?,
                        row.get(2)?,
                        row.get(3)?,
                        row.get(4)?,
                        row.get(5)?,
                        row.get(6)?,
                        row.get(7)?,
                    ))
                },
            )
            .unwrap();
        assert_eq!(
            values,
            (
                "opencode".into(),
                "opencode:paid-pool".into(),
                "billing-main".into(),
                "opencode-key-main".into(),
                "openai".into(),
                "api_key_backed".into(),
                "paid-pool".into(),
                "gpt-5".into(),
            )
        );
        let raw: String = conn
            .query_row("SELECT raw_json FROM ledger_entries LIMIT 1", [], |row| {
                row.get(0)
            })
            .unwrap();
        assert!(!raw.contains("/secret/home"));
        assert!(!raw.contains("executable"));
    }

    #[test]
    fn sync_mirrors_appended_entries_and_stays_in_lockstep_on_backfill() {
        let (_tmp, cfg) = test_config();

        let mut entry =
            LedgerEntry::new("test", &profile(), "codex", "improve", "target", None, None);
        entry.branch = Some("gah/test-1".to_string());
        entry.effective_model = Some("gpt-5".to_string());
        append(&cfg, &entry).unwrap();

        let db_path = db_path(&cfg);
        let conn = Connection::open(&db_path).unwrap();
        let count: i64 = conn
            .query_row("SELECT COUNT(*) FROM ledger_entries", [], |r| r.get(0))
            .unwrap();
        assert_eq!(count, 1);
        let review_verdict: Option<String> = conn
            .query_row(
                "SELECT review_verdict FROM ledger_entries LIMIT 1",
                [],
                |r| r.get(0),
            )
            .unwrap();
        assert_eq!(review_verdict, None);

        super::super::backfill_review_verdict(
            &cfg,
            "gah/test-1",
            super::super::ReviewVerdictBackfill {
                verdict: "APPROVE",
                confidence: "high",
                reviewer_backend: "claude",
                reviewer_model: Some("claude-sonnet-4"),
                reviewer_tier: None,
                review_gate_reason: None,
                review_source_sha: None,
                review_metadata_fingerprint: None,
                review_contract_version: None,
                review_generation: None,
                blocking_findings: &[],
                actionable_findings: &[],
                non_blocking_findings: &[],
                risk_notes: &[],
                evidence: &[],
                compatibility_evidence: &[],
            },
        )
        .unwrap();

        let review_verdict: Option<String> = conn
            .query_row(
                "SELECT review_verdict FROM ledger_entries LIMIT 1",
                [],
                |r| r.get(0),
            )
            .unwrap();
        assert_eq!(review_verdict.as_deref(), Some("APPROVE"));
    }

    #[test]
    fn sync_incrementally_appends_without_rereading_the_full_ledger() {
        let (_tmp, cfg) = test_config();
        crate::ledger::reset_read_entries_call_count(&cfg);

        let mut first = LedgerEntry::new(
            "test",
            &profile(),
            "codex",
            "improve",
            "target-a",
            None,
            None,
        );
        first.branch = Some("gah/test-1".to_string());
        append(&cfg, &first).unwrap();
        assert_eq!(crate::ledger::read_entries_call_count(&cfg), 1);

        let db_path = db_path(&cfg);
        let conn = Connection::open(&db_path).unwrap();
        let count_after_first: i64 = conn
            .query_row("SELECT COUNT(*) FROM ledger_entries", [], |r| r.get(0))
            .unwrap();
        assert_eq!(count_after_first, 1);

        let mut second = LedgerEntry::new(
            "test",
            &profile(),
            "codex",
            "improve",
            "target-b",
            None,
            None,
        );
        second.branch = Some("gah/test-2".to_string());
        append(&cfg, &second).unwrap();
        assert_eq!(crate::ledger::read_entries_call_count(&cfg), 1);

        let count_after_second: i64 = conn
            .query_row("SELECT COUNT(*) FROM ledger_entries", [], |r| r.get(0))
            .unwrap();
        assert_eq!(count_after_second, 2);
    }

    #[test]
    fn incremental_sync_waits_for_complete_jsonl_tail_and_records_exact_offset() {
        use std::io::Write as _;
        use std::sync::mpsc;
        use std::time::Duration;

        let (_tmp, cfg) = test_config();
        let first = LedgerEntry::new("test", &profile(), "codex", "improve", "first", None, None);
        append(&cfg, &first).unwrap();

        let second = LedgerEntry::new("test", &profile(), "codex", "improve", "second", None, None);
        let encoded = serde_json::to_vec(&second).unwrap();
        let split = encoded.len() / 2;
        let ledger_path = cfg.defaults.ledger_path();
        let writer_lock = crate::ledger::locking::exclusive(&ledger_path).unwrap();
        let mut file = std::fs::OpenOptions::new()
            .append(true)
            .open(&ledger_path)
            .unwrap();
        file.write_all(&encoded[..split]).unwrap();
        file.flush().unwrap();

        std::thread::scope(|scope| {
            let (started_tx, started_rx) = mpsc::channel();
            let (done_tx, done_rx) = mpsc::channel();
            let sync_cfg = &cfg;
            scope.spawn(move || {
                started_tx.send(()).unwrap();
                done_tx.send(sync_from_jsonl(sync_cfg)).unwrap();
            });
            started_rx.recv_timeout(Duration::from_secs(1)).unwrap();
            assert!(matches!(
                done_rx.recv_timeout(Duration::from_millis(100)),
                Err(mpsc::RecvTimeoutError::Timeout)
            ));

            file.write_all(&encoded[split..]).unwrap();
            file.write_all(b"\n").unwrap();
            file.flush().unwrap();
            drop(file);
            drop(writer_lock);
            done_rx
                .recv_timeout(Duration::from_secs(2))
                .unwrap()
                .unwrap();
        });

        let conn = Connection::open(db_path(&cfg)).unwrap();
        let row_count: u64 = conn
            .query_row("SELECT COUNT(*) FROM ledger_entries", [], |row| row.get(0))
            .unwrap();
        let synced_len: u64 = conn
            .query_row(
                "SELECT synced_byte_len FROM ledger_sync_state WHERE id = 1",
                [],
                |row| row.get(0),
            )
            .unwrap();
        assert_eq!(row_count, 2);
        assert_eq!(synced_len, fs::metadata(ledger_path).unwrap().len());
    }

    #[test]
    fn failed_full_rebuild_preserves_previous_rows_and_sync_state() {
        let (_tmp, cfg) = test_config();
        let first = LedgerEntry::new(
            "test",
            &profile(),
            "codex",
            "improve",
            "original",
            None,
            None,
        );
        append(&cfg, &first).unwrap();

        let db_path = db_path(&cfg);
        let conn = Connection::open(&db_path).unwrap();
        let state_before: (i64, i64) = conn
            .query_row(
                "SELECT synced_byte_len, synced_entry_count FROM ledger_sync_state WHERE id = 1",
                [],
                |row| Ok((row.get(0)?, row.get(1)?)),
            )
            .unwrap();
        conn.execute_batch(
            "CREATE TRIGGER reject_rebuild BEFORE INSERT ON ledger_entries
             BEGIN SELECT RAISE(FAIL, 'injected rebuild failure'); END;",
        )
        .unwrap();
        drop(conn);

        let replacement = LedgerEntry::new(
            "test",
            &profile(),
            "codex",
            "improve",
            "replacement",
            None,
            None,
        );
        let error =
            sync_full_from_entries(&cfg, &[replacement], state_before.0 as u64).unwrap_err();
        assert!(error.to_string().contains("injected rebuild failure"));

        let conn = Connection::open(&db_path).unwrap();
        let rows: Vec<String> = conn
            .prepare("SELECT raw_json FROM ledger_entries ORDER BY id")
            .unwrap()
            .query_map([], |row| row.get(0))
            .unwrap()
            .collect::<rusqlite::Result<_>>()
            .unwrap();
        assert_eq!(rows.len(), 1);
        assert!(rows[0].contains("original"));
        let state_after: (i64, i64) = conn
            .query_row(
                "SELECT synced_byte_len, synced_entry_count FROM ledger_sync_state WHERE id = 1",
                [],
                |row| Ok((row.get(0)?, row.get(1)?)),
            )
            .unwrap();
        assert_eq!(state_after, state_before);
    }
}
