use super::issues::{fetch_dependency_issue, DependencyIssue, IssueDetails};
use crate::config::Profile;
use crate::models::{DependencyBlocker, DependencyObservation};
use crate::provider::{gitlab_api, gitlab_project_id, provider_command};
use anyhow::Result;
use std::collections::{BTreeMap, HashMap, HashSet};

#[derive(Debug, Clone)]
enum CachedIssue {
    Found(DependencyIssue),
    Error(String),
}

/// Typed errors for dependency relationship failures that fail closed.
#[derive(Debug, Clone)]
pub enum DependencyRelationshipError {
    /// Permission denied when accessing provider API
    PermissionDenied { message: String },
    /// Pagination failed or exceeded limits
    PaginationError { message: String },
    /// Provider API version is unsupported
    UnsupportedServerVersion { message: String },
    /// Response from provider was malformed or invalid
    MalformedResponse { message: String },
    /// Other provider-specific error
    ProviderError { message: String },
}

impl std::fmt::Display for DependencyRelationshipError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            DependencyRelationshipError::PermissionDenied { message } => {
                write!(f, "permission denied: {message}")
            }
            DependencyRelationshipError::PaginationError { message } => {
                write!(f, "pagination error: {message}")
            }
            DependencyRelationshipError::UnsupportedServerVersion { message } => {
                write!(f, "unsupported server version: {message}")
            }
            DependencyRelationshipError::MalformedResponse { message } => {
                write!(f, "malformed response: {message}")
            }
            DependencyRelationshipError::ProviderError { message } => {
                write!(f, "provider error: {message}")
            }
        }
    }
}

impl std::error::Error for DependencyRelationshipError {}

/// Represents a dependency relationship source with provenance
#[derive(Debug, Clone)]
pub(crate) struct DependencySource {
    /// The issue number that has this dependency
    pub source_issue: String,
    /// The target dependency issue number
    pub target_issue: String,
    /// The provenance of this relationship
    pub provenance: String,
}

fn is_local_issue_reference(reference: &str) -> bool {
    !reference.is_empty() && reference.bytes().all(|byte| byte.is_ascii_digit())
}

fn dependency_identity(reference: &str) -> String {
    if is_local_issue_reference(reference) {
        format!("#{reference}")
    } else {
        reference.to_string()
    }
}

fn dependency_provider(reference: &str, fallback: &str) -> String {
    reference
        .split_once(':')
        .map(|(provider, _)| provider.to_string())
        .unwrap_or_else(|| fallback.to_string())
}

/// Fetch native GitHub sub-issue relationships for a given issue.
/// Returns a list of issue numbers that are sub-issues (children) of the parent.
/// This reads the native GitHub sub-issue API relationship.
///
/// Wired into `fetch_native_dependencies` below as a blocked-by relationship:
/// per issue #658's acceptance criteria ("native blocked-by/sub-issue/link
/// relationships"), a parent issue is intentionally treated as blocked until
/// all of its sub-issues close, mirroring GitLab's native `blocks`/
/// `is_blocked_by` links and GitHub's own "Tracked by" UI semantics. This is
/// not an accidental inversion of GitHub's parent/child direction -- it is
/// the deliberate contract this ticket asks for.
pub(crate) fn fetch_github_sub_issues(
    profile: &Profile,
    parent_number: &str,
) -> Result<Vec<String>, DependencyRelationshipError> {
    if profile.provider != "github" {
        return Ok(Vec::new());
    }

    let endpoint = format!("repos/{}/issues/{parent_number}/sub_issues", profile.repo);
    let issues = github_list_pages(&endpoint)?;

    let mut sub_issue_numbers = Vec::new();
    for issue in &issues {
        if let Some(number) = issue["number"].as_u64() {
            let number = number.to_string();
            if number != parent_number {
                sub_issue_numbers.push(number);
            }
        }
    }

    Ok(sub_issue_numbers)
}

/// Every item of a GitHub list endpoint, across all pages (`gh` defaults to
/// 30 per page). A 404 means the endpoint is unavailable, so no relationships.
/// A malformed or over-long response is an error, never a partial list.
pub(crate) fn github_list_pages(
    endpoint: &str,
) -> Result<Vec<serde_json::Value>, DependencyRelationshipError> {
    const MAX_PAGES: usize = 100;
    let output = provider_command("gh")
        .args(["api", "--method", "GET", endpoint])
        .args(["--paginate", "--slurp", "-f", "per_page=100"])
        .output()
        .map_err(|e| DependencyRelationshipError::ProviderError {
            message: format!("gh api list {endpoint} failed: {e}"),
        })?;

    if !output.status.success() {
        let stderr = crate::redact::redact(String::from_utf8_lossy(&output.stderr).trim());
        let lower = stderr.to_ascii_lowercase();

        // Classify the error based on the response
        if lower.contains("403") || lower.contains("permission") || lower.contains("denied") {
            return Err(DependencyRelationshipError::PermissionDenied {
                message: format!("GitHub API permission denied for {endpoint}: {stderr}"),
            });
        }
        if lower.contains("404") || lower.contains("not found") {
            // Sub-issues API might not be available on older GitHub instances
            // or the endpoint might not exist - this is not an error, just no relationships
            return Ok(Vec::new());
        }
        if lower.contains("400") || lower.contains("bad request") {
            return Err(DependencyRelationshipError::MalformedResponse {
                message: format!("GitHub API bad request for {endpoint}: {stderr}"),
            });
        }
        if lower.contains("429") || lower.contains("rate limit") {
            return Err(DependencyRelationshipError::PaginationError {
                message: format!("GitHub API rate limited for {endpoint}: {stderr}"),
            });
        }

        return Err(DependencyRelationshipError::ProviderError {
            message: format!("GitHub API error for {endpoint}: {stderr}"),
        });
    }

    let malformed = |detail: &str| DependencyRelationshipError::MalformedResponse {
        message: format!("GitHub list {endpoint}: {detail}"),
    };
    let value: serde_json::Value = serde_json::from_slice(&output.stdout)
        .map_err(|e| malformed(&format!("cannot parse response: {e}")))?;
    // `--slurp` wraps each page in an outer array; a bare list of objects is
    // accepted as one page.
    let pages = value
        .as_array()
        .ok_or_else(|| malformed("expected an array"))?;
    if pages.len() > MAX_PAGES {
        return Err(DependencyRelationshipError::PaginationError {
            message: format!(
                "GitHub list {endpoint} reached {MAX_PAGES} pages; refusing a partial list"
            ),
        });
    }
    let mut items = Vec::new();
    for page in pages {
        match page {
            serde_json::Value::Array(entries) => items.extend(entries.iter().cloned()),
            serde_json::Value::Object(_) => items.push(page.clone()),
            _ => return Err(malformed("page was not an array")),
        }
    }
    Ok(items)
}

/// Fetch native GitLab issue link relationships (blocks type) for a given issue.
/// Returns a list of issue numbers that this issue is blocked by.
/// This reads the native GitLab issue links API and resolves incoming blocker
/// edges for dependency-style evaluation.
pub(crate) fn fetch_gitlab_blocks_links(
    profile: &Profile,
    issue_number: &str,
) -> Result<Vec<String>, DependencyRelationshipError> {
    if profile.provider != "gitlab" {
        return Ok(Vec::new());
    }

    let project_id =
        gitlab_project_id(profile).map_err(|error| DependencyRelationshipError::ProviderError {
            message: error.to_string(),
        })?;

    let endpoint = format!("projects/{project_id}/issues/{issue_number}/links");
    let result = gitlab_api(profile, &endpoint, "GET", &[]);

    match result {
        Ok(value) => {
            let links =
                value
                    .as_array()
                    .ok_or_else(|| DependencyRelationshipError::MalformedResponse {
                        message: format!("Expected array of issue links, got: {value}"),
                    })?;

            let mut blocked_numbers = Vec::new();
            for link in links {
                let link_type = link["link_type"].as_str().unwrap_or_default();
                if link_type != "blocks" && link_type != "is_blocked_by" {
                    continue;
                }

                // The list endpoint returns the *other* issue at the top level
                // (`iid`, `project_id`) with `link_type` relative to this one.
                if link.get("source_issue").is_none() && link.get("source_issue_iid").is_none() {
                    let same_project = link["project_id"]
                        .as_u64()
                        .map(|id| id.to_string())
                        .or_else(|| link["project_id"].as_str().map(ToString::to_string))
                        .is_none_or(|id| !is_local_issue_reference(project_id) || id == project_id);
                    if link_type == "is_blocked_by" && same_project {
                        if let Some(iid) = link["iid"].as_u64() {
                            blocked_numbers.push(iid.to_string());
                        }
                    }
                    continue;
                }

                let source_issue = link
                    .pointer("/source_issue/iid")
                    .and_then(|value| value.as_u64())
                    .map(|id| id.to_string())
                    .or_else(|| link["source_issue_iid"].as_u64().map(|id| id.to_string()))
                    .or_else(|| link["source_issue_iid"].as_str().map(ToString::to_string));

                let target_issue = link
                    .pointer("/target_issue/iid")
                    .and_then(|value| value.as_u64())
                    .map(|id| id.to_string())
                    .or_else(|| link["target_issue_iid"].as_u64().map(|id| id.to_string()))
                    .or_else(|| link["target_issue_iid"].as_str().map(ToString::to_string));

                if let (Some(source), Some(target)) = (source_issue, target_issue) {
                    match link_type {
                        "blocks" if target == issue_number => {
                            blocked_numbers.push(source);
                        }
                        "is_blocked_by" if source == issue_number => {
                            blocked_numbers.push(target);
                        }
                        _ => {}
                    }
                }
            }
            Ok(blocked_numbers)
        }
        Err(error) => {
            let error_str = error.to_string().to_ascii_lowercase();

            if error_str.contains("403")
                || error_str.contains("permission")
                || error_str.contains("denied")
            {
                Err(DependencyRelationshipError::PermissionDenied {
                    message: format!("GitLab API permission denied for {endpoint}: {error}"),
                })
            } else if error_str.contains("404") || error_str.contains("not found") {
                // Issue links might not be available - not an error, just no relationships
                Ok(Vec::new())
            } else if error_str.contains("429") || error_str.contains("rate limit") {
                Err(DependencyRelationshipError::PaginationError {
                    message: format!("GitLab API rate limited for {endpoint}: {error}"),
                })
            } else if error_str.contains("version") || error_str.contains("unsupported") {
                Err(DependencyRelationshipError::UnsupportedServerVersion {
                    message: format!("GitLab API unsupported version for {endpoint}: {error}"),
                })
            } else {
                Err(DependencyRelationshipError::ProviderError {
                    message: format!("GitLab API error for {endpoint}: {error}"),
                })
            }
        }
    }
}

/// Fetch native dependencies for an issue from provider APIs.
/// Returns a list of DependencySource representing the native relationships.
pub(crate) fn fetch_native_dependencies(
    profile: &Profile,
    issue_number: &str,
) -> Result<Vec<DependencySource>, DependencyRelationshipError> {
    match profile.provider.as_str() {
        "github" => {
            let sub_issues = fetch_github_sub_issues(profile, issue_number)?;
            Ok(sub_issues
                .into_iter()
                .map(|child| DependencySource {
                    source_issue: issue_number.to_string(),
                    target_issue: child,
                    provenance: "github_sub_issue".to_string(),
                })
                .collect())
        }
        "gitlab" => {
            // For GitLab, fetch blocks links which indicate what blocks this issue.
            let blocked = fetch_gitlab_blocks_links(profile, issue_number)?;
            Ok(blocked
                .into_iter()
                .map(|target| DependencySource {
                    source_issue: issue_number.to_string(),
                    target_issue: target,
                    provenance: "gitlab_blocks_link".to_string(),
                })
                .collect())
        }
        _ => Ok(Vec::new()),
    }
}

#[derive(Debug, Clone)]
pub(crate) struct DependencyFailure {
    code: &'static str,
    message: String,
}

pub(crate) fn parse_dependency_line(body: &str) -> Result<Option<Vec<String>>, DependencyFailure> {
    let candidates: Vec<&str> = body
        .lines()
        .map(str::trim)
        .filter(|line| line.to_ascii_lowercase().starts_with("blocked by"))
        .collect();
    if candidates.is_empty() {
        return Ok(None);
    }
    if candidates.len() != 1 {
        return Err(DependencyFailure {
            code: "dependency_ambiguous",
            message: "multiple 'Blocked by:' compatibility lines are not allowed".into(),
        });
    }

    let line = candidates[0];
    let Some(payload) = line.strip_prefix("Blocked by:") else {
        return Err(DependencyFailure {
            code: "dependency_malformed",
            message: "dependency line must use exact syntax 'Blocked by: #12, #34'".into(),
        });
    };
    if payload.trim().is_empty() {
        return Err(DependencyFailure {
            code: "dependency_malformed",
            message: "dependency line contains no issue references".into(),
        });
    }

    let mut seen = HashSet::new();
    let mut references = Vec::new();
    for raw in payload.split(',') {
        let token = raw.trim();

        // Check if this is a cross-project dependency reference
        // Format: provider:project_id#number (e.g., github:owner/repo#123, gitlab:12345#678)
        if token.contains(':') && token.contains('#') {
            // This is a cross-project dependency - keep project identity
            // in the reference so we do not collapse to a local number.
            let parts: Vec<&str> = token.split('#').collect();
            if parts.len() == 2 {
                let before_hash = parts[0]; // Should be "provider:project_id"
                let number = parts[1].trim();

                // Validate that we have a proper provider:project_id format
                let provider_parts: Vec<&str> = before_hash.split(':').collect();
                if provider_parts.len() != 2
                    || provider_parts[0].is_empty()
                    || provider_parts[1].is_empty()
                {
                    return Err(DependencyFailure {
                        code: "dependency_malformed",
                        message: format!("invalid cross-project dependency reference '{token}'"),
                    });
                }

                // Validate the issue number
                if number.is_empty()
                    || !number.bytes().all(|byte| byte.is_ascii_digit())
                    || number.starts_with('0')
                {
                    return Err(DependencyFailure {
                        code: "dependency_malformed",
                        message: format!("invalid cross-project dependency reference '{token}'"),
                    });
                }
                if !seen.insert(format!("{before_hash}#{number}")) {
                    return Err(DependencyFailure {
                        code: "dependency_duplicate",
                        message: format!("duplicate dependency reference '{token}'"),
                    });
                }
                references.push(format!("{before_hash}#{number}"));
                continue;
            }
        }

        // Handle same-project dependency reference
        let Some(number) = token.strip_prefix('#') else {
            return Err(DependencyFailure {
                code: "dependency_malformed",
                message: format!("invalid dependency reference '{token}'"),
            });
        };
        if number.is_empty()
            || !number.bytes().all(|byte| byte.is_ascii_digit())
            || number.starts_with('0')
        {
            return Err(DependencyFailure {
                code: "dependency_malformed",
                message: format!("invalid dependency reference '{token}'"),
            });
        }
        if !seen.insert(number.to_string()) {
            return Err(DependencyFailure {
                code: "dependency_duplicate",
                message: format!("duplicate dependency reference '#{number}'"),
            });
        }
        references.push(number.to_string());
    }
    Ok(Some(references))
}

fn normalize_state(state: Option<&str>) -> &'static str {
    match state.map(str::to_ascii_lowercase).as_deref() {
        Some("open" | "opened") => "open",
        Some("closed") => "closed",
        _ => "unknown",
    }
}

struct Resolver<'a, F>
where
    F: FnMut(&str) -> Result<DependencyIssue, String>,
{
    provider: &'a str,
    cache: HashMap<String, CachedIssue>,
    fetch: F,
}

impl<'a, F> Resolver<'a, F>
where
    F: FnMut(&str) -> Result<DependencyIssue, String>,
{
    fn resolve(&mut self, number: &str) -> CachedIssue {
        if let Some(cached) = self.cache.get(number) {
            return cached.clone();
        }
        let resolved = match (self.fetch)(number) {
            Ok(issue) => CachedIssue::Found(issue),
            Err(error) => CachedIssue::Error(error),
        };
        self.cache.insert(number.to_string(), resolved.clone());
        resolved
    }

    /// Walk the dependency graph with provenance tracking.
    /// This allows tracking which source (native vs body) each dependency came from.
    fn walk_with_provenance(
        &mut self,
        current: &str,
        references: &[String],
        stack: &mut Vec<String>,
        observations: &mut Vec<DependencyObservation>,
        provenance_map: &mut HashMap<String, String>,
    ) -> Result<bool, DependencyFailure> {
        let mut has_open = false;
        let mut blocked_error = None;
        for number in references {
            if !is_local_issue_reference(number) {
                let provider = dependency_provider(number, self.provider);
                if let Some(provenance) = provenance_map.get(number).cloned() {
                    observations.push(DependencyObservation {
                        identity: dependency_identity(number),
                        provider,
                        provider_state: None,
                        normalized_state: "inaccessible".into(),
                        provenance: Some(provenance),
                    });
                } else {
                    observations.push(DependencyObservation {
                        identity: dependency_identity(number),
                        provider,
                        provider_state: None,
                        normalized_state: "inaccessible".into(),
                        provenance: None,
                    });
                }
                if blocked_error.is_none() {
                    blocked_error = Some(DependencyFailure {
                        code: "dependency_query_failed",
                        message: format!("cannot resolve cross-project dependency '{number}'"),
                    });
                }
                continue;
            }

            if number == current || stack.contains(number) {
                let mut cycle = stack.clone();
                cycle.push(number.clone());
                return Err(DependencyFailure {
                    code: "dependency_cycle",
                    message: format!(
                        "dependency cycle detected: {}",
                        cycle
                            .iter()
                            .map(|part| dependency_identity(part))
                            .collect::<Vec<_>>()
                            .join(" -> ")
                    ),
                });
            }

            let issue = match self.resolve(number) {
                CachedIssue::Found(issue) => issue,
                CachedIssue::Error(error) => {
                    let lower = error.to_ascii_lowercase();
                    let (code, label) = if lower.contains("not found") || lower.contains("404") {
                        ("dependency_missing", "missing")
                    } else {
                        ("dependency_query_failed", "inaccessible")
                    };
                    // Store provenance for this observation if available
                    if let Some(provenance) = provenance_map.get(number).cloned() {
                        observations.push(DependencyObservation {
                            identity: dependency_identity(number),
                            provider: self.provider.to_string(),
                            provider_state: None,
                            normalized_state: label.into(),
                            provenance: Some(provenance),
                        });
                    } else {
                        observations.push(DependencyObservation {
                            identity: dependency_identity(number),
                            provider: self.provider.to_string(),
                            provider_state: None,
                            normalized_state: label.into(),
                            provenance: None,
                        });
                    }
                    if blocked_error.is_none() {
                        blocked_error = Some(DependencyFailure {
                            code,
                            message: format!(
                                "could not resolve dependency {}: {error}",
                                dependency_identity(number)
                            ),
                        });
                    }
                    continue;
                }
            };

            let normalized = normalize_state(issue.state.as_deref());
            let identity = format!("#{}", issue.number);

            if !observations.iter().any(|seen| seen.identity == identity) {
                // Apply provenance from the map if available
                let provenance = provenance_map.get(number).cloned();
                let provenance_for_obs = provenance.clone();
                observations.push(DependencyObservation {
                    identity: identity.clone(),
                    provider: self.provider.to_string(),
                    provider_state: issue.state.clone(),
                    normalized_state: normalized.into(),
                    provenance: provenance_for_obs,
                });
                // Store the identity for provenance mapping
                if let Some(provenance) = provenance {
                    provenance_map.insert(identity, provenance);
                }
            }

            match normalized {
                "closed" => continue,
                "unknown" => {
                    if blocked_error.is_none() {
                        blocked_error = Some(DependencyFailure {
                            code: "dependency_unknown_state",
                            message: format!(
                                "dependency {} has unknown provider state",
                                dependency_identity(number)
                            ),
                        });
                    }
                    continue;
                }
                "open" => has_open = true,
                _ => unreachable!(),
            }

            // For nested dependencies, we need to parse the body and continue walking
            // This maintains compatibility with the existing body-based dependency parsing
            let nested = parse_dependency_line(&issue.body)?;
            if let Some(nested) = nested {
                stack.push(number.clone());
                let nested_open = self.walk_with_provenance(
                    number,
                    &nested,
                    stack,
                    observations,
                    provenance_map,
                )?;
                stack.pop();
                has_open |= nested_open;
            }
        }
        if let Some(error) = blocked_error {
            Err(error)
        } else {
            Ok(has_open)
        }
    }
}

/// Test-only harness that exercises the same `walk_with_provenance` graph
/// walk `evaluate_issue_dependencies` uses in production, but with a plain
/// closure-based fetch function instead of real provider fixtures -- kept
/// for algorithm-level tests (cycles, caching, cross-project handling) that
/// don't need real GitHub/GitLab responses.
#[cfg(test)]
fn evaluate_with<F>(provider: &str, issues: &[IssueDetails], mut fetch: F) -> Vec<DependencyBlocker>
where
    F: FnMut(&str) -> Result<DependencyIssue, String>,
{
    let mut cache = HashMap::new();
    for issue in issues {
        cache.insert(
            issue.number.clone(),
            CachedIssue::Found(DependencyIssue {
                number: issue.number.clone(),
                body: issue.body.clone(),
                state: issue.state.clone(),
            }),
        );
    }
    let mut resolver = Resolver {
        provider,
        cache,
        fetch: &mut fetch,
    };
    let mut blockers = Vec::new();

    for issue in issues {
        let parsed = parse_dependency_line(&issue.body);
        let mut observations = Vec::new();
        let outcome = match parsed {
            Ok(None) => continue,
            Ok(Some(references)) => resolver
                .walk_with_provenance(
                    &issue.number,
                    &references,
                    &mut vec![issue.number.clone()],
                    &mut observations,
                    &mut HashMap::new(),
                )
                .and_then(|has_open| {
                    if has_open {
                        Err(DependencyFailure {
                            code: "dependency_open",
                            message: "one or more declared prerequisites remain open".into(),
                        })
                    } else {
                        Ok(false)
                    }
                }),
            Err(error) => Err(error),
        };
        if let Err(error) = outcome {
            blockers.push(DependencyBlocker {
                ticket_path: issue.number.clone(),
                work_id: format!("#{}", issue.number),
                title: issue.title.clone(),
                reason_code: error.code.into(),
                reason: error.message,
                dependencies: observations,
            });
        }
    }
    blockers
}

/// Enhanced dependency evaluation that merges native provider relationships
/// with body-declared relationships, deduplicating exact matches.
///
/// For GitLab: reads native blocks issue links via the issue links API. For
/// GitHub: reads native sub-issues and treats them as blocked-by
/// relationships (see `fetch_github_sub_issues`'s doc comment for why this
/// direction is intentional).
///
/// Both sources are normalized into the same dependency identity/state model
/// with provenance metadata indicating the source.
pub(super) fn evaluate_issue_dependencies(
    profile: &Profile,
    issues: &[IssueDetails],
) -> Vec<DependencyBlocker> {
    let mut blockers = Vec::new();

    // Build a set of all known issue numbers for quick lookup
    let _known_issue_numbers: HashSet<String> =
        issues.iter().map(|issue| issue.number.clone()).collect();

    // First, collect all dependency relationships from both sources
    let mut all_dependencies: HashMap<String, Vec<DependencySource>> = HashMap::new();

    // 1. Collect body-declared relationships (canonical fallback)
    for issue in issues {
        if let Ok(Some(references)) = parse_dependency_line(&issue.body) {
            let entry = all_dependencies.entry(issue.number.clone()).or_default();
            for ref_num in references {
                entry.push(DependencySource {
                    source_issue: issue.number.clone(),
                    target_issue: ref_num,
                    provenance: "body".to_string(),
                });
            }
        }
    }

    // 2. Collect native provider relationships. One provider call per issue,
    // run concurrently: serially this dominated `gah status` (#1277).
    let fetched = crate::provider::parallel_provider_map(issues, 16, |issue| {
        fetch_native_dependencies(profile, &issue.number)
    });
    for (issue, fetched) in issues.iter().zip(fetched) {
        let native_deps = match fetched {
            Ok(deps) => deps,
            Err(error) => {
                let reason_code = match &error {
                    DependencyRelationshipError::UnsupportedServerVersion { .. } => None,
                    _ => Some("dependency_query_failed"),
                };

                if let Some(reason_code) = reason_code {
                    blockers.push(DependencyBlocker {
                        ticket_path: issue.number.clone(),
                        work_id: format!("#{}", issue.number),
                        title: issue.title.clone(),
                        reason_code: reason_code.into(),
                        reason: error.to_string(),
                        dependencies: Vec::new(),
                    });
                }
                continue;
            }
        };

        for dep in native_deps {
            let entry = all_dependencies
                .entry(dep.source_issue.clone())
                .or_default();
            entry.push(dep);
        }
    }

    // 3. Deduplicate exact matches - keep only one copy of each unique (source, target) pair
    // For duplicates, prefer native provider relationships over body-declared ones
    let mut deduplicated: HashMap<String, Vec<DependencySource>> = HashMap::new();
    for (source, deps) in all_dependencies {
        let unique_deps = deps;

        // Second pass: prefer native provider relationships over body ones
        let mut final_deps = Vec::new();
        let mut deduped_map: BTreeMap<String, DependencySource> = BTreeMap::new();
        for dep in unique_deps {
            let key = format!("{}:{}", dep.source_issue, dep.target_issue);
            let is_native = matches!(
                dep.provenance.as_str(),
                "gitlab_blocks_link" | "github_sub_issue"
            );
            match deduped_map.get(&key) {
                Some(existing) if existing.provenance == "body" && is_native => {
                    deduped_map.insert(key, dep);
                }
                Some(_) => {}
                None => {
                    deduped_map.insert(key, dep);
                }
            }
        }
        final_deps.extend(deduped_map.into_values());

        deduplicated.insert(source, final_deps);
    }
    // 4. Now evaluate the merged dependency graph
    let mut cache = HashMap::new();
    for issue in issues {
        cache.insert(
            issue.number.clone(),
            CachedIssue::Found(DependencyIssue {
                number: issue.number.clone(),
                body: issue.body.clone(),
                state: issue.state.clone(),
            }),
        );
    }

    // Prefetch first-level targets concurrently so the serial walk below hits
    // the cache; only deeper body-declared chains still fetch one at a time.
    let mut missing: Vec<String> = deduplicated
        .values()
        .flatten()
        .map(|dep| dep.target_issue.clone())
        .filter(|number| is_local_issue_reference(number) && !cache.contains_key(number))
        .collect();
    missing.sort();
    missing.dedup();
    let prefetched =
        crate::provider::parallel_provider_map(
            &missing,
            16,
            |number| match fetch_dependency_issue(profile, number) {
                Ok(issue) => CachedIssue::Found(issue),
                Err(error) => CachedIssue::Error(format!("{error:#}")),
            },
        );
    cache.extend(missing.into_iter().zip(prefetched));

    let mut resolver = Resolver {
        provider: &profile.provider,
        cache,
        fetch: |number| {
            fetch_dependency_issue(profile, number).map_err(|error| format!("{error:#}"))
        },
    };

    for issue in issues {
        let deps = deduplicated.get(&issue.number).cloned().unwrap_or_default();

        if deps.is_empty() {
            // No dependencies for this issue
            continue;
        }

        // Extract just the target issue numbers for the walk function
        let target_numbers: Vec<String> = deps.iter().map(|dep| dep.target_issue.clone()).collect();

        // Initialize provenance map with the provenance for each dependency
        // Use the raw issue number (without #) as the key for consistency
        let mut provenance_map: HashMap<String, String> = deps
            .iter()
            .map(|dep| (dep.target_issue.clone(), dep.provenance.clone()))
            .collect();

        let mut observations = Vec::new();

        let outcome = resolver
            .walk_with_provenance(
                &issue.number,
                &target_numbers,
                &mut vec![issue.number.clone()],
                &mut observations,
                &mut provenance_map,
            )
            .and_then(|has_open| {
                if has_open {
                    Err(DependencyFailure {
                        code: "dependency_open",
                        message: "one or more declared prerequisites remain open".into(),
                    })
                } else {
                    Ok(false)
                }
            });

        // Resolve provenance for nested dependencies where a parent provenance
        // was available but the child is discovered from body references.
        for obs in &mut observations {
            if obs.provenance.is_none() {
                let raw_identity = obs.identity.trim_start_matches('#').to_string();
                if let Some(provenance) = provenance_map.get(&obs.identity) {
                    obs.provenance = Some(provenance.clone());
                } else if let Some(provenance) = provenance_map.get(&raw_identity) {
                    obs.provenance = Some(provenance.clone());
                }
            }
        }

        if let Err(error) = outcome {
            blockers.push(DependencyBlocker {
                ticket_path: issue.number.clone(),
                work_id: format!("#{}", issue.number),
                title: issue.title.clone(),
                reason_code: error.code.into(),
                reason: error.message,
                dependencies: observations,
            });
        }
    }
    blockers
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::cell::RefCell;
    use std::collections::HashMap;
    use std::fs;
    #[cfg(unix)]
    use std::os::unix::fs::PermissionsExt;
    use tempfile::TempDir;

    use crate::test_support::PathGuard;

    fn issue(number: &str, state: Option<&str>, body: &str) -> IssueDetails {
        IssueDetails {
            number: number.into(),
            title: format!("Issue {number}"),
            body: body.into(),
            labels: vec![],
            state: state.map(str::to_string),
        }
    }

    fn write_fake_bin(path: &std::path::Path, name: &str, body: &str) {
        let path = path.join(name);
        fs::write(&path, body).unwrap();
        let mut perms = fs::metadata(&path).unwrap().permissions();
        perms.set_mode(0o755);
        fs::set_permissions(&path, perms).unwrap();
    }

    fn github_test_profile() -> Profile {
        Profile {
            manager_wake_autonomy: crate::config::WakeAutonomy::default(),
            delivery_mode: crate::config::DeliveryMode::default(),
            prune_older_than_days: None,
            chat_session_idle_days: None,
            display_name: "Repo".into(),
            repo_id: "repo".into(),
            provider: "github".into(),
            repo: "owner/repo".into(),
            local_path: "/tmp/repo".into(),
            artifact_root: "/tmp/artifacts".into(),
            default_target_branch: "main".into(),
            provider_api_base: None,
            provider_project_id: None,
            oh_profile: None,
            openhands_args: vec![],
            codex_args: vec![],
            codex_path: None,
            claude_args: vec![],
            claude_path: None,
            agy_path: None,
            vibe_args: vec![],
            vibe_path: None,
            opencode_args: vec![],
            opencode_path: None,
            hermes_args: vec![],
            hermes_path: None,
            agy_second_home: None,
            agy_print_timeout_seconds: HashMap::new(),
            agy_idle_timeout_seconds: None,
            opencode_idle_timeout_seconds: None,
            opencode_idle_timeout_seconds_by_model: HashMap::new(),
            max_concurrent_per_model: HashMap::new(),
            openhands_idle_timeout_seconds: None,
            vibe_idle_timeout_seconds: None,
            codex_idle_timeout_seconds: None,
            claude_idle_timeout_seconds: None,
            hermes_idle_timeout_seconds: None,
            max_parallel_workers: None,
            max_open_managed_mrs: None,
            notify_command: None,
            policy_path: None,
            env_file: None,
            env_file_prod: None,
            validation_commands: vec![],
            auto_fix_commands: vec![],
            test_file_patterns: vec![],
            known_baseline_failure_markers: vec![],
            model_improve: None,
            model_pm: None,
            model_review: None,
            review_timeout_seconds: None,
            review_hard_timeout_seconds: None,
            validation_timeout_seconds: None,
            routing: crate::config::RoutingPolicy::default(),
            publishing: Default::default(),
            external_credential_scopes: HashMap::new(),
            pacing: Default::default(),
        }
    }

    fn gitlab_test_profile() -> Profile {
        let mut profile = github_test_profile();
        profile.provider = "gitlab".into();
        profile.repo = "group/repo".into();
        profile.provider_api_base = Some("https://gitlab.example.com/api/v4".into());
        profile.provider_project_id = Some("42".into());
        profile
    }

    #[test]
    fn strict_parser_rejects_malformed_duplicate_self_and_ambiguous_lines() {
        assert_eq!(parse_dependency_line("no dependencies").unwrap(), None);
        for body in [
            "Blocked by #2",
            "blocked by: #2",
            "Blocked by: #2, 3",
            "Blocked by: #2, #2",
            "Blocked by: #2\nBlocked by: #3",
        ] {
            assert!(parse_dependency_line(body).is_err(), "{body}");
        }

        let roots = vec![issue("2", Some("OPEN"), "Blocked by: #2")];
        let blockers = evaluate_with("github", &roots, |_| unreachable!());
        assert_eq!(blockers[0].reason_code, "dependency_cycle");
    }

    #[test]
    fn github_states_block_open_release_closed_and_cache_shared_references() {
        let roots = vec![
            issue("1", Some("OPEN"), "Blocked by: #9"),
            issue("2", Some("OPEN"), "Blocked by: #9"),
        ];
        let calls = RefCell::new(0);
        let blockers = evaluate_with("github", &roots, |_| {
            *calls.borrow_mut() += 1;
            Ok(DependencyIssue {
                number: "9".into(),
                body: String::new(),
                state: Some("OPEN".into()),
            })
        });
        assert_eq!(blockers.len(), 2);
        assert_eq!(*calls.borrow(), 1, "one controller tick must share lookups");

        let released = evaluate_with("github", &roots, |_| {
            Ok(DependencyIssue {
                number: "9".into(),
                body: String::new(),
                state: Some("CLOSED".into()),
            })
        });
        assert!(released.is_empty());
    }

    #[test]
    fn gitlab_cycle_missing_unknown_and_provider_error_fail_closed() {
        let roots = vec![
            issue("1", Some("opened"), "Blocked by: #2"),
            issue("2", Some("opened"), "Blocked by: #1"),
        ];
        let cycle = evaluate_with("gitlab", &roots, |_| unreachable!());
        assert!(cycle
            .iter()
            .all(|block| block.reason_code == "dependency_cycle"));

        for (error, expected) in [
            ("404 not found", "dependency_missing"),
            ("permission denied", "dependency_query_failed"),
        ] {
            let blocked = evaluate_with(
                "gitlab",
                &[issue("3", Some("opened"), "Blocked by: #99")],
                |_| Err(error.into()),
            );
            assert_eq!(blocked[0].reason_code, expected);
        }

        let unknown = evaluate_with(
            "gitlab",
            &[issue("4", Some("opened"), "Blocked by: #8")],
            |_| {
                Ok(DependencyIssue {
                    number: "8".into(),
                    body: String::new(),
                    state: None,
                })
            },
        );
        assert_eq!(unknown[0].reason_code, "dependency_unknown_state");
    }

    #[test]
    fn cross_project_dependency_parsing_handles_provider_prefix() {
        // Test parsing of cross-project dependency references
        // Format: provider:project_id#number
        assert_eq!(
            parse_dependency_line("Blocked by: github:owner/repo#123").unwrap(),
            Some(vec!["github:owner/repo#123".to_string()])
        );
        assert_eq!(
            parse_dependency_line("Blocked by: gitlab:12345#678").unwrap(),
            Some(vec!["gitlab:12345#678".to_string()])
        );

        // Test mixed same-project and cross-project
        assert_eq!(
            parse_dependency_line("Blocked by: #123, github:owner/repo#456").unwrap(),
            Some(vec!["123".to_string(), "github:owner/repo#456".to_string()])
        );

        // Test malformed cross-project references are rejected
        assert!(parse_dependency_line("Blocked by: github:owner/repo").is_err());
        assert!(parse_dependency_line("Blocked by: github:#123").is_err());
        assert!(parse_dependency_line("Blocked by: :#123").is_err());
    }

    #[test]
    fn gitlab_native_and_body_dependencies_are_deduplicated_with_native_precedence() {
        let profile = gitlab_test_profile();
        let bin_dir = TempDir::new().unwrap();
        let _path = PathGuard::set(bin_dir.path());
        crate::provider::set_test_provider_path(bin_dir.path().to_str().unwrap());

        write_fake_bin(
            bin_dir.path(),
            "glab",
            "#!/bin/sh\nif [ \"$1\" = \"api\" ] && [ \"$2\" = \"projects/42/issues/1/links\" ]; then\n  printf '%s\n' '[{\"link_type\":\"is_blocked_by\",\"source_issue\":{\"iid\":1},\"target_issue\":{\"iid\":2}}]'\n  exit 0\nelif [ \"$1\" = \"api\" ] && [ \"$2\" = \"projects/42/issues/2\" ]; then\n  printf '%s\n' '{\"iid\":2,\"description\":\"\",\"state\":\"open\"}'\n  exit 0\nelif [ \"$1\" = \"api\" ] && [ \"$2\" = \"projects/42/issues/2/links\" ]; then\n  printf '%s\n' '[]'\n  exit 0\nelse\n  echo \"unexpected glab invocation: $*\" >&2\n  exit 1\nfi\n",
        );

        let issues = vec![
            issue("1", Some("OPEN"), "Blocked by: #2"),
            issue("2", Some("OPEN"), ""),
        ];
        let blockers = evaluate_issue_dependencies(&profile, &issues);
        assert_eq!(blockers.len(), 1);
        assert_eq!(blockers[0].dependencies.len(), 1);
        assert_eq!(blockers[0].dependencies[0].identity, "#2");
        assert_eq!(
            blockers[0].dependencies[0].provenance.as_deref(),
            Some("gitlab_blocks_link")
        );
    }

    /// Companion to the dedup test above: that test alone can't distinguish
    /// "body was parsed and correctly deduplicated against native" from "body
    /// was silently never parsed" -- both produce the exact same single
    /// native-provenance dependency. Here body declares a dependency (#5)
    /// that native does *not* also report, so a regression that stops body
    /// parsing would silently drop #5 and only #2 would survive.
    #[test]
    fn gitlab_body_only_dependency_survives_alongside_a_native_one() {
        let profile = gitlab_test_profile();
        let bin_dir = TempDir::new().unwrap();
        let _path = PathGuard::set(bin_dir.path());
        crate::provider::set_test_provider_path(bin_dir.path().to_str().unwrap());

        write_fake_bin(
            bin_dir.path(),
            "glab",
            "#!/bin/sh\nif [ \"$1\" = \"api\" ] && [ \"$2\" = \"projects/42/issues/1/links\" ]; then\n  printf '%s\n' '[{\"link_type\":\"is_blocked_by\",\"source_issue\":{\"iid\":1},\"target_issue\":{\"iid\":2}}]'\n  exit 0\nelif [ \"$1\" = \"api\" ] && [ \"$2\" = \"projects/42/issues/2/links\" ]; then\n  printf '%s\n' '[]'\n  exit 0\nelif [ \"$1\" = \"api\" ] && [ \"$2\" = \"projects/42/issues/2\" ]; then\n  printf '%s\n' '{\"iid\":2,\"description\":\"\",\"state\":\"open\"}'\n  exit 0\nelif [ \"$1\" = \"api\" ] && [ \"$2\" = \"projects/42/issues/5/links\" ]; then\n  printf '%s\n' '[]'\n  exit 0\nelif [ \"$1\" = \"api\" ] && [ \"$2\" = \"projects/42/issues/5\" ]; then\n  printf '%s\n' '{\"iid\":5,\"description\":\"\",\"state\":\"open\"}'\n  exit 0\nelse\n  echo \"unexpected glab invocation: $*\" >&2\n  exit 1\nfi\n",
        );

        let issues = vec![
            issue("1", Some("OPEN"), "Blocked by: #2, #5"),
            issue("2", Some("OPEN"), ""),
            issue("5", Some("OPEN"), ""),
        ];
        let blockers = evaluate_issue_dependencies(&profile, &issues);
        assert_eq!(blockers.len(), 1);
        let identities: HashSet<_> = blockers[0]
            .dependencies
            .iter()
            .map(|obs| obs.identity.as_str())
            .collect();
        assert_eq!(identities, HashSet::from(["#2", "#5"]));
        let provenance_for = |identity: &str| {
            blockers[0]
                .dependencies
                .iter()
                .find(|obs| obs.identity == identity)
                .and_then(|obs| obs.provenance.as_deref())
        };
        assert_eq!(provenance_for("#2"), Some("gitlab_blocks_link"));
        assert_eq!(provenance_for("#5"), Some("body"));
    }

    /// AC1: GitHub native sub-issues must actually be fetched and treated as
    /// blocked-by relationships -- previously `fetch_native_dependencies`
    /// returned `Ok(Vec::new())` unconditionally for github, so this was
    /// never exercised end to end.
    #[test]
    fn github_open_sub_issue_blocks_its_parent() {
        let profile = github_test_profile();
        let bin_dir = TempDir::new().unwrap();
        let _path = PathGuard::set(bin_dir.path());
        crate::provider::set_test_provider_path(bin_dir.path().to_str().unwrap());

        write_fake_bin(
            bin_dir.path(),
            "gh",
            "#!/bin/sh\nif [ \"$1\" = \"api\" ] && [ \"$4\" = \"repos/owner/repo/issues/1/sub_issues\" ]; then\n  printf '%s\n' '[{\"number\":2}]'\n  exit 0\nelif [ \"$1\" = \"api\" ] && [ \"$4\" = \"repos/owner/repo/issues/2/sub_issues\" ]; then\n  printf '%s\n' '[]'\n  exit 0\nelif [ \"$1\" = \"api\" ] && [ \"$4\" = \"repos/owner/repo/issues/2\" ]; then\n  printf '%s\n' '{\"number\":2,\"body\":\"\",\"state\":\"open\"}'\n  exit 0\nelse\n  echo \"unexpected gh invocation: $*\" >&2\n  exit 1\nfi\n",
        );

        let issues = vec![issue("1", Some("OPEN"), ""), issue("2", Some("OPEN"), "")];
        let blockers = evaluate_issue_dependencies(&profile, &issues);
        assert_eq!(blockers.len(), 1);
        assert_eq!(blockers[0].dependencies.len(), 1);
        assert_eq!(blockers[0].dependencies[0].identity, "#2");
        assert_eq!(
            blockers[0].dependencies[0].provenance.as_deref(),
            Some("github_sub_issue")
        );
    }

    /// Companion to the above: once the sub-issue closes, the parent must
    /// unblock. This is the direction check flagged in review -- a parent
    /// should not stay permanently blocked by children that have closed.
    #[test]
    fn github_parent_unblocks_once_its_sub_issue_closes() {
        let profile = github_test_profile();
        let bin_dir = TempDir::new().unwrap();
        let _path = PathGuard::set(bin_dir.path());
        crate::provider::set_test_provider_path(bin_dir.path().to_str().unwrap());

        write_fake_bin(
            bin_dir.path(),
            "gh",
            "#!/bin/sh\nif [ \"$1\" = \"api\" ] && [ \"$4\" = \"repos/owner/repo/issues/1/sub_issues\" ]; then\n  printf '%s\n' '[{\"number\":2}]'\n  exit 0\nelif [ \"$1\" = \"api\" ] && [ \"$4\" = \"repos/owner/repo/issues/2/sub_issues\" ]; then\n  printf '%s\n' '[]'\n  exit 0\nelif [ \"$1\" = \"api\" ] && [ \"$4\" = \"repos/owner/repo/issues/2\" ]; then\n  printf '%s\n' '{\"number\":2,\"body\":\"\",\"state\":\"closed\"}'\n  exit 0\nelse\n  echo \"unexpected gh invocation: $*\" >&2\n  exit 1\nfi\n",
        );

        let issues = vec![issue("1", Some("OPEN"), ""), issue("2", Some("CLOSED"), "")];
        let blockers = evaluate_issue_dependencies(&profile, &issues);
        assert!(blockers.is_empty());
    }

    #[test]
    fn evaluate_issue_dependencies_fails_closed_when_native_lookup_fails() {
        let profile = gitlab_test_profile();
        let bin_dir = TempDir::new().unwrap();
        let _path = PathGuard::set(bin_dir.path());
        crate::provider::set_test_provider_path(bin_dir.path().to_str().unwrap());

        write_fake_bin(
            bin_dir.path(),
            "glab",
            "#!/bin/sh\nif [ \"$1\" = \"api\" ] && [ \"$2\" = \"projects/42/issues/1/links\" ]; then\n  echo '403 permission denied' >&2\n  exit 1\nelse\n  echo \"unexpected glab invocation: $*\" >&2\n  exit 1\nfi\n",
        );

        let blockers = evaluate_issue_dependencies(&profile, &[issue("1", Some("OPEN"), "")]);
        assert_eq!(blockers.len(), 1);
        assert_eq!(blockers[0].reason_code, "dependency_query_failed");
    }

    #[test]
    fn evaluate_issue_dependencies_falls_back_to_body_only_when_native_gitlab_api_unsupported() {
        let profile = gitlab_test_profile();
        let bin_dir = TempDir::new().unwrap();
        let _path = PathGuard::set(bin_dir.path());
        crate::provider::set_test_provider_path(bin_dir.path().to_str().unwrap());

        write_fake_bin(
            bin_dir.path(),
            "glab",
            "#!/bin/sh\nif [ \"$1\" = \"api\" ] && [ \"$2\" = \"projects/42/issues/1/links\" ]; then\n  echo 'old API version unsupported' >&2\n  exit 1\nelif [ \"$1\" = \"api\" ] && [ \"$2\" = \"projects/42/issues/2/links\" ]; then\n  printf '%s\n' '[]'\n  exit 0\nelif [ \"$1\" = \"api\" ] && [ \"$2\" = \"projects/42/issues/2\" ]; then\n  printf '%s\n' '{\"iid\":2,\"description\":\"\",\"state\":\"closed\"}'\n  exit 0\nelse\n  echo \"unexpected glab invocation: $*\" >&2\n  exit 1\nfi\n",
        );

        let issues = vec![
            issue("1", Some("OPEN"), "Blocked by: #2"),
            issue("2", Some("CLOSED"), ""),
        ];
        let blockers = evaluate_issue_dependencies(&profile, &issues);
        assert!(blockers.is_empty());
    }

    #[test]
    fn walk_collects_all_references_when_cross_project_dependency_is_present() {
        let mut calls = Vec::new();
        let blockers = evaluate_with(
            "github",
            &[issue(
                "1",
                Some("OPEN"),
                "Blocked by: #2, github:owner/repo#99, #3",
            )],
            |number| {
                calls.push(number.to_string());
                Ok(DependencyIssue {
                    number: number.to_string(),
                    body: String::new(),
                    state: Some("CLOSED".into()),
                })
            },
        );

        assert_eq!(blockers.len(), 1);
        assert_eq!(blockers[0].reason_code, "dependency_query_failed");
        let identities: Vec<_> = blockers[0]
            .dependencies
            .iter()
            .map(|obs| obs.identity.as_str())
            .collect();
        assert!(identities.contains(&"#2"));
        assert!(identities.contains(&"github:owner/repo#99"));
        assert!(identities.contains(&"#3"));
        assert_eq!(calls, vec!["2".to_string(), "3".to_string()]);
    }

    #[test]
    fn fetch_gitlab_blocks_links_uses_nested_source_issue_and_rejects_mixed_types() {
        let profile = gitlab_test_profile();
        let bin_dir = TempDir::new().unwrap();
        let _path = PathGuard::set(bin_dir.path());
        crate::provider::set_test_provider_path(bin_dir.path().to_str().unwrap());

        write_fake_bin(
            bin_dir.path(),
            "glab",
            "#!/bin/sh\nif [ \"$1\" = \"api\" ] && [ \"$2\" = \"projects/42/issues/1/links\" ]; then\n  printf '%s\n' '[{\"link_type\":\"is_blocked_by\",\"source_issue\":{\"iid\":1},\"target_issue\":{\"iid\":10},\"target_project_id\":42},{\"link_type\":\"blocks\",\"source_issue\":{\"iid\":1},\"target_issue\":{\"iid\":99},\"target_project_id\":42}]'\n  exit 0\nelif [ \"$1\" = \"api\" ] && [ \"$2\" = \"projects/42/issues/10/links\" ]; then\n  printf '%s\n' '[]'\n  exit 0\nelse\n  echo \"unexpected glab invocation: $*\" >&2\n  exit 1\nfi\n",
        );

        let dependencies = fetch_gitlab_blocks_links(&profile, "1").unwrap();
        assert_eq!(dependencies, vec!["10".to_string(),]);
    }

    /// Self-hosted GitLab fixture (AC5): older/self-managed GitLab instances
    /// are known to return issue links with flat `source_issue_iid`/
    /// `target_issue_iid` fields instead of the nested `source_issue.iid`/
    /// `target_issue.iid` objects GitLab.com's current API returns -- which
    /// is exactly why `fetch_gitlab_blocks_links` falls back to those flat
    /// fields via `.or_else(...)`. Every other test in this file uses the
    /// nested shape, leaving that fallback path completely unexercised.
    #[test]
    fn fetch_gitlab_blocks_links_supports_self_hosted_flat_iid_response_shape() {
        let mut profile = gitlab_test_profile();
        profile.provider_api_base = Some("https://gitlab.internal.example.com/api/v4".into());
        let bin_dir = TempDir::new().unwrap();
        let _path = PathGuard::set(bin_dir.path());
        crate::provider::set_test_provider_path(bin_dir.path().to_str().unwrap());

        write_fake_bin(
            bin_dir.path(),
            "glab",
            "#!/bin/sh\nif [ \"$1\" = \"api\" ] && [ \"$2\" = \"projects/42/issues/1/links\" ]; then\n  printf '%s\n' '[{\"link_type\":\"is_blocked_by\",\"source_issue_iid\":1,\"target_issue_iid\":7}]'\n  exit 0\nelse\n  echo \"unexpected glab invocation: $*\" >&2\n  exit 1\nfi\n",
        );

        let dependencies = fetch_gitlab_blocks_links(&profile, "1").unwrap();
        assert_eq!(dependencies, vec!["7".to_string()]);
    }

    /// The list endpoint returns the other issue at the top level, with
    /// `link_type` relative to the asked issue.
    #[test]
    fn fetch_gitlab_blocks_links_reads_the_list_endpoint_shape() {
        let profile = gitlab_test_profile();
        let bin_dir = TempDir::new().unwrap();
        let _path = PathGuard::set(bin_dir.path());
        crate::provider::set_test_provider_path(bin_dir.path().to_str().unwrap());

        write_fake_bin(
            bin_dir.path(),
            "glab",
            "#!/bin/sh\nprintf '%s\\n' '[{\"iid\":10,\"project_id\":42,\"link_type\":\"is_blocked_by\"},{\"iid\":11,\"project_id\":42,\"link_type\":\"blocks\"},{\"iid\":12,\"project_id\":7,\"link_type\":\"is_blocked_by\"},{\"iid\":13,\"project_id\":42,\"link_type\":\"relates_to\"}]'\n",
        );

        assert_eq!(
            fetch_gitlab_blocks_links(&profile, "1").unwrap(),
            vec!["10".to_string()]
        );
    }

    #[test]
    fn github_relations_read_every_page_and_fail_closed_on_malformed_output() {
        let profile = github_test_profile();
        let bin_dir = TempDir::new().unwrap();
        let _path = PathGuard::set(bin_dir.path());
        crate::provider::set_test_provider_path(bin_dir.path().to_str().unwrap());
        let page = |range: std::ops::Range<u32>| {
            let items: Vec<_> = range.map(|n| format!("{{\"number\":{n}}}")).collect();
            format!("[{}]", items.join(","))
        };
        let slurped = format!("[{},{}]", page(2..102), page(102..112));
        let fake_gh = |output: &str| {
            write_fake_bin(
                bin_dir.path(),
                "gh",
                &format!(
                    "#!/bin/sh\ncase \"$*\" in *--paginate*--slurp*) printf '%s' '{output}' ;; *) echo unpaginated >&2; exit 1 ;; esac\n"
                ),
            );
        };
        fake_gh(&slurped);
        let found = fetch_github_sub_issues(&profile, "1").unwrap();
        assert_eq!(found.len(), 110);
        assert_eq!(found.last().map(String::as_str), Some("111"));

        fake_gh("{\"message\":\"nope\"}");
        assert!(matches!(
            fetch_github_sub_issues(&profile, "1"),
            Err(DependencyRelationshipError::MalformedResponse { .. })
        ));
    }

    #[test]
    fn dependency_observation_includes_provenance() {
        // Test that DependencyObservation includes provenance metadata
        let observation = DependencyObservation {
            identity: "#123".to_string(),
            provider: "github".to_string(),
            provider_state: Some("open".to_string()),
            normalized_state: "open".to_string(),
            provenance: Some("body".to_string()),
        };

        assert_eq!(observation.provenance, Some("body".to_string()));
    }

    #[test]
    fn dependency_relationship_error_types_are_send_sync() {
        // Ensure error types can be used across threads (Send + Sync)
        fn assert_send_sync<T: Send + Sync>() {}

        assert_send_sync::<DependencyRelationshipError>();
    }

    #[test]
    fn dependency_relationship_error_display_formats_correctly() {
        use std::fmt::Write;

        let mut output = String::new();

        let error = DependencyRelationshipError::PermissionDenied {
            message: "access denied".to_string(),
        };
        write!(&mut output, "{}", error).unwrap();
        assert!(output.contains("permission denied"));
        assert!(output.contains("access denied"));

        output.clear();
        let error = DependencyRelationshipError::PaginationError {
            message: "rate limited".to_string(),
        };
        write!(&mut output, "{}", error).unwrap();
        assert!(output.contains("pagination error"));
        assert!(output.contains("rate limited"));

        output.clear();
        let error = DependencyRelationshipError::UnsupportedServerVersion {
            message: "old API".to_string(),
        };
        write!(&mut output, "{}", error).unwrap();
        assert!(output.contains("unsupported server version"));
        assert!(output.contains("old API"));

        output.clear();
        let error = DependencyRelationshipError::MalformedResponse {
            message: "invalid JSON".to_string(),
        };
        write!(&mut output, "{}", error).unwrap();
        assert!(output.contains("malformed response"));
        assert!(output.contains("invalid JSON"));
    }
}
