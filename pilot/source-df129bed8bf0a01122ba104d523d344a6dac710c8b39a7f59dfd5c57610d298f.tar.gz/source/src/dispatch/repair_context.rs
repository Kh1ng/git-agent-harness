use super::prompts::indent_untrusted_text;
use super::text::utf8_safe_prefix;
use crate::config::GahConfig;
use crate::job_kind::JobKind;
use crate::ledger::{self, LedgerEntry};
use anyhow::{Context, Result};
use std::fmt;
use std::path::Path;
use std::process::Command;

const MAX_ITEMS_PER_SECTION: usize = 16;
const MAX_ITEM_BYTES: usize = 2_048;

#[derive(Debug, Clone, PartialEq, Eq)]
pub(super) struct RepairContext {
    pub work_id: String,
    pub verdict: String,
    pub reviewer_backend: String,
    pub reviewer_model: Option<String>,
    pub reviewer_tier: Option<String>,
    pub source_sha: String,
    pub metadata_fingerprint: String,
    pub review_contract_version: u32,
    pub review_generation: String,
    pub blocking_findings: Vec<String>,
    pub non_blocking_findings: Vec<String>,
    pub risk_notes: Vec<String>,
    pub evidence: Vec<String>,
    pub compatibility_evidence: Vec<String>,
}

#[derive(Debug, Clone, Copy)]
pub(super) struct RepairIdentity<'a> {
    pub profile_name: &'a str,
    pub repo_id: &'a str,
    pub branch: &'a str,
    pub work_id: Option<&'a str>,
    pub expected_review_generation: Option<&'a str>,
}

/// Load the latest applicable structured review for this exact repair
/// identity. Provider comments are deliberately not consulted: the ledger is
/// the durable, provider-neutral source for both GitHub and GitLab repairs.
/// Structured review verdicts may live on either a dedicated review entry or a
/// backfilled implementation entry, so both are considered.
/// Issue #551: the remote MR/PR this repair is based on is no longer a valid
/// base -- either it advanced past the SHA this attempt observed (a
/// concurrent push) or it's no longer open (merged or closed). Kept distinct
/// from a generic provider-fetch error so callers can terminate cleanly
/// (no worker launch, no force-push) instead of recording an opaque harness
/// failure. Carries expected/observed source SHAs so ledger diagnostics and
/// events show exactly what moved.
#[derive(Debug)]
pub(in crate::dispatch) struct StaleSourceError {
    pub(in crate::dispatch) branch: String,
    pub(in crate::dispatch) reason: String,
    pub(in crate::dispatch) expected_source_sha: Option<String>,
    pub(in crate::dispatch) observed_source_sha: Option<String>,
}

impl fmt::Display for StaleSourceError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "repair branch '{}' has a stale source: {} (expected source sha {}, observed source sha {}); re-run review before repair",
            self.branch,
            self.reason,
            self.expected_source_sha.as_deref().unwrap_or("unknown"),
            self.observed_source_sha.as_deref().unwrap_or("unknown"),
        )
    }
}

impl std::error::Error for StaleSourceError {}

pub(in crate::dispatch) fn stale_source_error(err: &anyhow::Error) -> Option<&StaleSourceError> {
    err.downcast_ref::<StaleSourceError>()
}

/// Kept distinct from a generic harness error so direct/manual repairs can
/// proceed without structured findings. Controller repairs carry an expected
/// generation and must treat its disappearance as a failed preflight.
#[derive(Debug)]
pub(in crate::dispatch) struct NoReviewFoundError {
    pub(in crate::dispatch) branch: String,
    pub(in crate::dispatch) work_id: Option<String>,
    pub(in crate::dispatch) expected_review_generation: Option<String>,
}

impl fmt::Display for NoReviewFoundError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "no structured completed review exists for repair branch '{}'{}{}",
            self.branch,
            self.work_id
                .as_deref()
                .map(|id| format!(" and work item '{id}'"))
                .unwrap_or_default(),
            self.expected_review_generation
                .as_deref()
                .map(|generation| format!(" at expected generation '{generation}'"))
                .unwrap_or_default(),
        )
    }
}

impl std::error::Error for NoReviewFoundError {}

pub(in crate::dispatch) fn no_review_found_error(
    err: &anyhow::Error,
) -> Option<&NoReviewFoundError> {
    err.downcast_ref::<NoReviewFoundError>()
}

pub(super) fn load(
    cfg: &GahConfig,
    profile: &crate::config::Profile,
    identity: RepairIdentity<'_>,
    worktree: &Path,
) -> Result<RepairContext> {
    let entries = ledger::read_entries(cfg).context("reading repair review context from ledger")?;
    let context = latest_from_entries_for_generation(&entries, identity)?;
    ensure_source_is_ancestor(worktree, &context.source_sha)?;

    // Re-read live provider state immediately before dispatch -- the ledger
    // above only proves gah's own last observation was consistent, not that
    // nothing has changed since (a human push, a merge, a close).
    if matches!(profile.provider.as_str(), "github" | "gitlab") {
        let target = crate::provider::find_review_target_by_branch(profile, identity.branch)
            .with_context(|| {
                format!(
                    "refreshing live review identity for repair branch '{}'",
                    identity.branch
                )
            })?;
        ensure_review_target_still_actionable(&identity, &target, &context)?;
    }

    Ok(context)
}

fn ensure_review_target_still_actionable(
    identity: &RepairIdentity<'_>,
    target: &crate::provider::ReviewTarget,
    context: &RepairContext,
) -> std::result::Result<(), StaleSourceError> {
    if is_terminal_state(target) {
        return Err(StaleSourceError {
            branch: identity.branch.to_string(),
            reason: format!(
                "MR/PR is no longer open (state={}, merged_at={})",
                target.state.as_deref().unwrap_or("unknown"),
                target.merged_at.as_deref().unwrap_or("none"),
            ),
            expected_source_sha: Some(context.source_sha.clone()),
            observed_source_sha: target.source_sha.clone(),
        });
    }
    let expected = identity
        .expected_review_generation
        .unwrap_or(&context.review_generation);
    if !crate::sync::review_generation_matches(
        expected,
        target.source_sha.as_deref(),
        target.title.as_deref(),
        target.body.as_deref(),
        target.draft,
    ) {
        let live_fingerprint = crate::sync::review_metadata_fingerprint(
            target.source_sha.as_deref(),
            target.title.as_deref(),
            target.body.as_deref(),
            target.draft,
        );
        let live =
            crate::ledger::review_generation(target.source_sha.as_deref(), Some(&live_fingerprint));
        return Err(StaleSourceError {
            branch: identity.branch.to_string(),
            reason: format!(
                "changed after review: expected review generation '{expected}', live provider generation is '{}'",
                live.as_deref().unwrap_or("unknown")
            ),
            expected_source_sha: Some(context.source_sha.clone()),
            observed_source_sha: target.source_sha.clone(),
        });
    }
    Ok(())
}

/// Issue #551 AC4: re-check immediately before push that a repair's remote
/// target wasn't merged or closed while the worker ran. Scoped to repairs
/// (`existing_branch`) and supported providers only -- a fresh dispatch has
/// no pre-existing MR/PR to go stale.
pub(super) fn ensure_still_open_before_publish(
    profile: &crate::config::Profile,
    branch: &str,
) -> Result<()> {
    if !matches!(profile.provider.as_str(), "github" | "gitlab") {
        return Ok(());
    }
    let target =
        crate::provider::find_review_target_by_branch(profile, branch).with_context(|| {
            format!("refreshing live review identity for repair branch '{branch}' before publish")
        })?;
    if is_terminal_state(&target) {
        return Err(StaleSourceError {
            branch: branch.to_string(),
            reason: format!(
                "MR/PR is no longer open (state={}, merged_at={})",
                target.state.as_deref().unwrap_or("unknown"),
                target.merged_at.as_deref().unwrap_or("none"),
            ),
            expected_source_sha: None,
            observed_source_sha: target.source_sha.clone(),
        }
        .into());
    }
    Ok(())
}

fn is_terminal_state(target: &crate::provider::ReviewTarget) -> bool {
    if target.merged_at.is_some() {
        return true;
    }
    matches!(
        target.state.as_deref(),
        Some("MERGED" | "CLOSED" | "merged" | "closed" | "locked")
    )
}

#[cfg(test)]
fn latest_from_entries(
    entries: &[LedgerEntry],
    profile_name: &str,
    repo_id: &str,
    branch: &str,
    work_id: Option<&str>,
) -> Result<RepairContext> {
    latest_from_entries_for_generation(
        entries,
        RepairIdentity {
            profile_name,
            repo_id,
            branch,
            work_id,
            expected_review_generation: None,
        },
    )
}

fn latest_from_entries_for_generation(
    entries: &[LedgerEntry],
    identity: RepairIdentity<'_>,
) -> Result<RepairContext> {
    let aliases = identity.work_id.map(ledger::work_id_aliases);
    let latest = entries
        .iter()
        .filter(|entry| {
            entry.profile == identity.profile_name
                && entry.repo_id == identity.repo_id
                && matches!(
                    JobKind::parse(&entry.mode),
                    Ok(JobKind::Review) | Ok(JobKind::Fix) | Ok(JobKind::Improve)
                )
                && entry.review_contract_version == Some(ledger::REVIEW_CONTRACT_VERSION)
                && entry.review_generation.is_some()
                && identity
                    .expected_review_generation
                    .is_none_or(|expected| entry.review_generation.as_deref() == Some(expected))
                && entry.branch.as_deref() == Some(identity.branch)
                && aliases.as_ref().is_none_or(|aliases| {
                    entry
                        .work_id
                        .as_deref()
                        .is_some_and(|id| aliases.iter().any(|alias| alias == id))
                })
                && matches!(
                    entry
                        .review_verdict
                        .as_deref()
                        .or(entry.validation_result.as_deref()),
                    Some("APPROVE" | "NEEDS_FIX" | "REJECT" | "HUMAN_REVIEW")
                )
        })
        .max_by_key(|entry| entry.timestamp.as_str())
        .ok_or_else(|| {
            anyhow::Error::new(NoReviewFoundError {
                branch: identity.branch.to_string(),
                work_id: identity.work_id.map(str::to_string),
                expected_review_generation: identity.expected_review_generation.map(str::to_string),
            })
        })?;

    let verdict = latest
        .review_verdict
        .as_deref()
        .or(latest.validation_result.as_deref())
        .unwrap_or_default();
    if !matches!(verdict, "NEEDS_FIX" | "REJECT") {
        anyhow::bail!(
            "latest review for repair branch '{}' has verdict '{verdict}', not NEEDS_FIX/REJECT",
            identity.branch
        );
    }
    if latest.review_blocking_findings.is_empty() {
        anyhow::bail!(
            "latest {verdict} review for repair branch '{}' has no structured blocking findings; re-run review before repair",
            identity.branch
        );
    }
    let source_sha = latest.review_source_sha.clone().with_context(|| {
        format!(
            "latest review for repair branch '{}' has no source SHA",
            identity.branch
        )
    })?;
    let metadata_fingerprint = latest
        .review_metadata_fingerprint
        .clone()
        .with_context(|| {
            format!(
                "latest review for repair branch '{}' has no metadata fingerprint",
                identity.branch
            )
        })?;
    let recorded_work_id = latest.work_id.clone().with_context(|| {
        format!(
            "latest review for repair branch '{}' has no work-item identity",
            identity.branch
        )
    })?;

    Ok(RepairContext {
        work_id: recorded_work_id,
        verdict: verdict.to_string(),
        reviewer_backend: latest
            .reviewer_backend
            .clone()
            .unwrap_or_else(|| latest.effective_backend.clone()),
        reviewer_model: latest
            .reviewer_model
            .clone()
            .or_else(|| latest.effective_model.clone()),
        reviewer_tier: latest.reviewer_tier.clone(),
        source_sha,
        metadata_fingerprint,
        review_contract_version: latest.review_contract_version.unwrap_or_default(),
        review_generation: latest.review_generation.clone().unwrap_or_default(),
        blocking_findings: latest.review_blocking_findings.clone(),
        non_blocking_findings: latest.review_non_blocking_findings.clone(),
        risk_notes: latest.review_risk_notes.clone(),
        evidence: latest.review_evidence.clone(),
        compatibility_evidence: latest.review_compatibility_evidence.clone(),
    })
}

fn ensure_source_is_ancestor(worktree: &Path, source_sha: &str) -> Result<()> {
    let output = Command::new("git")
        .args(["merge-base", "--is-ancestor", source_sha, "HEAD"])
        .current_dir(worktree)
        .output()
        .with_context(|| format!("checking review source lineage for {source_sha}"))?;
    if output.status.success() {
        return Ok(());
    }
    if output.status.code() == Some(1) {
        anyhow::bail!(
            "review source {source_sha} is not an ancestor of repair branch HEAD; re-run review before repair"
        );
    }
    anyhow::bail!(
        "git could not verify review source lineage for {source_sha}: {}",
        String::from_utf8_lossy(&output.stderr).trim()
    )
}

pub(super) fn append_to_prompt(prompt: &mut String, context: &RepairContext) {
    prompt.push_str("\n## Repair Findings\n\n");
    prompt.push_str(
        "These are the authoritative blockers from the latest applicable review. \
         Address every blocking finding; do not infer a different task from branch history.\n\n",
    );
    prompt.push_str(&format!(
        "Work item: {}\nVerdict: {}\nReviewer: {} / {} ({})\nReviewed source SHA: {}\nReview generation: {}\n",
        indent_untrusted_text(&context.work_id),
        indent_untrusted_text(&context.verdict),
        indent_untrusted_text(&context.reviewer_backend),
        indent_untrusted_text(context.reviewer_model.as_deref().unwrap_or("unknown")),
        indent_untrusted_text(context.reviewer_tier.as_deref().unwrap_or("unknown tier")),
        indent_untrusted_text(&context.source_sha),
        indent_untrusted_text(&context.review_generation),
    ));
    append_list(prompt, "Blocking findings", &context.blocking_findings);
    append_list(
        prompt,
        "Non-blocking findings",
        &context.non_blocking_findings,
    );
    append_list(prompt, "Risk notes", &context.risk_notes);
    append_list(prompt, "Evidence", &context.evidence);
    append_list(
        prompt,
        "Compatibility evidence",
        &context.compatibility_evidence,
    );
}

fn append_list(prompt: &mut String, title: &str, items: &[String]) {
    if items.is_empty() {
        return;
    }
    prompt.push_str(&format!("\n{title}:\n"));
    for item in items.iter().take(MAX_ITEMS_PER_SECTION) {
        let bounded = utf8_safe_prefix(item, MAX_ITEM_BYTES);
        prompt.push_str("- ");
        prompt.push_str(&indent_untrusted_text(bounded));
        prompt.push('\n');
    }
    if items.len() > MAX_ITEMS_PER_SECTION {
        prompt.push_str(&format!(
            "-   [truncated: {} additional items]\n",
            items.len() - MAX_ITEMS_PER_SECTION
        ));
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ledger::test_util as ledger_tests;
    use crate::ledger::LedgerEntry;
    use std::fs;

    /// Thread-local `gh`/`glab` PATH override for this module's tests, mirroring
    /// `provider::tests::PathOverride`. Drop-guarded so a panic mid-test still
    /// clears it instead of bleeding into an unrelated test on a reused thread.
    struct FakeProviderPath;

    impl FakeProviderPath {
        fn set(path: &str) -> Self {
            crate::provider::set_test_provider_path(path);
            FakeProviderPath
        }
    }

    impl Drop for FakeProviderPath {
        fn drop(&mut self) {
            crate::provider::clear_test_provider_path();
        }
    }

    fn review_entry(branch: &str, work_id: &str, timestamp: &str) -> LedgerEntry {
        let profile = crate::ledger::test_util::profile();
        let mut entry = LedgerEntry::new("gah", &profile, "agy", "review", branch, None, None);
        entry.timestamp = timestamp.to_string();
        entry.branch = Some(branch.to_string());
        entry.work_id = Some(work_id.to_string());
        entry.review_verdict = Some("NEEDS_FIX".to_string());
        entry.review_source_sha = Some("abc123".to_string());
        entry.review_metadata_fingerprint = Some("sha256:test".to_string());
        entry.review_contract_version = Some(crate::ledger::REVIEW_CONTRACT_VERSION);
        entry.review_generation = crate::ledger::review_generation(
            entry.review_source_sha.as_deref(),
            entry.review_metadata_fingerprint.as_deref(),
        );
        entry.reviewer_backend = Some("agy".to_string());
        entry.reviewer_model = Some("sonnet".to_string());
        entry.review_blocking_findings = vec!["src/lib.rs: fix retry".to_string()];
        entry
    }

    #[test]
    fn selects_latest_review_for_exact_branch_and_work_item() {
        let unrelated = review_entry("gah/other", "#493", "2026-01-03T00:00:00Z");
        let older = review_entry("gah/fix", "#493", "2026-01-01T00:00:00Z");
        let mut latest = review_entry("gah/fix", "TICKET-493", "2026-01-02T00:00:00Z");
        latest.review_blocking_findings = vec!["latest blocker".to_string()];
        let selected = latest_from_entries(
            &[unrelated, older, latest],
            "gah",
            "repo",
            "gah/fix",
            Some("#493"),
        )
        .unwrap();
        assert_eq!(selected.blocking_findings, ["latest blocker"]);
    }

    #[test]
    fn controller_expected_generation_cannot_reuse_newer_or_older_review_findings() {
        let expected = review_entry("gah/fix", "#493", "2026-01-01T00:00:00Z");
        let expected_generation = expected.review_generation.clone().unwrap();
        let mut different = review_entry("gah/fix", "#493", "2026-01-02T00:00:00Z");
        different.review_source_sha = Some("different-sha".into());
        different.review_metadata_fingerprint = Some("sha256:different".into());
        different.review_generation = crate::ledger::review_generation(
            different.review_source_sha.as_deref(),
            different.review_metadata_fingerprint.as_deref(),
        );
        different.review_blocking_findings = vec!["stale blocker".into()];

        let selected = latest_from_entries_for_generation(
            &[expected, different],
            RepairIdentity {
                profile_name: "gah",
                repo_id: "repo",
                branch: "gah/fix",
                work_id: Some("#493"),
                expected_review_generation: Some(&expected_generation),
            },
        )
        .unwrap();

        assert_eq!(selected.review_generation, expected_generation);
        assert_eq!(selected.blocking_findings, ["src/lib.rs: fix retry"]);
    }

    #[test]
    fn missing_controller_generation_fails_closed() {
        let entry = review_entry("gah/fix", "#493", "2026-01-01T00:00:00Z");
        let error = latest_from_entries_for_generation(
            &[entry],
            RepairIdentity {
                profile_name: "gah",
                repo_id: "repo",
                branch: "gah/fix",
                work_id: Some("#493"),
                expected_review_generation: Some("review-v1:missing:sha256:missing"),
            },
        )
        .unwrap_err();

        assert!(error.to_string().contains("at expected generation"));
    }

    #[test]
    fn latest_review_without_structured_findings_fails_closed() {
        let mut entry = review_entry("gah/fix", "#493", "2026-01-01T00:00:00Z");
        entry.review_blocking_findings.clear();
        let err =
            latest_from_entries(&[entry], "gah", "repo", "gah/fix", Some("#493")).unwrap_err();
        assert!(err.to_string().contains("no structured blocking findings"));
    }

    #[test]
    fn later_non_repair_verdict_supersedes_older_findings() {
        let older = review_entry("gah/fix", "#493", "2026-01-01T00:00:00Z");
        let mut approved = review_entry("gah/fix", "#493", "2026-01-02T00:00:00Z");
        approved.review_verdict = Some("APPROVE".to_string());
        approved.review_blocking_findings.clear();
        let err = latest_from_entries(&[older, approved], "gah", "repo", "gah/fix", Some("#493"))
            .unwrap_err();
        assert!(err.to_string().contains("not NEEDS_FIX/REJECT"));
    }

    #[test]
    fn capacity_deferral_does_not_supersede_latest_repair_opinion() {
        let repair = review_entry("gah/fix", "#493", "2026-01-01T00:00:00Z");
        let mut deferred = review_entry("gah/fix", "#493", "2026-01-02T00:00:00Z");
        deferred.review_verdict = None;
        deferred.validation_result = Some("deferred_capacity".to_string());
        deferred.review_source_sha = None;
        deferred.review_blocking_findings.clear();

        let selected =
            latest_from_entries(&[repair, deferred], "gah", "repo", "gah/fix", Some("#493"))
                .unwrap();
        assert_eq!(selected.verdict, "NEEDS_FIX");
        assert_eq!(selected.blocking_findings, ["src/lib.rs: fix retry"]);
    }

    #[test]
    fn existing_branch_preflight_uses_backfilled_implementation_review_context() {
        let (_tmp, cfg) = ledger_tests::test_config();
        let repo = tempfile::tempdir().unwrap();
        let repo_path = repo.path().join("repo");
        crate::dispatch::test_util::init_repo(&repo_path);

        let source_sha = Command::new("git")
            .args(["rev-parse", "HEAD"])
            .current_dir(&repo_path)
            .output()
            .unwrap();
        assert!(source_sha.status.success());
        let source_sha = String::from_utf8(source_sha.stdout).unwrap();
        let source_sha = source_sha.trim().to_string();

        fs::write(repo_path.join("README.md"), "updated\n").unwrap();
        let add = Command::new("git")
            .args(["add", "README.md"])
            .current_dir(&repo_path)
            .output()
            .unwrap();
        assert!(add.status.success());
        let commit = Command::new("git")
            .args(["commit", "-m", "repair branch"])
            .current_dir(&repo_path)
            .output()
            .unwrap();
        assert!(commit.status.success());

        let profile = crate::dispatch::test_util::profile(&repo_path);
        let mut entry =
            LedgerEntry::new("test", &profile, "claude", "improve", "target", None, None);
        entry.branch = Some("gah/fix".to_string());
        entry.work_id = Some("#493".to_string());
        entry.review_verdict = Some("NEEDS_FIX".to_string());
        entry.review_confidence = Some("high".to_string());
        entry.reviewer_backend = Some("claude".to_string());
        entry.reviewer_model = Some("claude-sonnet-4".to_string());
        entry.reviewer_tier = Some("strong".to_string());
        entry.review_source_sha = Some(source_sha.clone());
        entry.review_metadata_fingerprint = Some(crate::sync::review_metadata_fingerprint(
            Some(&source_sha),
            Some("t"),
            Some("b"),
            false,
        ));
        entry.review_contract_version = Some(crate::ledger::REVIEW_CONTRACT_VERSION);
        entry.review_generation = crate::ledger::review_generation(
            entry.review_source_sha.as_deref(),
            entry.review_metadata_fingerprint.as_deref(),
        );
        entry.review_blocking_findings = vec!["src/lib.rs: fix retry".to_string()];
        entry.review_non_blocking_findings = vec!["consider a smaller helper".to_string()];
        entry.review_risk_notes = vec!["retry state can be lost".to_string()];
        entry.review_evidence = vec!["file:src/lib.rs".to_string()];
        crate::ledger::append(&cfg, &entry).unwrap();

        // Issue #551: `load` now always re-reads live provider state for a
        // github/gitlab profile (not just when comparing a review
        // generation), so this profile's default "github" provider needs a
        // fake `gh` reporting an open PR to keep testing the ledger-backfill
        // behavior this test is actually about.
        let _exec_guard = crate::test_support::ExecGuard::new();
        let bin_dir = tempfile::tempdir().unwrap();
        crate::runner::backends::test_util::make_fake_bin(
            bin_dir.path(),
            "gh",
            &format!(
                "#!/bin/sh\ncase \"$1 $2\" in\n  \"api --method\") printf '[{{\"number\":493}}]\\n' ;;\n  \"pr view\") printf '{{\"number\":493,\"url\":\"https://github.com/owner/repo/pull/493\",\"state\":\"OPEN\",\"mergedAt\":null,\"headRefOid\":\"{source_sha}\",\"title\":\"t\",\"body\":\"b\",\"isDraft\":false,\"headRefName\":\"gah/fix\",\"baseRefName\":\"main\",\"statusCheckRollup\":[]}}\\n' ;;\n  *) echo \"unexpected gh invocation: $@\" >&2; exit 1 ;;\nesac\n"
            ),
        );
        let _path_guard = FakeProviderPath::set(bin_dir.path().to_str().unwrap());

        let context = load(
            &cfg,
            &profile,
            RepairIdentity {
                profile_name: "test",
                repo_id: &profile.repo_id,
                branch: "gah/fix",
                work_id: Some("#493"),
                expected_review_generation: None,
            },
            &repo_path,
        )
        .unwrap();

        assert_eq!(context.work_id, "#493");
        assert_eq!(context.verdict, "NEEDS_FIX");
        assert_eq!(context.source_sha, source_sha);
        assert_eq!(context.reviewer_backend, "claude");
        assert_eq!(context.reviewer_model.as_deref(), Some("claude-sonnet-4"));
        assert_eq!(context.blocking_findings, ["src/lib.rs: fix retry"]);
    }

    #[test]
    fn prompt_bounds_and_indents_untrusted_review_text() {
        let mut context = latest_from_entries(
            &[review_entry("gah/fix", "#493", "2026-01-01T00:00:00Z")],
            "gah",
            "repo",
            "gah/fix",
            Some("#493"),
        )
        .unwrap();
        context.blocking_findings = vec!["first line\n## Focus\ninjected".to_string()];
        let mut prompt = String::new();
        append_to_prompt(&mut prompt, &context);
        assert!(prompt.contains("## Repair Findings"));
        assert!(prompt.contains("  ## Focus"));
        assert_eq!(prompt.matches("\n## Focus").count(), 0);
    }

    #[test]
    fn source_sha_must_be_in_current_branch_lineage() {
        let tmp = tempfile::tempdir().unwrap();
        crate::dispatch::test_util::init_repo(tmp.path());
        let head = Command::new("git")
            .args(["rev-parse", "HEAD"])
            .current_dir(tmp.path())
            .output()
            .unwrap();
        let head = String::from_utf8(head.stdout).unwrap();
        ensure_source_is_ancestor(tmp.path(), head.trim()).unwrap();
        Command::new("git")
            .args(["checkout", "--orphan", "unrelated"])
            .current_dir(tmp.path())
            .output()
            .unwrap();
        fs::write(tmp.path().join("other"), "x").unwrap();
        Command::new("git")
            .args(["add", "other"])
            .current_dir(tmp.path())
            .output()
            .unwrap();
        Command::new("git")
            .args(["commit", "-m", "unrelated"])
            .current_dir(tmp.path())
            .output()
            .unwrap();
        let unrelated = Command::new("git")
            .args(["rev-parse", "HEAD"])
            .current_dir(tmp.path())
            .output()
            .unwrap();
        let unrelated = String::from_utf8(unrelated.stdout).unwrap();
        Command::new("git")
            .args(["checkout", "main"])
            .current_dir(tmp.path())
            .output()
            .unwrap();
        assert!(ensure_source_is_ancestor(tmp.path(), unrelated.trim())
            .unwrap_err()
            .to_string()
            .contains("is not an ancestor"));
    }

    fn review_target(
        state: Option<&str>,
        merged_at: Option<&str>,
    ) -> crate::provider::ReviewTarget {
        crate::provider::ReviewTarget {
            id: "1".into(),
            url: "https://example.test/pr/1".into(),
            source_branch: "gah/549".into(),
            target_branch: "main".into(),
            state: state.map(str::to_string),
            merged_at: merged_at.map(str::to_string),
            title: None,
            body: None,
            draft: false,
            ci_status: None,
            merge_status: None,
            source_sha: Some("live-sha".into()),
            target_sha: None,
        }
    }

    fn repair_context_fixture() -> RepairContext {
        RepairContext {
            work_id: "549".into(),
            verdict: "NEEDS_FIX".into(),
            reviewer_backend: "claude".into(),
            reviewer_model: None,
            reviewer_tier: None,
            source_sha: "expected-sha".into(),
            metadata_fingerprint: "fp".into(),
            review_contract_version: 1,
            review_generation: "gen".into(),
            blocking_findings: vec![],
            non_blocking_findings: vec![],
            risk_notes: vec![],
            evidence: vec![],
            compatibility_evidence: vec![],
        }
    }

    // Issue #549: a merged PR/MR must never be picked back up by a repair --
    // this is the classification `find_review_target_by_branch` now feeds.
    #[test]
    fn is_terminal_state_true_for_merged_at_regardless_of_state_string() {
        assert!(is_terminal_state(&review_target(
            Some("OPEN"),
            Some("2026-01-01T00:00:00Z")
        )));
    }

    #[test]
    fn is_terminal_state_true_for_closed_or_merged_state_strings() {
        for state in ["MERGED", "CLOSED", "merged", "closed", "locked"] {
            assert!(
                is_terminal_state(&review_target(Some(state), None)),
                "expected state={state} to be terminal"
            );
        }
    }

    #[test]
    fn is_terminal_state_false_for_open() {
        assert!(!is_terminal_state(&review_target(Some("OPEN"), None)));
        assert!(!is_terminal_state(&review_target(Some("opened"), None)));
    }

    #[test]
    fn ensure_review_target_still_actionable_rejects_merged_pr_before_dispatch() {
        let identity = RepairIdentity {
            profile_name: "p",
            repo_id: "r",
            branch: "gah/549",
            work_id: None,
            expected_review_generation: None,
        };
        let target = review_target(Some("MERGED"), Some("2026-01-01T00:00:00Z"));
        let context = repair_context_fixture();
        let err = ensure_review_target_still_actionable(&identity, &target, &context).unwrap_err();
        assert_eq!(err.expected_source_sha.as_deref(), Some("expected-sha"));
        assert_eq!(err.observed_source_sha.as_deref(), Some("live-sha"));

        // Round-trips through anyhow as a typed error, matching how
        // `repair::load_context` distinguishes this from a generic
        // harness error to pick `FailureClass::StaleSource`.
        let anyhow_err: anyhow::Error = err.into();
        assert!(stale_source_error(&anyhow_err).is_some());
    }

    // Issue #537: a live review-generation drift (remote advanced) must also
    // be reported as a typed stale-source outcome, not a generic error.
    #[test]
    fn ensure_review_target_still_actionable_rejects_generation_drift() {
        let identity = RepairIdentity {
            profile_name: "p",
            repo_id: "r",
            branch: "gah/537",
            work_id: None,
            expected_review_generation: Some("expected-generation"),
        };
        let target = review_target(Some("OPEN"), None);
        let context = repair_context_fixture();
        let err = ensure_review_target_still_actionable(&identity, &target, &context).unwrap_err();
        assert!(err.reason.contains("changed after review"));
    }

    #[test]
    fn manual_repair_rejects_review_generation_drift() {
        let identity = RepairIdentity {
            profile_name: "p",
            repo_id: "r",
            branch: "gah/537",
            work_id: None,
            expected_review_generation: None,
        };
        let target = review_target(Some("OPEN"), None);
        let context = repair_context_fixture();
        let err = ensure_review_target_still_actionable(&identity, &target, &context).unwrap_err();
        assert!(err.reason.contains("changed after review"));
    }

    #[test]
    fn ensure_review_target_still_actionable_allows_open_matching_generation() {
        let identity = RepairIdentity {
            profile_name: "p",
            repo_id: "r",
            branch: "gah/537",
            work_id: None,
            expected_review_generation: None,
        };
        let target = review_target(Some("OPEN"), None);
        let mut context = repair_context_fixture();
        let metadata_fingerprint = crate::sync::review_metadata_fingerprint(
            target.source_sha.as_deref(),
            target.title.as_deref(),
            target.body.as_deref(),
            target.draft,
        );
        context.review_generation = crate::ledger::review_generation(
            target.source_sha.as_deref(),
            Some(&metadata_fingerprint),
        )
        .unwrap();
        assert!(ensure_review_target_still_actionable(&identity, &target, &context).is_ok());
    }
}
