use super::super::attempts::{
    apply_route_to_ledger, attempt_usage, classify_git_operation_result, classify_worktree_result,
    decide_route, failure_text_with_internal_log, preflight_identity,
    record_external_approval_consumption_for_last_attempt, record_route_attempt,
    reserve_backend_attempt, resolve_llm, route_after_backend_unavailable, route_identity,
    route_label, run_backend_with_reserved_route, validation_retry_route, wip_checkpoint_branch,
};
use super::super::claims::ensure_dispatch_capacity;
use super::super::identity::timestamp;
use super::super::issues::{
    parse_ticket_metadata, parse_ticket_metadata_from_issue, resolve_target_to_issue_or_string,
};
use super::super::mutation_policy::enforce_policy;
use super::super::prior_attempts::build_redispatch_task;
use super::super::prompts::enforce_context_budget;
use super::super::repair_context;
use super::super::text::utf8_safe_prefix;
use super::super::validation::{
    classify_validation_failure_progress, run_auto_fix_commands, should_skip_per_dispatch_baseline,
    validation_failure_no_progress_reason,
};
use super::super::DispatchArgs;
use super::already_satisfied_reconcile::AlreadySatisfiedRun;
use crate::config::{self, GahConfig, Profile};
use crate::controller::HumanRequiredReason;
use crate::job_kind::JobKind;
use crate::ledger::{self, LedgerEntry};
use crate::notifications::{notify_event, NotifyEvent};
use crate::routing::RouteRequest;
use crate::usage_attribution::UsageAttribution;
use crate::validation_runner::{validate_with_exit_code, VALIDATION_COMMAND_TIMEOUT_EXIT_CODE};
use crate::{runner, worktree};
use anyhow::{Context, Result};
use std::fs;
use std::path::{Path, PathBuf};
mod attempt_bookkeeping;
mod bounded_validation;
pub(crate) use bounded_validation::bounded_validation_failure;
mod conflict_resolution;
#[path = "improve/finish.rs"]
mod finish;
mod handoff;
mod publish_mr;
use finish::finish_improve_workflow;
mod repair;
mod shutdown;
use shutdown::record_cancelled_attempt;
mod stall;
use stall::record_exact_route_unavailability;
mod work_identity;
use work_identity::{
    apply_manual_fix_context_to_ledger, resolve_manual_fix_context, resolve_target,
};

pub(crate) fn improve(
    cfg: &GahConfig,
    profile: &Profile,
    args: &DispatchArgs,
    session_dir: &Path,
    ledger: &mut LedgerEntry,
) -> Result<()> {
    // Resolve the Claude executable path so the optional live `/usage` PTY
    // probe (issue #153) can drive a real session when explicitly enabled.
    let claude_path = profile
        .claude_path
        .clone()
        .unwrap_or_else(|| "claude".to_string());

    // Enforce policy before any mutations
    let push_action = if args.prod {
        "git-push-prod"
    } else {
        "git-push"
    };
    enforce_policy(profile, "open-draft-pr")?;
    enforce_policy(profile, push_action)?;

    let manual_fix = resolve_manual_fix_context(
        cfg,
        &args.profile,
        profile,
        &args.mode,
        args.existing_branch.clone(),
        args.mr.as_deref(),
    )?;

    let target = resolve_target(args, profile, &manual_fix)?;

    // Resolve target as an issue number, propagating real fetch errors.
    let issue_details =
        resolve_target_to_issue_or_string(profile, &target, args.issue_intake_override)?;
    if issue_details.is_some() && args.issue_intake_override {
        println!("Issue intake override enabled for explicit issue dispatch");
    }

    let ticket_meta = if let Some(ref issue) = issue_details {
        Some(parse_ticket_metadata_from_issue(issue))
    } else {
        parse_ticket_metadata(Path::new(&target)).ok().flatten()
    };
    let usage_summary = ledger::usage_summary_for_backend(
        cfg,
        args.backend.as_str(),
        args.model.as_deref(),
        Some(
            session_dir
                .file_name()
                .and_then(|s| s.to_str())
                .unwrap_or(""),
        ),
    )
    .ok();
    let route_req = RouteRequest {
        mode: &args.mode,
        requested_backend: config::canonical_backend_name(&args.backend),
        requested_model: args.model.as_deref(),
        recommended_backend: ticket_meta
            .as_ref()
            .and_then(|m| m.recommended_backend.as_deref()),
        recommended_model: ticket_meta
            .as_ref()
            .and_then(|m| m.recommended_model.as_deref()),
        session_id: session_dir.file_name().and_then(|s| s.to_str()),
        usage_summary,
        last_failure_class: if args.escalate {
            Some(crate::ledger::FailureClass::AgentNoProgress.as_str())
        } else {
            None
        },
        exact_route_required: false,
    };
    let mut route = decide_route(
        cfg,
        profile,
        route_req.clone(),
        ticket_meta.as_ref(),
        ledger,
    )?;
    apply_route_to_ledger(ledger, &route);
    preflight_identity(profile, &route.identity)?;
    let mut llm = resolve_llm(
        cfg,
        args,
        profile.oh_profile.as_deref(),
        route.effective_model.as_deref(),
    )?;

    let resolved_env = if args.prod {
        profile.env_file_prod.as_deref().unwrap_or("")
    } else {
        profile.env_file.as_deref().unwrap_or("")
    };
    if !resolved_env.is_empty() {
        println!("Env file: {}", resolved_env);
        if args.prod {
            println!("  \u{26a0}\u{fe0f}  PRODUCTION env - agent has live API access");
        }
    }

    let ts = timestamp();
    let branch = if let Some(ref existing_branch) = manual_fix.existing_branch {
        existing_branch.clone()
    } else {
        format!("gah/{}-{}", profile.repo_id, ts)
    };
    apply_manual_fix_context_to_ledger(ledger, ticket_meta.as_ref(), &branch, &manual_fix);
    let worktree_base = PathBuf::from(&cfg.defaults.worktree_base);
    let repo = Path::new(&profile.local_path);
    ensure_dispatch_capacity(profile, &worktree_base)?;

    // Track WIP checkpoints for cleanup/tombstoning after successful completion
    let mut wip_checkpoints = Vec::new();

    // Issue #362: Check for existing resumable checkpoints first
    let sessions_base = Path::new(&profile.artifact_root).join("sessions");
    let checkpoint_result = crate::dispatch::checkpoints::find_latest_resumable_checkpoint(
        &sessions_base,
        &branch,
        ledger.work_id.as_deref(),
    )?;

    let (branch, wt) = if let Some(ref existing_branch) = manual_fix.existing_branch {
        println!(
            "Creating worktree from existing branch '{}'...",
            existing_branch
        );
        let wt = classify_worktree_result(
            ledger,
            worktree::create_existing(repo, existing_branch, &worktree_base),
        )?;
        (existing_branch.clone(), wt)
    } else if let Some((checkpoint_branch, checkpoint_sha, _)) = checkpoint_result {
        // Issue #362: Resume from existing checkpoint
        println!("Resuming from checkpoint {checkpoint_branch} (sha: {checkpoint_sha}) ...");

        if let Some(wt) = crate::dispatch::checkpoints::resume_checkpoint_into_worktree(
            ledger,
            repo,
            &checkpoint_branch,
            &branch,
            &worktree_base,
        )? {
            wip_checkpoints.push(checkpoint_branch.clone()); // for tombstoning after success
            println!("Successfully resumed from checkpoint: {checkpoint_branch} (as {branch})");
            (branch.clone(), wt)
        } else {
            // Checkpoint is no longer valid, fall back to normal creation
            println!(
                "Checkpoint {} is no longer valid, creating fresh worktree from {}...",
                checkpoint_branch, profile.default_target_branch
            );
            let wt = classify_worktree_result(
                ledger,
                worktree::create(
                    repo,
                    &profile.default_target_branch,
                    &branch,
                    &worktree_base,
                ),
            )?;
            (branch, wt)
        }
    } else {
        println!(
            "Creating worktree from {}...",
            profile.default_target_branch
        );
        let wt = classify_worktree_result(
            ledger,
            worktree::create(
                repo,
                &profile.default_target_branch,
                &branch,
                &worktree_base,
            ),
        )?;
        (branch, wt)
    };
    // Issue #537: the repair branch's remote tip at worktree creation, used
    // by the retry-reset loop below to detect whether the remote source
    // advanced concurrently instead of blindly resetting to it (or, worse,
    // to `main`). `wt`'s HEAD is exactly `origin/<branch>` at this point --
    // `worktree::create_existing` just checked it out.
    let repair_base_sha: Option<String> = if manual_fix.existing_branch.is_some() {
        Some(worktree::git(&["rev-parse", "HEAD"], &wt)?)
    } else {
        None
    };
    ledger.branch = Some(branch.clone());
    println!("Worktree: {}", wt.display());
    println!("Branch:   {}", branch);
    let conflict_session = conflict_resolution::ConflictSession::prepare(
        manual_fix.existing_branch.is_some(),
        ledger,
        &wt,
        repo,
        session_dir,
        &profile.default_target_branch,
    )?;
    let already_satisfied = AlreadySatisfiedRun::new(
        profile,
        &wt,
        repo,
        &branch,
        &args.mode,
        issue_details.as_ref().map(|issue| issue.number.as_str()),
    );
    let repair_context = repair::load_context(
        repair::LoadContext::new(
            manual_fix.existing_branch.is_some(),
            args,
            cfg,
            profile,
            &branch,
            &wt,
            repo,
        ),
        ledger,
    )?;
    let cargo_target = crate::build_cache::ScopedCargoTarget::acquire(&profile.artifact_root)?;
    let validation_environment = cargo_target.environment();

    let mut base_task = build_redispatch_task(profile, &wt, args, &target, issue_details.as_ref());
    if let Some(repair_context) = repair_context.as_ref() {
        repair_context::append_to_prompt(&mut base_task, repair_context);
    }
    conflict_session.append_prompt(&mut base_task);
    let timeout = std::time::Duration::from_secs(profile.validation_timeout_seconds());

    let (baseline_failure, baseline_exit_code) = if conflict_session.is_active()
        || should_skip_per_dispatch_baseline(
            profile.validation_commands.is_empty(),
            manual_fix.existing_branch.is_some(),
            args.skip_validation_gate,
        ) {
        (None, None)
    } else {
        println!("Baseline validation on pristine worktree...");
        match validate_with_exit_code(
            &profile.validation_commands,
            &wt,
            &validation_environment,
            timeout,
        ) {
            Ok(()) => {
                println!("Baseline validation passed.");
                (None, None)
            }
            Err((text, code)) => (Some(text), code),
        }
    };
    // TICKET-110/111: classify why the baseline failed, then apply policy.
    // clean/expected_red proceed (existing warning-in-prompt behavior);
    // harness_error/environment_error always stop; unknown_red stops unless
    // explicitly overridden. Never let this improvise -- see baseline.rs.
    let baseline_disposition = crate::baseline::classify_baseline(
        baseline_failure.as_deref().unwrap_or(""),
        baseline_exit_code,
        &profile.known_baseline_failure_markers,
    );
    if let Some(b) = &baseline_failure {
        fs::write(session_dir.join("baseline-validation-failure.txt"), b)?;
        println!(
            "Baseline validation ALREADY FAILING on untouched branch ({}).",
            baseline_disposition.as_str()
        );
        use crate::baseline::BaselineDisposition as BD;
        match baseline_disposition {
            BD::Clean => unreachable!("failure text implies a non-Clean disposition"),
            BD::HarnessError | BD::EnvironmentError => {
                ledger.set_failure(
                    match baseline_disposition {
                        BD::HarnessError => crate::ledger::FailureClass::HarnessError,
                        _ => crate::ledger::FailureClass::EnvironmentError,
                    },
                    crate::ledger::FailureStage::BaselineValidation,
                );
                worktree::cleanup(&wt, repo);
                anyhow::bail!(
                    "baseline validation stopped ({}): {}",
                    baseline_disposition.as_str(),
                    bounded_validation_failure(b, 4_000),
                );
            }
            BD::UnknownRed if !args.allow_unknown_red_baseline => {
                ledger.set_failure(
                    crate::ledger::FailureClass::Unknown,
                    crate::ledger::FailureStage::BaselineValidation,
                );
                worktree::cleanup(&wt, repo);
                anyhow::bail!(
                    "baseline validation stopped (unknown_red): {}\n\nUse --allow-unknown-red-baseline to proceed anyway.",
                    bounded_validation_failure(b, 4_000),
                );
            }
            BD::UnknownRed | BD::ExpectedRed => {
                base_task.push_str(&format!(
                    "\n\n## Warning: validation already fails on the untouched branch\n\n```\n{}\n```\n\nIf this ticket is about fixing that failure, fix it. Otherwise it is pre-existing — your changes must not add new failures.\n",
                    utf8_safe_prefix(b, 4_000),
                ));
            }
        }
    }

    let mut task = base_task.clone();
    let max_attempts = args.retries + 1;
    let mut validation_failed = false;
    let mut prev_failure: Option<String> = None;
    let mut prior_phase_context: Option<String> = None;
    let mut backend_summary = String::new();
    // Retry checkpoints are temporary recovery refs. They are deliberately
    // retained on any terminal failure, then removed only after a successful
    // publish so real partial work is never silently discarded.
    for attempt in 0..max_attempts {
        println!(
            "\nAttempt {}/{}: running {} backend...",
            attempt + 1,
            max_attempts,
            route.effective_backend
        );
        let attempt_session = session_dir.join(format!("attempt-{}", attempt + 1));
        fs::create_dir_all(&attempt_session)?;
        let shutdown_ctx = shutdown::ShutdownContext::new(
            &wt,
            repo,
            &profile.default_target_branch,
            &branch,
            &attempt_session,
            args.run_id.clone(),
            attempt + 1,
            ledger.work_id.clone(),
        );
        let attempt_state_before = classify_git_operation_result(
            ledger,
            crate::ledger::FailureStage::AgentRun,
            worktree::state_snapshot(&wt),
        )?;
        ledger.attempts_started = Some(ledger.attempts_started.unwrap_or(0) + 1);
        let attempt_start = std::time::Instant::now();

        let env_path = if !resolved_env.is_empty() {
            Some(resolved_env)
        } else {
            None
        };
        let fresh_context = if JobKind::parse(&args.mode) == Ok(JobKind::Fix) {
            cfg.context
                .effective(&args.profile, &route.effective_backend)
                .fresh_context_on_fix
        } else {
            true
        };
        if !fresh_context {
            if let Some(previous) = prior_phase_context.as_deref() {
                task = format!("{task}\n\n## Prior Phase Context\n{previous}");
            }
        }
        let context = match enforce_context_budget(
            cfg,
            profile,
            &wt,
            &args.profile,
            &route.effective_backend,
            if JobKind::parse(&args.mode) == Ok(JobKind::Fix) {
                "fix"
            } else {
                "coding"
            },
            fresh_context,
            &task,
            &attempt_session,
            args.run_id.as_deref(),
            ledger,
            None,
        ) {
            Ok(build) => build.prompt,
            Err(err) => {
                worktree::cleanup(&wt, repo);
                return Err(err);
            }
        };
        task = context;
        let admission_guard =
            reserve_backend_attempt(profile, &route.identity, args.route_admission.as_ref())
                .map_err(|error| {
                    super::super::contextualize_capacity_deferral(error, attempt as usize)
                })?;
        record_route_attempt(ledger, &route)?;
        let result = run_backend_with_reserved_route(
            &route.identity,
            profile,
            &wt,
            &task,
            &attempt_session,
            &cargo_target,
            &llm,
            env_path,
            cfg,
            &args.profile,
            ledger.work_id.as_deref(),
            true,
            None,
        );
        drop(admission_guard);
        let result = match result {
            Ok(r) => r,
            Err(e)
                if crate::dispatch::external_approval_pause::latch_external_approval_hold(
                    cfg,
                    &args.profile,
                    profile,
                    ledger,
                    &e,
                ) =>
            {
                worktree::cleanup(&wt, repo);
                return Ok(());
            }
            Err(e) => {
                // The backend process itself couldn't launch (binary missing,
                // exec failure) — this is a setup/harness problem, not the
                // agent or backend failing at its job.
                attempt_bookkeeping::record_backend_launch_failure(
                    ledger,
                    &route,
                    attempt,
                    &llm,
                    attempt_start.elapsed().as_secs_f64(),
                );
                record_external_approval_consumption_for_last_attempt(
                    cfg,
                    &args.profile,
                    profile,
                    ledger,
                );
                worktree::cleanup(&wt, repo);
                return Err(e);
            }
        };
        // The backend process launched and ran to an exit code, regardless
        // of what that code was — "completed" tracks whether the attempt
        // got a fair shot, not whether it succeeded.
        ledger.attempts_completed = Some(ledger.attempts_completed.unwrap_or(0) + 1);
        println!(
            "Backend finished: exit={} duration={:.0}s log={}",
            result.exit_code, result.duration_secs, result.log_path
        );
        ledger.backend_exit_code = Some(result.exit_code);
        conflict_session.snapshot_if_unresolved(attempt + 1)?;
        shutdown::pause_after_backend_result_if_requested()?;

        // SIGINT/SIGTERM is an operator lifecycle event, not a backend
        // failure to retry. The runner already killed and reaped the backend
        // process group; return so the controller can write the matching
        // terminal dispatch event.
        let shutdown_after_result = crate::runner::shutdown_requested();
        if shutdown_after_result && result.exit_code == -2 {
            shutdown_ctx.record_cancelled_backend_result_and_cleanup(
                ledger,
                &route,
                &llm.model,
                &result,
                Some(&claude_path),
                attempt_start.elapsed().as_secs_f64(),
            )?;
        }

        backend_summary = runner::output::publishable_summary(
            result.final_summary.as_deref(),
            ledger.target_summary.as_deref(),
            &wt,
        );

        if result.exit_code != 0 {
            // The backend launched but exited nonzero — the backend itself
            // failed at its job, distinct from it never starting at all.
            let output_log_text = fs::read_to_string(&result.log_path).unwrap_or_default();
            let log_text = failure_text_with_internal_log(
                &output_log_text,
                result.internal_log_delta.as_deref(),
            );
            let failure_log_path = result
                .internal_log_path
                .as_deref()
                .unwrap_or(&result.log_path);
            let exit_failure = stall::classify_backend_exit_failure(&log_text, result.exit_code);
            let stalled = exit_failure.stalled;
            let stalled_before_changes = exit_failure.stalled_before_changes;
            let stalled_during_validation = exit_failure.stalled_during_validation;
            let cleanup_failed = exit_failure.cleanup_failed;
            ledger.set_failure(
                exit_failure.failure_class,
                crate::ledger::FailureStage::AgentRun,
            );
            if cleanup_failed {
                ledger.validation_result = Some("not_run_process_cleanup_failed".into());
                ledger.error_summary = Some("backend descendant cleanup failed".into());
            } else if stalled_before_changes {
                ledger.validation_result = Some("not_run_backend_stalled".into());
            } else if stalled_during_validation {
                ledger.validation_result = Some("not_run_backend_stalled_during_validation".into());
            }
            ledger.attempts.push(crate::ledger::AttemptRecord {
                resources: Some(result.resources.clone()),
                attempt_number: attempt + 1,
                backend: route.effective_backend.clone(),
                effective_model: Some(llm.model.clone()),
                exit_code: Some(result.exit_code),
                validation_result: cleanup_failed
                    .then(|| "not_run_process_cleanup_failed".into())
                    .or_else(|| stalled_before_changes.then(|| "not_run_backend_stalled".into()))
                    .or_else(|| {
                        stalled_during_validation
                            .then(|| "not_run_backend_stalled_during_validation".into())
                    }),
                failure_class: Some(exit_failure.failure_class.as_str().into()),
                failure_stage: Some(crate::ledger::FailureStage::AgentRun.as_str().into()),
                duration_seconds: Some(attempt_start.elapsed().as_secs_f64()),
                diff_path: None,
                checkpoint_branch: None,
                checkpoint_sha: None,
                usage: attempt_usage(
                    &result.log_path,
                    result.agy_cli_log_delta.as_deref(),
                    UsageAttribution::from_route(&route).with_fallback_model(&llm.model),
                    result.transcript_path.as_deref(),
                    Some(&claude_path),
                ),
                cli_version: result.agy_version.clone(),
            });
            record_external_approval_consumption_for_last_attempt(
                cfg,
                &args.profile,
                profile,
                ledger,
            );
            shutdown_ctx.checkpoint_after_result(ledger, shutdown_after_result)?;
            if stalled {
                notify_event(
                    cfg,
                    profile,
                    NotifyEvent::BackendStalled {
                        work_id: ledger.work_id.as_deref().unwrap_or("unknown"),
                        backend: &route.effective_backend,
                        model: route.effective_model.as_deref().unwrap_or(&llm.model),
                        duration_seconds: result.duration_secs,
                    },
                );
            }
            if cleanup_failed {
                // Set the durable gate before fallible cleanup; the outer boundary persists it.
                ledger.human_required = true;
                ledger.human_required_reason_code = Some(
                    HumanRequiredReason::TerminalHarnessFailure
                        .as_str()
                        .to_string(),
                );
                worktree::preserve_wip(
                    &wt,
                    &profile.default_target_branch,
                    &format!(
                        "gah: WIP cleanup-failed {} attempt {}",
                        args.mode,
                        attempt + 1
                    ),
                )?;
                worktree::cleanup(&wt, repo);
                anyhow::bail!("backend descendant cleanup failed; refusing to retry");
            }
            if stalled_before_changes {
                let availability_result =
                    record_exact_route_unavailability(&route, &log_text, failure_log_path);
                worktree::preserve_wip(
                    &wt,
                    &profile.default_target_branch,
                    &format!("gah: WIP failed {} attempt {}", args.mode, attempt + 1),
                )?;
                worktree::cleanup(&wt, repo);
                availability_result
                    .context("recording idle-stalled backend cooldown before ending the attempt")?;
                anyhow::bail!(
                    "{} made no repository progress (stalled before any changes) on attempt {}; not retrying blindly",
                    route.effective_backend,
                    attempt + 1
                );
            }
            if stalled_during_validation {
                // Issue #579: backend produced a diff and was validating when
                // the watchdog fired. Checkpoint the WIP diff on a repo-local
                // branch (the worktree is removed by cleanup) so a later
                // attempt can resume it instead of losing the work.
                let checkpoint = wip_checkpoint_branch(&branch, attempt + 1);
                let resumed = worktree::checkpoint_wip(
                    &wt,
                    &profile.default_target_branch,
                    &checkpoint,
                    &format!(
                        "gah: WIP checkpointed {} attempt {} (stalled during validation)",
                        args.mode,
                        attempt + 1
                    ),
                )?;
                if resumed {
                    println!(
                        "Backend stalled during validation; preserved WIP diff on local branch {checkpoint}"
                    );
                    wip_checkpoints.push(checkpoint.clone());
                }
                if attempt + 1 < max_attempts {
                    prior_phase_context = Some(task.clone());
                    task = format!(
                        "{}\n\n## Previous attempt stalled during validation (attempt {}/{})\n\nThe backend produced changes and they remain checkpointed in this worktree. Inspect and preserve that progress, finish any incomplete verification, and complete the task.",
                        base_task,
                        attempt + 1,
                        max_attempts,
                    );
                    println!(
                        "Continuing checkpointed WIP with attempt {}/{}...",
                        attempt + 2,
                        max_attempts
                    );
                    continue;
                }
                worktree::cleanup(&wt, repo);
                anyhow::bail!(
                    "{} stalled during validation after producing changes on final attempt {}; WIP checkpointed for a future continuation",
                    route.effective_backend,
                    attempt + 1
                );
            }
            if attempt + 1 < max_attempts {
                if let Some((parsed, rerouted)) = route_after_backend_unavailable(
                    cfg,
                    profile,
                    &route_req,
                    ticket_meta.as_ref(),
                    ledger,
                    &route,
                    (&log_text, failure_log_path),
                )? {
                    let current_identity =
                        route_identity(&route.effective_backend, route.effective_model.as_deref());
                    let rerouted_identity = route_identity(
                        &rerouted.effective_backend,
                        rerouted.effective_model.as_deref(),
                    );
                    if rerouted_identity != current_identity {
                        let checkpoint = wip_checkpoint_branch(&branch, attempt + 1);
                        let resumed = worktree::checkpoint_wip(
                            &wt,
                            &profile.default_target_branch,
                            &checkpoint,
                            &format!("gah: WIP failed {} attempt {}", args.mode, attempt + 1),
                        )?;
                        if resumed {
                            println!(
                                "Preserved retry progress on local branch {checkpoint}; next backend will continue it"
                            );
                            wip_checkpoints.push(checkpoint);
                        }
                        prior_phase_context = Some(task.clone());
                        let is_context_limit_exceeded =
                            parsed.kind == crate::quota_parser::FailureKind::ContextLimitExceeded;
                        let message = if is_context_limit_exceeded {
                            format!(
                                "## Context limit exceeded (attempt {}/{})\n\nThe existing checkpointed repository changes remain in this worktree. Inspect them, preserve useful progress, and complete or repair the ticket with a larger-context model.",
                                attempt + 1,
                                max_attempts
                            )
                        } else {
                            format!(
                                "## Previous backend became unavailable (attempt {}/{})\n\nThe existing checkpointed repository changes remain in this worktree. Inspect them, preserve useful progress, and complete or repair the ticket with the next backend.",
                                attempt + 1,
                                max_attempts
                            )
                        };
                        task = format!("{}\n\n{}", base_task, message,);
                        let log_message = if is_context_limit_exceeded {
                            "Context limit exceeded; retrying next attempt with larger-context model"
                        } else {
                            "Backend unavailable; retrying next attempt"
                        };
                        println!(
                            "{} with {} instead of {} ({:?})",
                            log_message,
                            route_label(
                                &rerouted.effective_backend,
                                rerouted.effective_model.as_deref(),
                            ),
                            route_label(&route.effective_backend, route.effective_model.as_deref(),),
                            parsed.kind
                        );
                        route = rerouted;
                        apply_route_to_ledger(ledger, &route);
                        preflight_identity(profile, &route.identity)?;
                        llm = resolve_llm(
                            cfg,
                            args,
                            profile.oh_profile.as_deref(),
                            route.effective_model.as_deref(),
                        )?;
                        continue;
                    }
                }
                // Live-observed bug: a generic backend error (an idle-timeout
                // kill, a transient crash, anything `mark_backend_unavailable_from_output`
                // doesn't recognize as a quota/rate-limit message) fell straight
                // through to bail!() below, ending the ENTIRE dispatch after a
                // single attempt regardless of --retries -- the reroute branch
                // above was the ONLY retry path that existed, so a non-quota
                // failure never got a second attempt at all. Retry with the
                // SAME backend/model instead, mirroring the validation-failure
                // retry path (wipe partial changes, rebuild task with context).
                println!(
                    "Backend error (exit {}) on attempt {}/{}, not a recognized quota/rate-limit signal -- retrying with the same backend...",
                    result.exit_code, attempt + 1, max_attempts
                );
                let checkpoint = wip_checkpoint_branch(&branch, attempt + 1);
                let resumed = worktree::checkpoint_wip(
                    &wt,
                    &profile.default_target_branch,
                    &checkpoint,
                    &format!("gah: WIP failed {} attempt {}", args.mode, attempt + 1),
                )?;
                if resumed {
                    println!("Preserved failed attempt on local branch {checkpoint}");
                    wip_checkpoints.push(checkpoint.clone());
                }
                prior_phase_context = Some(task.clone());
                task = if resumed {
                    format!(
                        "{}\n\n## Previous attempt did not complete (attempt {}/{})\n\nThe backend exited with code {} before finishing. Its checkpointed repository changes remain in this worktree. Inspect them, preserve useful progress, and continue the implementation.",
                        base_task,
                        attempt + 1,
                        max_attempts,
                        result.exit_code,
                    )
                } else {
                    format!(
                        "{}\n\n## Previous attempt did not complete (attempt {}/{})\n\nThe backend exited with code {} before producing repository changes. Start the implementation now.",
                        base_task,
                        attempt + 1,
                        max_attempts,
                        result.exit_code,
                    )
                };
                continue;
            }
            worktree::preserve_wip(
                &wt,
                &profile.default_target_branch,
                &format!("gah: WIP failed {} attempt {}", args.mode, attempt + 1),
            )?;
            worktree::cleanup(&wt, repo);
            anyhow::bail!(
                "backend exited {} on attempt {}",
                result.exit_code,
                attempt + 1
            );
        }

        // An exit-0 process that leaves the worktree unchanged did not
        // complete the ticket. Treating it as success would let a backend
        // consume quota, pass the repository's unchanged test suite, and
        // falsely advance the controller with no patch or PR to show for it.
        // Stop before post-change validation: there is no change to validate.
        let attempt_state_after = classify_git_operation_result(
            ledger,
            crate::ledger::FailureStage::PostValidation,
            worktree::state_snapshot(&wt),
        )?;
        match conflict_session.after_attempt(
            &base_task,
            attempt + 1,
            max_attempts,
            attempt_start.elapsed().as_secs_f64(),
            ledger,
            &route,
            &llm.model,
            &result,
            &claude_path,
        )? {
            conflict_resolution::AttemptDisposition::Ready => {}
            conflict_resolution::AttemptDisposition::Retry { task: retry_task } => {
                prior_phase_context = Some(task.clone());
                task = retry_task;
                continue;
            }
            conflict_resolution::AttemptDisposition::Terminal { message } => {
                worktree::cleanup(&wt, repo);
                anyhow::bail!("{message}");
            }
        }
        if attempt_state_after == attempt_state_before {
            // OpenCode can exit successfully after a provider rejection and
            // put the useful diagnostic only in its internal log. Inspect
            // that run-scoped tail before treating this as generic no-progress
            // so the next route cannot select the unavailable model again.
            let output_log_text = fs::read_to_string(&result.log_path).unwrap_or_default();
            let failure_text = failure_text_with_internal_log(
                &output_log_text,
                result.internal_log_delta.as_deref(),
            );
            let failure_log_path = result
                .internal_log_path
                .as_deref()
                .unwrap_or(&result.log_path);
            if let Some((parsed, rerouted)) = route_after_backend_unavailable(
                cfg,
                profile,
                &route_req,
                ticket_meta.as_ref(),
                ledger,
                &route,
                (&failure_text, failure_log_path),
            )? {
                // Issue #437: classify context exhaustion as ContextLimitExceeded, not BackendError
                let is_context_limit_exceeded =
                    parsed.kind == crate::quota_parser::FailureKind::ContextLimitExceeded;
                let failure_class = if is_context_limit_exceeded {
                    crate::ledger::FailureClass::ContextLimitExceeded
                } else {
                    crate::ledger::FailureClass::BackendError
                };
                ledger.set_failure(failure_class, crate::ledger::FailureStage::AgentRun);
                let validation_result = if is_context_limit_exceeded {
                    "not_run_context_limit_exceeded"
                } else {
                    "not_run_backend_unavailable"
                };
                ledger.attempts.push(crate::ledger::AttemptRecord {
                    resources: Some(result.resources.clone()),
                    attempt_number: attempt + 1,
                    backend: route.effective_backend.clone(),
                    effective_model: Some(llm.model.clone()),
                    exit_code: Some(0),
                    validation_result: Some(validation_result.into()),
                    failure_class: Some(failure_class.as_str().into()),
                    failure_stage: Some(crate::ledger::FailureStage::AgentRun.as_str().into()),
                    duration_seconds: Some(attempt_start.elapsed().as_secs_f64()),
                    diff_path: None,
                    checkpoint_branch: None,
                    checkpoint_sha: None,
                    usage: attempt_usage(
                        &result.log_path,
                        result.agy_cli_log_delta.as_deref(),
                        UsageAttribution::from_route(&route).with_fallback_model(&llm.model),
                        result.transcript_path.as_deref(),
                        Some(&claude_path),
                    ),
                    cli_version: result.agy_version.clone(),
                });
                record_external_approval_consumption_for_last_attempt(
                    cfg,
                    &args.profile,
                    profile,
                    ledger,
                );
                shutdown_ctx.checkpoint_after_result(ledger, shutdown_after_result)?;
                if attempt + 1 < max_attempts {
                    let current_identity =
                        route_identity(&route.effective_backend, route.effective_model.as_deref());
                    let rerouted_identity = route_identity(
                        &rerouted.effective_backend,
                        rerouted.effective_model.as_deref(),
                    );
                    if rerouted_identity != current_identity {
                        let is_context_limit_exceeded =
                            parsed.kind == crate::quota_parser::FailureKind::ContextLimitExceeded;
                        let message = if is_context_limit_exceeded {
                            "Context limit exceeded; retrying next attempt with larger-context model"
                        } else {
                            "Backend unavailable after no-progress result; retrying next attempt"
                        };
                        println!(
                            "{} with {} instead of {} ({:?})",
                            message,
                            route_label(
                                &rerouted.effective_backend,
                                rerouted.effective_model.as_deref(),
                            ),
                            route_label(&route.effective_backend, route.effective_model.as_deref(),),
                            parsed.kind
                        );
                        route = rerouted;
                        apply_route_to_ledger(ledger, &route);
                        preflight_identity(profile, &route.identity)?;
                        llm = resolve_llm(
                            cfg,
                            args,
                            profile.oh_profile.as_deref(),
                            route.effective_model.as_deref(),
                        )?;
                        continue;
                    }
                }
                worktree::cleanup(&wt, repo);
                anyhow::bail!(
                    "{} reported {:?} after attempt {} made no worktree changes",
                    route.effective_backend,
                    parsed.kind,
                    attempt + 1
                );
            }
            ledger.attempts.push(crate::ledger::AttemptRecord {
                resources: Some(result.resources.clone()),
                attempt_number: attempt + 1,
                backend: route.effective_backend.clone(),
                effective_model: Some(llm.model.clone()),
                exit_code: Some(0),
                validation_result: Some("not_run_no_changes".into()),
                failure_class: Some(crate::ledger::FailureClass::AgentNoProgress.as_str().into()),
                failure_stage: Some(crate::ledger::FailureStage::AgentRun.as_str().into()),
                duration_seconds: Some(attempt_start.elapsed().as_secs_f64()),
                diff_path: None,
                checkpoint_branch: None,
                checkpoint_sha: None,
                usage: attempt_usage(
                    &result.log_path,
                    result.agy_cli_log_delta.as_deref(),
                    UsageAttribution::from_route(&route).with_fallback_model(&llm.model),
                    result.transcript_path.as_deref(),
                    Some(&claude_path),
                ),
                cli_version: result.agy_version.clone(),
            });
            record_external_approval_consumption_for_last_attempt(
                cfg,
                &args.profile,
                profile,
                ledger,
            );
            shutdown_ctx.checkpoint_after_result(ledger, shutdown_after_result)?;
            if already_satisfied.reconcile(
                ledger,
                &backend_summary,
                &wip_checkpoints,
                matches!(
                    baseline_disposition,
                    crate::baseline::BaselineDisposition::Clean
                ),
            )? {
                return Ok(());
            }
            if attempt + 1 < max_attempts {
                // No progress is recoverable: a fresh attempt can get a
                // clearer instruction or a transient backend condition may
                // have cleared. Preserve the failed attempt in the ledger,
                // but do not stamp the overall dispatch as failed unless all
                // bounded attempts make no progress.
                println!(
                    "Backend made no changes on attempt {}/{}; retrying with explicit no-progress context...",
                    attempt + 1,
                    max_attempts
                );
                prior_phase_context = Some(task.clone());
                task = format!(
                    "{}\n\n## Previous attempt made no progress (attempt {}/{})\n\nThe backend exited successfully but did not change the worktree. Re-read the scoped task, make the required implementation change, and do not stop until a concrete diff exists.",
                    base_task,
                    attempt + 1,
                    max_attempts,
                );
                continue;
            }
            ledger.validation_result = Some("not_run_no_changes".into());
            ledger.set_failure(
                crate::ledger::FailureClass::AgentNoProgress,
                crate::ledger::FailureStage::AgentRun,
            );
            worktree::cleanup(&wt, repo);
            anyhow::bail!(
                "backend exited 0 on attempt {} but produced no worktree changes",
                attempt + 1
            );
        }

        if profile.validation_commands.is_empty() {
            ledger.validation_result = Some("not_run".into());
            ledger.attempts.push(crate::ledger::AttemptRecord {
                resources: Some(result.resources.clone()),
                attempt_number: attempt + 1,
                backend: route.effective_backend.clone(),
                effective_model: Some(llm.model.clone()),
                exit_code: Some(0),
                validation_result: None,
                failure_class: None,
                failure_stage: None,
                duration_seconds: Some(attempt_start.elapsed().as_secs_f64()),
                diff_path: None,
                checkpoint_branch: None,
                checkpoint_sha: None,
                usage: attempt_usage(
                    &result.log_path,
                    result.agy_cli_log_delta.as_deref(),
                    UsageAttribution::from_route(&route).with_fallback_model(&llm.model),
                    result.transcript_path.as_deref(),
                    Some(&claude_path),
                ),
                cli_version: result.agy_version.clone(),
            });
            shutdown_ctx.checkpoint_after_result(ledger, shutdown_after_result)?;
            break;
        }

        run_auto_fix_commands(&profile.auto_fix_commands, &wt, &validation_environment);

        println!(
            "Running validation ({} commands)...",
            profile.validation_commands.len()
        );
        match validate_with_exit_code(
            &profile.validation_commands,
            &wt,
            &validation_environment,
            timeout,
        ) {
            Ok(()) => {
                println!("Validation passed.");
                validation_failed = false;
                ledger.validation_result = Some("passed".into());
                ledger.attempts.push(crate::ledger::AttemptRecord {
                    resources: Some(result.resources.clone()),
                    attempt_number: attempt + 1,
                    backend: route.effective_backend.clone(),
                    effective_model: Some(llm.model.clone()),
                    exit_code: Some(0),
                    validation_result: Some("passed".into()),
                    failure_class: None,
                    failure_stage: None,
                    duration_seconds: Some(attempt_start.elapsed().as_secs_f64()),
                    diff_path: None,
                    checkpoint_branch: None,
                    checkpoint_sha: None,
                    usage: attempt_usage(
                        &result.log_path,
                        result.agy_cli_log_delta.as_deref(),
                        UsageAttribution::from_route(&route).with_fallback_model(&llm.model),
                        result.transcript_path.as_deref(),
                        Some(&claude_path),
                    ),
                    cli_version: result.agy_version.clone(),
                });
                attempt_bookkeeping::capture_successful_attempt(
                    cfg,
                    &args.profile,
                    &profile.local_path,
                    attempt,
                    ledger,
                );
                record_external_approval_consumption_for_last_attempt(
                    cfg,
                    &args.profile,
                    profile,
                    ledger,
                );
                break;
            }
            Err((e, exit_code)) => {
                validation_failed = true;
                let failure_output = format!("{:#}", e);
                let failure_path = attempt_session.join("validation-failure.txt");
                fs::write(&failure_path, &failure_output)?;
                println!("Validation failed ({})", failure_path.display());

                if crate::runner::shutdown_requested() {
                    record_cancelled_attempt(
                        ledger,
                        attempt + 1,
                        &route.effective_backend,
                        &llm.model,
                        result.exit_code,
                        crate::ledger::FailureStage::PostValidation,
                        attempt_start.elapsed().as_secs_f64(),
                        attempt_usage(
                            &result.log_path,
                            result.agy_cli_log_delta.as_deref(),
                            UsageAttribution::from_route(&route).with_fallback_model(&llm.model),
                            result.transcript_path.as_deref(),
                            Some(&claude_path),
                        ),
                        result.agy_version.clone(),
                        result.resources.clone(),
                    );
                    record_external_approval_consumption_for_last_attempt(
                        cfg,
                        &args.profile,
                        profile,
                        ledger,
                    );
                    worktree::preserve_wip(
                        &wt,
                        &profile.default_target_branch,
                        &format!("gah: WIP interrupted {} attempt {}", args.mode, attempt + 1),
                    )?;
                    worktree::cleanup(&wt, repo);
                    anyhow::bail!("shutdown requested during post-validation; not retrying");
                }

                if exit_code == Some(VALIDATION_COMMAND_TIMEOUT_EXIT_CODE) {
                    ledger.set_failure(
                        crate::ledger::FailureClass::HarnessError,
                        crate::ledger::FailureStage::PostValidation,
                    );
                    ledger.attempts.push(crate::ledger::AttemptRecord {
                        resources: Some(result.resources.clone()),
                        attempt_number: attempt + 1,
                        backend: route.effective_backend.clone(),
                        effective_model: Some(llm.model.clone()),
                        exit_code: Some(VALIDATION_COMMAND_TIMEOUT_EXIT_CODE),
                        validation_result: Some("failed".into()),
                        failure_class: Some(
                            crate::ledger::FailureClass::HarnessError.as_str().into(),
                        ),
                        failure_stage: Some(
                            crate::ledger::FailureStage::PostValidation.as_str().into(),
                        ),
                        duration_seconds: Some(attempt_start.elapsed().as_secs_f64()),
                        diff_path: None,
                        checkpoint_branch: None,
                        checkpoint_sha: None,
                        usage: attempt_usage(
                            &result.log_path,
                            result.agy_cli_log_delta.as_deref(),
                            UsageAttribution::from_route(&route).with_fallback_model(&llm.model),
                            result.transcript_path.as_deref(),
                            Some(&claude_path),
                        ),
                        cli_version: result.agy_version.clone(),
                    });
                    shutdown_ctx.checkpoint_after_result(ledger, shutdown_after_result)?;
                    worktree::cleanup(&wt, repo);
                    anyhow::bail!("validation timed out (harness error). {}", failure_output);
                }

                // Identical failure to the previous attempt means the agent's
                // changes had no effect on the error — almost always an
                // environment/config problem the agent cannot fix. Stop burning
                // attempts.
                let failure_progress = classify_validation_failure_progress(
                    baseline_failure.as_deref(),
                    prev_failure.as_deref(),
                    &failure_output,
                );
                // #568 AC5: a recurring failure isn't always the agent's fault -- reuse
                // the baseline classifier to catch known harness/environment signatures.
                let post_validation_disposition = crate::baseline::classify_baseline(
                    &failure_output,
                    exit_code,
                    &profile.known_baseline_failure_markers,
                );
                prev_failure = Some(failure_output.clone());
                prior_phase_context = Some(task.clone());

                if attempt + 1 < max_attempts
                    && !failure_progress.unchanged_from_baseline()
                    && !failure_progress.unchanged_from_previous_attempt()
                {
                    // Save the failed attempt's diff before wiping, so the
                    // session artifact shows what the agent actually wrote.
                    let _ = worktree::git(&["add", "-A"], &wt);
                    let mut diff_path = None;
                    if let Ok(diff) = worktree::git(&["diff", "--cached"], &wt) {
                        let path = attempt_session.join("attempt-diff.patch");
                        if fs::write(&path, diff).is_ok() {
                            diff_path = Some(path.display().to_string());
                        }
                    }
                    // Checkpoint the actual failed tree before the clean
                    // retry. The old implementation reset it in place and
                    // permanently lost substantial, often nearly-correct
                    // work whenever later attempts also failed.
                    let checkpoint = wip_checkpoint_branch(&branch, attempt + 1);
                    if worktree::checkpoint_wip(
                        &wt,
                        &profile.default_target_branch,
                        &checkpoint,
                        &format!("gah: WIP failed {} attempt {}", args.mode, attempt + 1),
                    )? {
                        println!("Preserved failed attempt on local branch {checkpoint}");
                        wip_checkpoints.push(checkpoint.clone());
                    }
                    // Issue #537: a repair (`repair_base_sha` set) must
                    // retry from its own branch, never the default target --
                    // resetting to `main` here silently discards the PR
                    // being repaired. Confirm the remote hasn't advanced
                    // since the repair began before reusing it as the reset
                    // base; a concurrent push must fail closed, not be
                    // silently discarded by the reset.
                    if let Some(ref base_sha) = repair_base_sha {
                        let observed = worktree::fetch_remote_branch_sha(repo, &wt, &branch)?;
                        if &observed != base_sha {
                            ledger.set_failure(
                                crate::ledger::FailureClass::StaleSource,
                                crate::ledger::FailureStage::PostValidation,
                            );
                            worktree::cleanup(&wt, repo);
                            return Err(repair_context::StaleSourceError {
                                branch: branch.clone(),
                                reason:
                                    "remote branch advanced during repair retry (concurrent push)"
                                        .to_string(),
                                expected_source_sha: Some(base_sha.clone()),
                                observed_source_sha: Some(observed),
                            }
                            .into());
                        }
                        worktree::reset_to_target(&wt, &branch)?;
                    } else {
                        worktree::reset_to_target(&wt, &profile.default_target_branch)?;
                    }
                    println!("Retrying with failure context...");
                    ledger.attempts.push(crate::ledger::AttemptRecord {
                        resources: Some(result.resources.clone()),
                        attempt_number: attempt + 1,
                        backend: route.effective_backend.clone(),
                        effective_model: Some(llm.model.clone()),
                        exit_code: Some(0),
                        validation_result: Some("failed".into()),
                        failure_class: Some(
                            crate::ledger::FailureClass::ValidationFailure
                                .as_str()
                                .into(),
                        ),
                        failure_stage: Some(
                            crate::ledger::FailureStage::PostValidation.as_str().into(),
                        ),
                        duration_seconds: Some(attempt_start.elapsed().as_secs_f64()),
                        diff_path,
                        checkpoint_branch: None,
                        checkpoint_sha: None,
                        usage: attempt_usage(
                            &result.log_path,
                            result.agy_cli_log_delta.as_deref(),
                            UsageAttribution::from_route(&route).with_fallback_model(&llm.model),
                            result.transcript_path.as_deref(),
                            Some(&claude_path),
                        ),
                        cli_version: result.agy_version.clone(),
                    });
                    record_external_approval_consumption_for_last_attempt(
                        cfg,
                        &args.profile,
                        profile,
                        ledger,
                    );
                    shutdown_ctx.checkpoint_after_result(ledger, shutdown_after_result)?;
                    // Rebuild from the base task with only the latest failure —
                    // accumulating retry blocks confuses smaller models.
                    task = format!(
                        "{}\n\n## Previous attempt failed validation (attempt {}/{})\n\nThe previous tree was checkpointed locally as `{}`. This retry starts from a clean target branch. Fix the following before completing the task:\n\n```\n{}\n```",
                        base_task,
                        attempt + 1,
                        max_attempts,
                        checkpoint,
                        utf8_safe_prefix(&failure_output, 8_000),
                    );
                    let rerouted = validation_retry_route(
                        cfg,
                        profile,
                        &route_req,
                        ticket_meta.as_ref(),
                        ledger,
                        &route,
                    )?;
                    let current_identity =
                        route_identity(&route.effective_backend, route.effective_model.as_deref());
                    let rerouted_identity = route_identity(
                        &rerouted.effective_backend,
                        rerouted.effective_model.as_deref(),
                    );
                    if rerouted_identity != current_identity {
                        println!(
                            "Escalating retry after validation failure: {} -> {}",
                            route_label(&route.effective_backend, route.effective_model.as_deref()),
                            route_label(
                                &rerouted.effective_backend,
                                rerouted.effective_model.as_deref(),
                            ),
                        );
                        route = rerouted;
                        apply_route_to_ledger(ledger, &route);
                        preflight_identity(profile, &route.identity)?;
                        llm = resolve_llm(
                            cfg,
                            args,
                            profile.oh_profile.as_deref(),
                            route.effective_model.as_deref(),
                        )?;
                    }
                } else if attempt + 1 < max_attempts && !args.allow_draft_fail {
                    let Some(reason) = validation_failure_no_progress_reason(failure_progress)
                    else {
                        worktree::preserve_wip(
                            &wt,
                            &profile.default_target_branch,
                            &format!("gah: WIP failed {} attempt {}", args.mode, attempt + 1),
                        )?;
                        worktree::cleanup(&wt, repo);
                        anyhow::bail!(
                            "validation failed after {} attempt(s). Use --allow-draft-fail to push anyway.\n\n{}",
                            max_attempts,
                            utf8_safe_prefix(&failure_output, 4_000),
                        );
                    };
                    // No progress -- usually the agent's fault, unless the recurring
                    // text is a known harness/environment signature (#568 AC5).
                    use crate::baseline::BaselineDisposition as BD;
                    use crate::ledger::{FailureClass as FC, FailureStage as FS};
                    let no_progress_class = match post_validation_disposition {
                        BD::HarnessError => FC::HarnessError,
                        BD::EnvironmentError => FC::EnvironmentError,
                        BD::Clean | BD::ExpectedRed | BD::UnknownRed => FC::AgentNoProgress,
                    };
                    ledger.set_failure(no_progress_class, FS::PostValidation);
                    attempt_bookkeeping::record_failed_validation_attempt(
                        ledger,
                        cfg,
                        &args.profile,
                        profile,
                        &shutdown_ctx,
                        shutdown_after_result,
                        attempt,
                        &route,
                        &llm,
                        &result,
                        &claude_path,
                        attempt_start,
                        "failed",
                        Some(no_progress_class.as_str().into()),
                        Some(FS::PostValidation.as_str().into()),
                    )?;
                    worktree::preserve_wip(
                        &wt,
                        &profile.default_target_branch,
                        &format!("gah: WIP failed {} attempt {}", args.mode, attempt + 1),
                    )?;
                    worktree::cleanup(&wt, repo);
                    let label = match no_progress_class {
                        FC::HarnessError | FC::EnvironmentError => {
                            "Validation infrastructure failure recurred unchanged"
                        }
                        _ => reason,
                    };
                    anyhow::bail!(
                        "{} Aborting early after attempt {}.\n\n{}",
                        label,
                        attempt + 1,
                        utf8_safe_prefix(&failure_output, 4_000),
                    );
                } else if args.allow_draft_fail {
                    println!(
                        "Validation still failing; --allow-draft-fail set — pushing as draft."
                    );
                    ledger.validation_result = Some("failed-draft".into());
                    attempt_bookkeeping::record_failed_validation_attempt(
                        ledger,
                        cfg,
                        &args.profile,
                        profile,
                        &shutdown_ctx,
                        shutdown_after_result,
                        attempt,
                        &route,
                        &llm,
                        &result,
                        &claude_path,
                        attempt_start,
                        "failed-draft",
                        None,
                        None,
                    )?;
                    break;
                } else {
                    attempt_bookkeeping::record_failed_validation_attempt(
                        ledger,
                        cfg,
                        &args.profile,
                        profile,
                        &shutdown_ctx,
                        shutdown_after_result,
                        attempt,
                        &route,
                        &llm,
                        &result,
                        &claude_path,
                        attempt_start,
                        "failed",
                        Some(
                            crate::ledger::FailureClass::ValidationFailure
                                .as_str()
                                .into(),
                        ),
                        Some(crate::ledger::FailureStage::PostValidation.as_str().into()),
                    )?;
                    worktree::preserve_wip(
                        &wt,
                        &profile.default_target_branch,
                        &format!("gah: WIP failed {} attempt {}", args.mode, attempt + 1),
                    )?;
                    worktree::cleanup(&wt, repo);
                    anyhow::bail!(
                        "validation failed after {} attempt(s). Use --allow-draft-fail to push anyway.\n\n{}",
                        max_attempts,
                        utf8_safe_prefix(&failure_output, 4_000),
                    );
                }
            }
        }
    }

    finish_improve_workflow(
        cfg,
        profile,
        &args.mode,
        ledger,
        &wt,
        repo,
        &branch,
        manual_fix.existing_branch.is_some(),
        ticket_meta.as_ref(),
        issue_details.as_ref(),
        &conflict_session,
        &already_satisfied,
        validation_failed,
        &backend_summary,
        &wip_checkpoints,
        &route.effective_backend,
        route.effective_model.as_deref(),
        &llm.model,
    )
}

#[cfg(test)]
mod tests;
