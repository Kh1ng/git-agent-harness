mod routing_record;
pub(super) use routing_record::record_route_attempt;
mod execution_env;
use super::command::which;
pub(super) use execution_env::apply_execution_identity_env;

pub(crate) mod external_approval_gap;
use super::DispatchArgs;
use crate::backend_kind::BackendKind;
use crate::config::{self, GahConfig, Profile};
use crate::controller::HumanRequiredReason;
use crate::ledger::{self, LedgerEntry};
use crate::models::WorkMetadata;
use crate::routing::{
    self, CandidateIdentity, RouteDecision, RouteError, RouteRequest, RoutingRuntimeState,
    TaskRoutingContext,
};
use crate::usage_attribution::{normalize_attempt_usage, UsageAttribution};
use crate::{runner, usage, worktree};
use anyhow::{Context, Result};
pub(crate) use external_approval_gap::{ExternalApprovalRequiredError, ExternalCredentialGap};
use std::fs;
use std::path::Path;
use time::format_description::well_known::Rfc3339;
use time::OffsetDateTime;

pub(super) fn mark_shutdown_cancelled(
    ledger: &mut LedgerEntry,
    stage: crate::ledger::FailureStage,
    backend_exit_code: Option<i32>,
) {
    ledger.set_failure(crate::ledger::FailureClass::HarnessError, stage);
    ledger.backend_exit_code = backend_exit_code;
    ledger.validation_result = Some("cancelled_shutdown".into());
}
pub(super) fn resolve_llm(
    cfg: &GahConfig,
    args: &DispatchArgs,
    profile_oh: Option<&str>,
    effective_model: Option<&str>,
) -> Result<runner::LlmConfig> {
    // CLI flag wins, then profile config, then default
    let effective_oh_profile = args.oh_profile.as_deref().or(profile_oh);
    if let Some(name) = effective_oh_profile {
        let mut llm = runner::load_oh_profile(name)?;
        if let Some(m) = &args.model {
            llm.model = m.clone();
        }
        if let Some(m) = effective_model {
            llm.model = m.to_string();
        }
        if let Ok(v) = std::env::var("LLM_BASE_URL") {
            llm.base_url = v;
        }
        if let Ok(v) = std::env::var("LLM_API_KEY") {
            llm.api_key = v;
        }
        if let Ok(v) = std::env::var("LLM_MODEL") {
            llm.model = v;
        }
        return Ok(llm);
    }
    // --model flag always wins
    if let Some(m) = &args.model {
        return Ok(runner::LlmConfig {
            base_url: cfg.defaults.llm_base_url(),
            api_key: cfg.defaults.llm_api_key(),
            model: m.clone(),
        });
    }
    if let Some(m) = effective_model {
        return Ok(runner::LlmConfig {
            base_url: cfg.defaults.llm_base_url(),
            api_key: cfg.defaults.llm_api_key(),
            model: m.to_string(),
        });
    }
    // Check profile-level mode-specific override, then global default
    let profile_model = config::get_profile(cfg, &args.profile).ok().and_then(|p| {
        match crate::job_kind::JobKind::parse(&args.mode) {
            Ok(crate::job_kind::JobKind::Improve | crate::job_kind::JobKind::Fix) => {
                p.model_improve.clone()
            }
            Ok(crate::job_kind::JobKind::Pm) => p.model_pm.clone(),
            Ok(crate::job_kind::JobKind::Review) => p.model_review.clone(),
            _ => None,
        }
    });
    let cloud = args.backend == "cloud-coder";
    Ok(runner::LlmConfig {
        base_url: cfg.defaults.llm_base_url(),
        api_key: cfg.defaults.llm_api_key(),
        model: profile_model.unwrap_or_else(|| cfg.defaults.llm_model(cloud)),
    })
}

pub(super) fn reserve_backend_slot(
    profile: &Profile,
    identity: &crate::execution_identity::ExecutionIdentity,
    wait_for_capacity: bool,
) -> Result<routing::ConcurrencyGuard> {
    let concurrency_cap = profile
        .max_concurrent_per_model
        .get(&format!(
            "{}/{}",
            identity.logical_backend,
            identity.effective_model.as_deref().unwrap_or("")
        ))
        .copied();
    if wait_for_capacity {
        routing::ConcurrencyGuard::acquire_shared_for_identity(
            identity,
            concurrency_cap,
            crate::runner::shutdown_requested,
        )
    } else {
        routing::ConcurrencyGuard::try_acquire_shared_for_identity(identity, concurrency_cap)?
            .ok_or_else(|| {
                crate::routing::RouteError::NoEligibleBackend {
                    preferred_backend: identity.logical_backend.clone(),
                    preferred_model: identity.effective_model.clone(),
                    skipped: vec![crate::routing::SkippedBackend {
                        backend_instance: None,
                        backend: identity.logical_backend.clone(),
                        model: identity.effective_model.clone(),
                        reason: "max_concurrent_reached".into(),
                        unavailable_until: None,
                    }],
                    earliest_reset: None,
                }
                .into()
            })
    }
}

pub(super) struct BackendAdmissionGuard {
    _route: routing::ConcurrencyGuard,
    _node: Option<crate::controller::WorkerNodeLease>,
}

/// A parallel sibling reached routing after another worker reserved the only
/// available backend/model slot. This is typed capacity contention, not a
/// failed backend execution.
pub fn capacity_deferred_error(error: &anyhow::Error) -> bool {
    error.chain().any(|cause| {
        cause
            .downcast_ref::<crate::routing::RouteError>()
            .is_some_and(crate::routing::RouteError::is_capacity_deferral)
            || cause
                .downcast_ref::<crate::controller::NodeAdmissionDeferred>()
                .is_some()
            || cause
                .downcast_ref::<PostAttemptCapacityDeferred>()
                .is_some()
    })
}

pub fn node_capacity_deferred_error(error: &anyhow::Error) -> bool {
    error.chain().any(|cause| {
        cause
            .downcast_ref::<crate::controller::NodeAdmissionDeferred>()
            .is_some()
            || cause
                .downcast_ref::<PostAttemptCapacityDeferred>()
                .is_some_and(|deferred| deferred.node_capacity)
    })
}

#[derive(Debug)]
struct PostAttemptCapacityDeferred {
    attempts_completed: usize,
    node_capacity: bool,
    detail: String,
}

impl std::fmt::Display for PostAttemptCapacityDeferred {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            formatter,
            "fallback capacity deferred after {} backend attempt(s): {}",
            self.attempts_completed, self.detail
        )
    }
}

impl std::error::Error for PostAttemptCapacityDeferred {}

pub(crate) fn contextualize_capacity_deferral(
    error: anyhow::Error,
    attempts_completed: usize,
) -> anyhow::Error {
    if attempts_completed == 0 || !capacity_deferred_error(&error) {
        return error;
    }
    PostAttemptCapacityDeferred {
        attempts_completed,
        node_capacity: node_capacity_deferred_error(&error),
        detail: error.to_string(),
    }
    .into()
}

pub(crate) fn post_attempt_capacity_deferral(error: &anyhow::Error) -> Option<usize> {
    error.chain().find_map(|cause| {
        cause
            .downcast_ref::<PostAttemptCapacityDeferred>()
            .map(|deferred| deferred.attempts_completed)
    })
}

pub(super) fn reserve_backend_attempt(
    profile: &Profile,
    identity: &crate::execution_identity::ExecutionIdentity,
    route_admission: Option<&crate::controller::RouteNodeAdmission>,
) -> Result<BackendAdmissionGuard> {
    let route = reserve_backend_slot(profile, identity, route_admission.is_none())?;
    let node = route_admission
        .map(crate::controller::RouteNodeAdmission::wait_for_node)
        .transpose()?;
    Ok(BackendAdmissionGuard {
        _route: route,
        _node: node,
    })
}

pub(super) fn apply_backend_instance_env(
    profile: &Profile,
    backend: &str,
    env_vars: &mut Vec<(String, String)>,
) {
    if backend == "agy-second" {
        if let Some(home) = profile.agy_second_home.as_deref().filter(|h| !h.is_empty()) {
            // Keep one authoritative HOME so both Command and usage/log
            // capture resolve the same backend instance. Several capture
            // helpers intentionally read the first matching environment key.
            env_vars.retain(|(key, _)| key != "HOME");
            env_vars.push(("HOME".to_string(), home.to_string()));
        }
    }
}

pub(super) fn record_external_approval_consumption_for_last_attempt(
    cfg: &GahConfig,
    profile_name: &str,
    profile: &Profile,
    ledger: &LedgerEntry,
) {
    let Some(attempt) = ledger.attempts.last() else {
        return;
    };
    let _ = ledger::record_external_approval_consumption_for_work_item(
        cfg,
        profile_name,
        profile,
        ledger.work_id.as_deref(),
        &attempt.usage,
    );
}

pub(super) fn external_env_vars_for_work_item(
    cfg: &GahConfig,
    profile_name: &str,
    profile: &Profile,
    work_id: Option<&str>,
    env_path: Option<&str>,
) -> Vec<(String, String)> {
    let Some(work_id) = work_id else {
        return Vec::new();
    };
    let Ok(entries) = ledger::read_entries(cfg) else {
        return Vec::new();
    };
    let allowed = ledger::active_external_approval_env_vars_from_entries(
        &entries,
        profile_name,
        &profile.repo_id,
        work_id,
    );
    let declared_external_env_vars: std::collections::HashSet<String> = profile
        .external_credential_scopes
        .values()
        .flat_map(|scope| scope.env_vars.iter().cloned())
        .collect();
    let mut env_vars = env_path.map(runner::load_env_file).unwrap_or_default();
    env_vars.retain(|(key, _)| !declared_external_env_vars.contains(key) || allowed.contains(key));
    env_vars
}

fn execution_identity_executable(
    profile: &Profile,
    identity: &crate::execution_identity::ExecutionIdentity,
) -> Result<std::path::PathBuf> {
    match identity.executable.as_ref() {
        Some(path) if path.as_os_str().is_empty() => anyhow::bail!(
            "backend instance '{}' is missing an explicit executable binding",
            identity.backend_instance
        ),
        Some(path) if crate::runner::is_executable_path(path) => Ok(path.clone()),
        Some(path) => anyhow::bail!(
            "configured executable '{}' for instance '{}' does not exist or is not executable",
            path.display(),
            identity.backend_instance
        ),
        None => runner::require_backend_executable(profile, &identity.logical_backend),
    }
}

#[allow(clippy::too_many_arguments)]
#[cfg(test)]
pub(super) fn run_backend(
    cfg: &GahConfig,
    profile_name: &str,
    backend: &str,
    profile: &Profile,
    wt: &Path,
    task: &str,
    session_dir: &Path,
    cargo_target: &crate::build_cache::ScopedCargoTarget,
    llm: &runner::LlmConfig,
    effective_model: Option<&str>,
    env_path: Option<&str>,
    work_id: Option<&str>,
    hard_timeout_seconds: Option<u64>,
) -> Result<runner::RunResult> {
    let identity = crate::execution_identity::ExecutionIdentity::legacy_candidate(
        backend,
        effective_model,
        None::<String>,
    );
    run_backend_with_reserved_route(
        &identity,
        profile,
        wt,
        task,
        session_dir,
        cargo_target,
        llm,
        env_path,
        cfg,
        profile_name,
        work_id,
        false,
        hard_timeout_seconds,
    )
}

#[allow(clippy::too_many_arguments)]
pub(super) fn run_backend_for_identity(
    cfg: &GahConfig,
    profile_name: &str,
    identity: &crate::execution_identity::ExecutionIdentity,
    profile: &Profile,
    wt: &Path,
    task: &str,
    session_dir: &Path,
    cargo_target: &crate::build_cache::ScopedCargoTarget,
    llm: &runner::LlmConfig,
    env_path: Option<&str>,
    work_id: Option<&str>,
    hard_timeout_seconds: Option<u64>,
) -> Result<runner::RunResult> {
    run_backend_with_reserved_route(
        identity,
        profile,
        wt,
        task,
        session_dir,
        cargo_target,
        llm,
        env_path,
        cfg,
        profile_name,
        work_id,
        false,
        hard_timeout_seconds,
    )
}

#[allow(clippy::too_many_arguments)]
pub(super) fn run_backend_with_reserved_route(
    identity: &crate::execution_identity::ExecutionIdentity,
    profile: &Profile,
    wt: &Path,
    task: &str,
    session_dir: &Path,
    cargo_target: &crate::build_cache::ScopedCargoTarget,
    llm: &runner::LlmConfig,
    env_path: Option<&str>,
    cfg: &GahConfig,
    profile_name: &str,
    work_id: Option<&str>,
    route_slot_already_reserved: bool,
    hard_timeout_seconds: Option<u64>,
) -> Result<runner::RunResult> {
    // Live incident (2026-07-11): concurrent dispatches landing on the same
    // shared free-tier backend+model (opencode/hy3-free) silently rate-limit.
    // Held for the duration of the actual backend call -- dropped on every
    // exit path (success, error, or panic) -- so routing's
    // `max_concurrent_per_model` check sees an accurate live count.
    let _concurrency_slot = (!route_slot_already_reserved)
        .then(|| reserve_backend_slot(profile, identity, true))
        .transpose()?;
    let backend = identity.logical_backend.as_str();
    let runner_kind = identity.runner_kind.as_str();
    let effective_model = identity.effective_model.as_deref();
    let executable = execution_identity_executable(profile, identity)?;
    identity.validate_launch_config(wt)?;
    identity.validate_credential_args(match identity.runner_kind.as_str() {
        "claude" => &profile.claude_args,
        "hermes" => &profile.hermes_args,
        "opencode" => &profile.opencode_args,
        _ => &[],
    })?;
    let origin_before = worktree::git(&["remote", "get-url", "origin"], wt).ok();
    let mut env_vars =
        external_env_vars_for_work_item(cfg, profile_name, profile, work_id, env_path);
    // Issue #653: a work item whose declared external credential scope is
    // present in the environment but unapproved pauses HERE — before any
    // backend launch, before any attempt is consumed — with the approval
    // request raised and the operator notified. A valid grant releases the
    // hold and the existing loop re-selects the work.
    let gaps = external_approval_gap::external_approval_gaps_for_work_item(
        cfg,
        profile_name,
        profile,
        work_id,
        env_path,
    );
    if !gaps.is_empty() {
        return Err(anyhow::Error::new(
            external_approval_gap::ExternalApprovalRequiredError {
                profile: profile_name.to_string(),
                work_id: work_id.unwrap_or_default().to_string(),
                gaps,
            },
        ));
    }
    // Every agent and any test command it launches inherit this repository-
    // scoped target directory. Cargo safely serializes concurrent builds in a
    // shared target dir, while separate worktree-local `target/` directories
    // otherwise multiply multi-gigabyte artifacts until the host fills.
    // Use the complete ScopedCargoTarget environment (CARGO_TARGET_DIR and RUSTC_WRAPPER)
    // to ensure sccache is used when available.
    env_vars.extend(cargo_target.environment());
    apply_execution_identity_env(profile, identity, &mut env_vars)?;
    execution_env::authorize_identity(cfg, profile_name, profile, work_id, identity)?;
    let selected_llm = match execution_env::selected_llm(identity, llm, &env_vars) {
        Ok(value) => value,
        Err(_) => anyhow::bail!("selected inference configuration unavailable"),
    };
    let llm = &selected_llm;
    env_vars.retain(|(key, _)| key != crate::runner::process::HARD_TIMEOUT_ENV);
    if let Some(seconds) = hard_timeout_seconds.filter(|seconds| *seconds > 0) {
        env_vars.push((
            crate::runner::process::HARD_TIMEOUT_ENV.to_string(),
            seconds.to_string(),
        ));
    }
    let backend_kind = match BackendKind::parse(runner_kind) {
        Ok(kind) => kind,
        Err(_) => anyhow::bail!("unsupported runner kind '{runner_kind}' for backend '{backend}'"),
    };
    let skill_resolution = crate::skill_bindings::resolve(
        &cfg.defaults,
        profile_name,
        backend,
        identity
            .explicit_instance
            .then_some(identity.backend_instance.as_str()),
    )?;

    // Issue #832: the runner invocation itself goes through the uniform
    // `for_kind` constructor so dispatch no longer hand-maintains a match
    // over backend runner implementations. What legitimately stays per-kind
    // is the launch shape each backend reads from the profile: its args,
    // idle timeout, and whether it takes an LLM config / print timeout.
    struct LaunchShape<'a> {
        model: Option<&'a str>,
        llm: Option<&'a runner::LlmConfig>,
        extra_args: &'a [String],
        idle_timeout_seconds: u64,
        print_timeout_seconds: Option<u64>,
    }
    let skill_args;
    let shape = match backend_kind {
        BackendKind::Codex => LaunchShape {
            model: effective_model,
            llm: None,
            extra_args: &profile.codex_args,
            idle_timeout_seconds: profile.codex_idle_timeout_seconds(),
            print_timeout_seconds: None,
        },
        BackendKind::Claude => LaunchShape {
            model: effective_model,
            llm: None,
            extra_args: &profile.claude_args,
            idle_timeout_seconds: profile.claude_idle_timeout_seconds(),
            print_timeout_seconds: None,
        },
        BackendKind::Agy => LaunchShape {
            model: None,
            llm: Some(llm),
            extra_args: &[],
            idle_timeout_seconds: profile.agy_idle_timeout_seconds(),
            print_timeout_seconds: profile
                .agy_print_timeout_seconds
                .get(llm.model.as_str())
                .copied(),
        },
        BackendKind::Vibe => LaunchShape {
            model: effective_model,
            llm: None,
            extra_args: &profile.vibe_args,
            idle_timeout_seconds: profile.vibe_idle_timeout_seconds(),
            print_timeout_seconds: None,
        },
        BackendKind::Opencode => LaunchShape {
            model: effective_model,
            llm: None,
            extra_args: &profile.opencode_args,
            idle_timeout_seconds: effective_model
                .and_then(|m| {
                    profile
                        .opencode_idle_timeout_seconds_by_model
                        .get(m)
                        .copied()
                })
                .unwrap_or_else(|| profile.opencode_idle_timeout_seconds()),
            print_timeout_seconds: None,
        },
        BackendKind::Openhands => {
            skill_args = crate::skill_bindings::materialize_args(
                "openhands",
                &profile.openhands_args,
                &skill_resolution.skills,
            );
            LaunchShape {
                model: None,
                llm: Some(llm),
                extra_args: &skill_args,
                idle_timeout_seconds: profile.openhands_idle_timeout_seconds(),
                print_timeout_seconds: None,
            }
        }
        BackendKind::Hermes => {
            skill_args = crate::skill_bindings::materialize_args(
                "hermes",
                &profile.hermes_args,
                &skill_resolution.skills,
            );
            LaunchShape {
                model: effective_model,
                llm: None,
                extra_args: &skill_args,
                idle_timeout_seconds: profile.hermes_idle_timeout_seconds(),
                print_timeout_seconds: None,
            }
        }
    };
    let result = runner::for_kind(backend_kind).run(&runner::RunContext {
        executable: &executable,
        worktree: wt,
        task,
        session_dir,
        model: shape.model,
        llm: shape.llm,
        extra_args: shape.extra_args,
        env_vars: &env_vars,
        idle_timeout_seconds: shape.idle_timeout_seconds,
        print_timeout_seconds: shape.print_timeout_seconds,
    });
    if let Some(origin_before) = origin_before {
        let origin_after = worktree::git(&["remote", "get-url", "origin"], wt)
            .context("checking git origin after backend run")?;
        if origin_after != origin_before {
            anyhow::bail!(
                "git origin changed during backend run: before='{origin_before}' after='{origin_after}'"
            );
        }
    }
    result
}

/// TICKET-101: usage the backend reported for exactly this attempt.
/// `RunResult` only carries a log path, not captured stdout in memory (see
/// `ReviewRunResult` for the pattern that does), so this reads that one
/// attempt's own log from disk. A read or parse failure yields an empty
/// (all-`None`) `LedgerUsage`, never a fabricated zero.
///
/// Issue #152: tries the codex exec --json parser first (JSONL event stream
/// produced when `--json` is passed to codex exec). Falls back to the
/// generic regex-based parser for non-JSONL output from other backends.
///
/// Issue #155: for AGY, also merges in the run-scoped cli.log delta
/// (quota/reset messages) -- the offset-scoped tail captured by runner,
/// NOT a fresh read of the whole cli.log, so a single attempt's usage is
/// never polluted by prior runs or concurrent appends.
pub(super) fn attempt_usage(
    log_path: &str,
    agy_cli_log_delta: Option<&str>,
    attribution: UsageAttribution<'_>,
    transcript_path: Option<&str>,
    claude_path: Option<&str>,
) -> crate::ledger::LedgerUsage {
    let text = match fs::read_to_string(log_path) {
        Ok(t) => t,
        Err(_) => {
            return normalize_attempt_usage(
                crate::ledger::LedgerUsage::default(),
                attribution,
                true,
            );
        }
    };
    let behavior_metrics = crate::telemetry::extractor::parse_structured_behavior_events(&text);
    let finalize = |mut usage: crate::ledger::LedgerUsage| {
        if let Some(metrics) = &behavior_metrics {
            usage = usage::merge_usage(
                usage,
                crate::ledger::LedgerUsage {
                    behavior_metrics: Some(metrics.clone()),
                    ..crate::ledger::LedgerUsage::default()
                },
            );
        }
        normalize_attempt_usage(usage, attribution, true)
    };
    let backend_kind = crate::usage_attribution::backend_kind_of(attribution.backend);

    // Claude Code: prefer the structured session transcript for real
    // per-attempt token/cost usage (issue #153). Never scrape stdout text.
    if backend_kind == Some(BackendKind::Claude) {
        if let Some(transcript) = transcript_path {
            if let Ok(t) = fs::read_to_string(transcript) {
                let transcript_usage = crate::claude_monitor::parse_claude_transcript_usage(&t);
                if transcript_usage.usage_source.is_some() {
                    let mut merged = transcript_usage;
                    // Merge any quota/cost info the log text parser still finds.
                    let log_usage = usage::parse_generic_usage(&text, "attempt_output_log");
                    merged = usage::merge_usage(merged, log_usage);
                    // Optionally enrich with a live `/usage` PTY probe (issue
                    // #153). Gated behind GAH_CLAUDE_LIVE_USAGE so normal
                    // dispatch stays bounded — the probe only runs when the
                    // operator explicitly opts in.
                    if let Some(path) = claude_path {
                        if std::env::var_os("GAH_CLAUDE_LIVE_USAGE").is_some() {
                            if let Ok(capture) =
                                crate::claude_monitor::capture_usage_via_pty(path, None)
                            {
                                let live =
                                    crate::claude_monitor::parse_claude_usage_text(&capture.raw);
                                merged = usage::merge_usage(merged, live);
                            }
                        }
                    }
                    if merged.usage_source.is_some() {
                        merged.observed_at = Some(
                            time::OffsetDateTime::now_utc()
                                .format(&time::format_description::well_known::Rfc3339)
                                .unwrap_or_default(),
                        );
                    }
                    return finalize(merged);
                }
            }
        }
        // No transcript yet (or none located): fall back to the generic
        // stdout parser so partial observations are still recorded.
        let mut usage = usage::parse_generic_usage(&text, "attempt_output_log");
        if usage.usage_source.is_some() {
            usage.observed_at = Some(
                time::OffsetDateTime::now_utc()
                    .format(&time::format_description::well_known::Rfc3339)
                    .unwrap_or_default(),
            );
        }
        return finalize(usage);
    }

    // Vibe's structured session metadata is passed through the same artifact
    // slot as Claude's transcript.
    if backend_kind == Some(BackendKind::Vibe) {
        if let Some(metadata) = transcript_path {
            if let Ok(metadata_json) = fs::read_to_string(metadata) {
                let session_usage = usage::parse_vibe_session_metadata(&metadata_json);
                if session_usage.usage_source.is_some() {
                    return finalize(session_usage);
                }
            }
        }
    }

    // OpenCode persists exact per-session model and token counters in its
    // local SQLite store. The runner snapshots only this invocation's row
    // into a JSON artifact, avoiding a racy global "latest session" lookup.
    if backend_kind == Some(BackendKind::Opencode) {
        if let Some(metadata) = transcript_path {
            if let Ok(metadata_json) = fs::read_to_string(metadata) {
                let session_usage = usage::parse_opencode_session_metadata(&metadata_json);
                if session_usage.usage_source.is_some() {
                    return finalize(session_usage);
                }
            }
        }
    }

    // Try codex exec --json parser first — handles JSONL output from
    // codex exec --json where the generic regex parser would find nothing.
    let mut usage = if backend_kind == Some(BackendKind::Codex) {
        usage::parse_codex_exec_json(&text)
    } else if backend_kind == Some(BackendKind::Agy) {
        usage::parse_agy_output_json(&text)
    } else {
        crate::ledger::LedgerUsage::default()
    };
    if backend_kind == Some(BackendKind::Codex) {
        if let Some(transcript) = transcript_path {
            if let Ok(transcript_jsonl) = fs::read_to_string(transcript) {
                usage = usage::merge_usage(
                    usage,
                    usage::parse_codex_transcript_attribution(&transcript_jsonl),
                );
            }
        }
    }
    if backend_kind == Some(BackendKind::Openhands) {
        let openhands_usage = usage::parse_openhands_usage(&text);
        if openhands_usage.usage_source.is_some() {
            usage = usage::merge_usage(openhands_usage, usage);
        }
    }
    let has_json_lines = text.lines().any(|line| line.trim_start().starts_with('{'));
    if usage.usage_source.is_none() && (backend_kind != Some(BackendKind::Codex) || !has_json_lines)
    {
        // Fall back to the generic regex-based parser for other backends (or
        // for codex running in non-JSON mode).
        usage = usage::parse_generic_usage(&text, "attempt_output_log");
    }

    if let Some(delta) = agy_cli_log_delta {
        let agy = usage::parse_agy_cli_log_delta(delta, "agy_cli_log_delta");
        usage = usage::merge_usage(usage, agy);
    }

    if usage.usage_source.is_some() {
        usage.observed_at = Some(
            time::OffsetDateTime::now_utc()
                .format(&time::format_description::well_known::Rfc3339)
                .unwrap_or_default(),
        );
    }
    finalize(usage)
}

/// Attribute a review invocation even when the reviewer does not expose token
/// counters. Reviews consume the same subscription/API capacity as coding
/// attempts, so an empty review-output parser result must not turn a completed
/// reviewer run into an invisible zero-usage ledger record.
///
/// AGY receives its fully-qualified model label as an explicit `--model`
/// argument. In that case the invoked model is directly observable from the
/// command contract, so retain it as the actual model when AGY itself did not
/// emit a more specific observation. Other backends may resolve aliases or
/// proxy routes after launch; leave their actual model unknown unless their
/// backend artifact reports it.
pub(super) fn review_usage(
    log_path: &str,
    agy_cli_log_delta: Option<&str>,
    attribution: UsageAttribution<'_>,
    usage_artifact_path: Option<&str>,
    claude_path: Option<&str>,
) -> crate::ledger::LedgerUsage {
    attempt_usage(
        log_path,
        agy_cli_log_delta,
        attribution,
        usage_artifact_path,
        claude_path,
    )
}

#[cfg(test)]
pub(super) fn preflight(profile: &Profile, backend: &str) -> Result<()> {
    let identity = crate::execution_identity::ExecutionIdentity::legacy_candidate(
        backend,
        None::<String>,
        None::<String>,
    );
    preflight_identity(profile, &identity)
}

pub(super) fn preflight_identity(
    profile: &Profile,
    identity: &crate::execution_identity::ExecutionIdentity,
) -> Result<()> {
    ensure_bin("git")?;
    ensure_supported_runner_kind(identity)?;
    execution_identity_executable(profile, identity)?;
    Ok(())
}

fn ensure_supported_runner_kind(
    identity: &crate::execution_identity::ExecutionIdentity,
) -> Result<()> {
    if matches!(
        identity.runner_kind.as_str(),
        "agy" | "claude" | "codex" | "openhands" | "opencode" | "vibe"
    ) {
        Ok(())
    } else {
        anyhow::bail!(
            "backend instance '{}' has unsupported runner kind '{}'",
            identity.backend_instance,
            identity.runner_kind
        )
    }
}

/// TICKET-109: capabilities required for `backend` during review, profile
/// config taking precedence over shared defaults (same precedence
/// convention as `strong_review_backend`/`weak_review_backend`).
fn required_review_capabilities(cfg: &GahConfig, profile: &Profile, backend: &str) -> Vec<String> {
    profile
        .routing
        .review_required_capabilities
        .get(backend)
        .or_else(|| {
            cfg.defaults
                .routing
                .review_required_capabilities
                .get(backend)
        })
        .cloned()
        .unwrap_or_default()
}

/// TICKET-105: preflight for review, extended beyond plain binary
/// existence. Distinguishes exactly why a review can't proceed with its
/// configured capability policy:
/// - "backend unavailable" -- the executable itself doesn't resolve
/// - "required capability missing" -- executable present, but the
///   capability (e.g. Ponytail) isn't installed
/// - "reviewer degraded" -- the capability is required but GAH has no known
///   way to activate it for this backend (never silently downgrades)
///
/// Shared by `review()` (actual invocation) and `doctor.rs --validate`
/// (preflight only) so the two can never drift into inconsistent checks.
/// Returns the capabilities that will be applied on success.
pub fn review_preflight(cfg: &GahConfig, profile: &Profile, backend: &str) -> Result<Vec<String>> {
    let identity = crate::execution_identity::ExecutionIdentity::legacy_candidate(
        backend,
        None::<String>,
        None::<String>,
    );
    review_preflight_for_identity(cfg, profile, &identity)
}

pub fn review_preflight_for_identity(
    cfg: &GahConfig,
    profile: &Profile,
    identity: &crate::execution_identity::ExecutionIdentity,
) -> Result<Vec<String>> {
    ensure_supported_runner_kind(identity)?;
    execution_identity_executable(profile, identity).map_err(|_| {
        anyhow::anyhow!(
            "backend unavailable: '{}' executable not found",
            identity.logical_backend
        )
    })?;
    let backend = identity.logical_backend.as_str();
    let required = required_review_capabilities(cfg, profile, backend);
    for capability in &required {
        if !crate::capability::is_capability_available(capability, None) {
            anyhow::bail!(
                "required capability missing: '{}' is required for backend '{}' review but is not installed",
                capability,
                backend
            );
        }
        if crate::capability::activation_prefix(capability).is_none() {
            anyhow::bail!(
                "reviewer degraded: capability '{}' is required for backend '{}', but GAH does not know how to activate it -- refusing to silently run an ordinary review",
                capability,
                backend
            );
        }
    }
    Ok(required)
}

pub(super) fn ensure_bin(bin: &str) -> Result<()> {
    if which(bin).is_some() {
        Ok(())
    } else {
        anyhow::bail!("required binary '{}' not found on PATH", bin);
    }
}

pub(super) fn apply_route_to_ledger(ledger: &mut LedgerEntry, route: &RouteDecision) {
    ledger.backend = route.effective_backend.clone();
    ledger.requested_backend = route.requested_backend.clone();
    ledger.effective_backend = route.effective_backend.clone();
    ledger.requested_model = route.requested_model.clone();
    ledger.effective_model = route.effective_model.clone();
    ledger.routing_reason = Some(route.routing_reason.clone());
    ledger.fallback_used = route.fallback_used;
    ledger.confidence_impact = route.confidence_impact.clone();
    ledger.human_required_reason_code = None;
    ledger.human_required = route.human_required;
    ledger.routing_diagnostics = route.routing_diagnostics.clone();
}

/// Live-observed bug: `worktree::create`/`create_existing` failures (e.g. a
/// transient `git fetch` auth/network error) were propagating via `?`
/// straight past every `ledger.set_failure()` call site, reaching `run()`'s
/// top-level handler with `failure_class` still `None`. An unclassified
/// ticket is invisible to both of `decide_next_action`'s retry/escalate
/// loops (both gate on `Some(failure_class)`), so it becomes permanently
/// stuck once `prior_attempt_count > 0`. This is a harness/setup problem
/// (git plumbing), not the agent or backend failing at its job -- same
/// reasoning as the `BackendLaunch` classification below -- so classify it
/// the same way before propagating.
pub(super) fn classify_worktree_result<T>(
    ledger: &mut LedgerEntry,
    result: Result<T>,
) -> Result<T> {
    classify_git_operation_result(ledger, crate::ledger::FailureStage::Preflight, result)
}

pub(super) fn classify_git_operation_result<T>(
    ledger: &mut LedgerEntry,
    stage: crate::ledger::FailureStage,
    result: Result<T>,
) -> Result<T> {
    if let Err(err) = &result {
        let class = if worktree::is_transient_network_error(&format!("{err:#}")) {
            crate::ledger::FailureClass::EnvironmentError
        } else {
            crate::ledger::FailureClass::HarnessError
        };
        ledger.set_failure(class, stage);
    }
    result
}

pub(super) fn decide_route(
    cfg: &GahConfig,
    profile: &Profile,
    req: RouteRequest<'_>,
    task: Option<&WorkMetadata>,
    ledger: &mut LedgerEntry,
) -> Result<RouteDecision> {
    let runtime = routing_runtime_state(cfg, ledger)?;
    let decision = if let Some(task) = task {
        routing::decide_for_task_with_state(
            &cfg.defaults,
            profile,
            req,
            TaskRoutingContext {
                task_class: task.task_class.as_deref(),
                difficulty: task.difficulty.as_deref(),
                risk: task.risk.as_deref(),
            },
            &runtime,
        )
    } else {
        routing::decide_with_state(&cfg.defaults, profile, req, &runtime)
    };
    match decision {
        Ok(route) => {
            crate::ledger::notify_paid_route_skips(
                cfg,
                profile,
                ledger,
                route.routing_diagnostics.as_ref(),
            );
            Ok(route)
        }
        Err(err) => {
            if let Some(route_err) = err.downcast_ref::<RouteError>() {
                let (selected_backend, selected_model, skipped) = match route_err {
                    RouteError::ApprovalRequired {
                        backend,
                        model,
                        skipped,
                        ..
                    } => (Some(backend.clone()), model.clone(), skipped),
                    RouteError::NoEligibleBackend {
                        preferred_backend,
                        preferred_model,
                        skipped,
                        ..
                    } => (
                        Some(preferred_backend.clone()),
                        preferred_model.clone(),
                        skipped,
                    ),
                };
                ledger.routing_diagnostics = Some(crate::ledger::RoutingDiagnostics {
                    selected_backend,
                    selected_model,
                    candidates: skipped
                        .iter()
                        .enumerate()
                        .map(
                            |(index, candidate)| crate::ledger::RoutingCandidateDiagnostic {
                                backend: candidate.backend.clone(),
                                backend_instance: candidate.backend_instance.clone(),
                                model: candidate.model.clone(),
                                consideration_order: Some(index),
                                skip_reason: Some(candidate.reason.clone()),
                                unavailable_until: candidate.unavailable_until.clone(),
                                ..Default::default()
                            },
                        )
                        .collect(),
                    human_summary: Some(route_err.to_string()),
                    ..Default::default()
                });
                crate::ledger::notify_paid_route_skips(
                    cfg,
                    profile,
                    ledger,
                    ledger.routing_diagnostics.as_ref(),
                );
                // Transient: every candidate backend is momentarily unavailable
                // (quota/cooldown), and this self-resolves once an
                // `unavailable_until`/`earliest_reset` window passes -- same
                // "harness/setup, not agent failure" reasoning as
                // `classify_worktree_result` above. Match exhaustively so a
                // future non-transient `RouteError` variant doesn't silently
                // inherit this classification.
                let class = match route_err {
                    RouteError::NoEligibleBackend { .. } => {
                        if route_err.is_capacity_deferral() {
                            ledger.validation_result = Some("deferred_capacity".into());
                        }
                        crate::ledger::FailureClass::BackendError
                    }
                    RouteError::ApprovalRequired {
                        backend,
                        backend_instance,
                        model,
                        ..
                    } => {
                        ledger.human_required = true;
                        ledger.human_required_reason_code =
                            Some(HumanRequiredReason::PolicyApproval.as_str().to_string());
                        ledger.error_summary = Some(format!(
                            "paid route approval required; run: gah route-approval grant --profile {} {} --backend {}{}{}",
                            ledger.profile,
                            ledger.work_id.as_deref().unwrap_or("<work-id>"),
                            backend,
                            backend_instance
                                .as_deref()
                                .filter(|instance| *instance != backend)
                                .map(|instance| format!(" --instance {instance}"))
                                .unwrap_or_default(),
                            model
                                .as_deref()
                                .map(|model| format!(" --model {model}"))
                                .unwrap_or_default()
                        ));
                        crate::ledger::FailureClass::HumanBlocked
                    }
                };
                ledger.set_failure(class, crate::ledger::FailureStage::Route);
            } else if format!("{:#}", err).contains("parsing availability state") {
                ledger.set_failure(
                    crate::ledger::FailureClass::EnvironmentError,
                    crate::ledger::FailureStage::Route,
                );
            }
            Err(err)
        }
    }
}

/// Preserve an operator-pinned backend across validation retries; automatic
/// routes may escalate to a different candidate.
pub(super) fn validation_retry_route(
    cfg: &GahConfig,
    profile: &Profile,
    req: &RouteRequest<'_>,
    task: Option<&WorkMetadata>,
    ledger: &mut LedgerEntry,
    current: &RouteDecision,
) -> Result<RouteDecision> {
    if req.requested_backend != "auto" {
        return Ok(current.clone());
    }
    let mut escalation = req.clone();
    escalation.last_failure_class = Some(crate::ledger::FailureClass::ValidationFailure.as_str());
    decide_route(cfg, profile, escalation, task, ledger)
}

pub(super) fn routing_runtime_state(
    cfg: &GahConfig,
    current: &LedgerEntry,
) -> Result<RoutingRuntimeState> {
    let entries = ledger::read_entries(cfg)?;
    let mut state = routing_runtime_state_from_entries(&entries, current);
    let reconciliations = ledger::reconcile::read_reconciliation_entries(cfg).unwrap_or_default();
    state.reviewer_outcomes = crate::routing::reviewer_outcome_metrics(
        &entries,
        &reconciliations,
        &current.profile,
        &current.repo_id,
    );
    Ok(state)
}

pub(crate) fn routing_runtime_state_from_entries(
    entries: &[LedgerEntry],
    current: &LedgerEntry,
) -> RoutingRuntimeState {
    let cutoff = OffsetDateTime::now_utc() - time::Duration::days(7);
    let mut state = RoutingRuntimeState::default();
    for entry in entries
        .iter()
        .filter(|entry| entry.profile == current.profile)
    {
        let in_window = OffsetDateTime::parse(&entry.timestamp, &Rfc3339)
            .map(|timestamp| timestamp >= cutoff)
            .unwrap_or(false);
        if in_window && is_agent_execution_mode(&entry.mode) {
            if entry.attempts.is_empty() {
                if entry.attempts_completed.unwrap_or(0) > 0 || entry.backend_exit_code.is_some() {
                    record_recent_route_run(
                        &mut state,
                        &entry.effective_backend,
                        entry.effective_model.as_deref(),
                    );
                }
            } else {
                for attempt in &entry.attempts {
                    record_recent_attempt_run(&mut state, entry, attempt);
                }
            }
        }
    }
    for attempt in &current.attempts {
        record_recent_attempt_run(&mut state, current, attempt);
    }

    if let Some(work_id) = current.work_id.as_deref() {
        let aliases = ledger::work_id_aliases(work_id);
        if is_implementation_execution_mode(&current.mode) {
            for entry in entries.iter().filter(|entry| {
                entry.profile == current.profile
                    && entry.repo_id == current.repo_id
                    && entry
                        .work_id
                        .as_deref()
                        .is_some_and(|id| aliases.iter().any(|alias| alias == id))
                    && is_implementation_execution_mode(&entry.mode)
            }) {
                record_genuine_failure_routes(&mut state, entry);
            }
            record_genuine_failure_routes(&mut state, current);
        }
        for (backend_instance, model) in
            ledger::active_paid_route_approval_destinations_from_entries(
                entries,
                &current.profile,
                work_id,
            )
        {
            state
                .approved
                .insert(CandidateIdentity::new(backend_instance, model));
        }
    }
    state
        .dispatch_attempted
        .extend(current.routing_runtime.dispatch_attempted.iter().cloned());

    state
}

fn record_recent_route_run(state: &mut RoutingRuntimeState, backend: &str, model: Option<&str>) {
    if backend.is_empty() {
        return;
    }
    *state
        .recent_runs
        .entry(CandidateIdentity::new(backend, model))
        .or_insert(0) += 1;
}

fn recorded_attempt_identity(
    entry: &LedgerEntry,
    attempt_number: u32,
) -> Option<&crate::execution_identity::ExecutionIdentity> {
    entry
        .attempt_routing
        .iter()
        .find(|route| route.attempt_number == attempt_number)
        .and_then(|route| route.identity.as_ref())
}

fn record_recent_attempt_run(
    state: &mut RoutingRuntimeState,
    entry: &LedgerEntry,
    attempt: &crate::ledger::AttemptRecord,
) {
    let key = recorded_attempt_identity(entry, attempt.attempt_number)
        .map(CandidateIdentity::from_execution_identity)
        .unwrap_or_else(|| {
            CandidateIdentity::new(attempt.backend.as_str(), attempt.effective_model.as_deref())
        });
    *state.recent_runs.entry(key).or_insert(0) += 1;
}

fn is_agent_execution_mode(mode: &str) -> bool {
    crate::job_kind::JobKind::parse(mode).is_ok()
}

fn is_implementation_execution_mode(mode: &str) -> bool {
    crate::job_kind::JobKind::parse(mode).map(|kind| kind.family())
        == Ok(crate::job_kind::JobFamily::ImproveLike)
}

pub(super) fn record_genuine_failure_routes(state: &mut RoutingRuntimeState, entry: &LedgerEntry) {
    let mut recorded_attempt = false;
    for attempt in &entry.attempts {
        if attempt
            .failure_class
            .as_deref()
            .is_some_and(crate::controller::is_genuine_agent_failure)
        {
            let key = recorded_attempt_identity(entry, attempt.attempt_number)
                .map(CandidateIdentity::from_execution_identity)
                .unwrap_or_else(|| {
                    CandidateIdentity::new(
                        attempt.backend.as_str(),
                        attempt.effective_model.as_deref(),
                    )
                });
            state.attempted.insert(key);
            recorded_attempt = true;
        }
    }
    if !recorded_attempt
        && entry
            .failure_class
            .as_deref()
            .is_some_and(crate::controller::is_genuine_agent_failure)
        && !entry.effective_backend.is_empty()
    {
        state.attempted.insert(CandidateIdentity::new(
            entry.effective_backend.as_str(),
            entry.effective_model.as_deref(),
        ));
    }
}

pub(super) fn route_identity(backend: &str, model: Option<&str>) -> String {
    format!("{backend}\u{0}{}", model.unwrap_or(""))
}

pub(super) fn route_label(backend: &str, model: Option<&str>) -> String {
    match model {
        Some(model) => format!("{backend}/{model}"),
        None => backend.to_string(),
    }
}

/// Local-only recovery refs for discarded retry attempts. Keep the prefix
/// separate from normal dispatch branches so pruning/inspection can identify
/// them unambiguously without inventing a second user-facing ticket ID.
pub(super) fn wip_checkpoint_branch(dispatch_branch: &str, attempt: u32) -> String {
    format!(
        "gah-wip/{}-attempt-{attempt}",
        dispatch_branch.trim_start_matches("gah/").replace('/', "-")
    )
}

pub(super) fn clear_wip_checkpoints(repo: &Path, checkpoints: &[String]) {
    for checkpoint in checkpoints {
        if let Err(error) = worktree::delete_local_branch(repo, checkpoint) {
            eprintln!(
                "warning: could not remove successful WIP checkpoint {checkpoint}: {error:#}"
            );
        }
    }
}

/// Current instant, but with the *local* UTC offset attached rather than
/// always `+00:00`. `quota_parser::parse` treats a no-timezone time-of-day
/// string in backend output (e.g. Codex's "resets 9:01 PM") as being in
/// `now`'s offset, since that's the only clock available to a backend CLI
/// printing to its own terminal -- it means local wall-clock time, not
/// UTC. Passing `OffsetDateTime::now_utc()` silently mis-resolved every
/// such reset by exactly the host's UTC offset (observed live: a ~3am
/// local reset displaying as "~14h remaining" on a UTC-5 host). Falls back
/// to UTC only if the local offset genuinely can't be determined.
fn now_with_local_offset() -> OffsetDateTime {
    let local_offset_seconds = chrono::Local::now().offset().local_minus_utc();
    let offset =
        time::UtcOffset::from_whole_seconds(local_offset_seconds).unwrap_or(time::UtcOffset::UTC);
    OffsetDateTime::now_utc().to_offset(offset)
}

pub(super) fn mark_backend_unavailable_from_output_for_identity(
    identity: &crate::execution_identity::ExecutionIdentity,
    log_text: &str,
    log_path: &str,
) -> Result<Option<crate::quota_parser::ParsedFailure>> {
    mark_backend_unavailable_from_output_for_identity_at(
        &crate::availability::resolve_state_path(),
        identity,
        log_text,
        log_path,
    )
}

#[cfg(test)]
fn mark_backend_unavailable_from_output_at(
    state_path: &Path,
    backend: &str,
    model: Option<&str>,
    quota_pool: Option<&str>,
    log_text: &str,
    log_path: &str,
) -> Result<Option<crate::quota_parser::ParsedFailure>> {
    let identity =
        crate::execution_identity::ExecutionIdentity::legacy_candidate(backend, model, quota_pool);
    mark_backend_unavailable_from_output_for_identity_at(state_path, &identity, log_text, log_path)
}

fn mark_backend_unavailable_from_output_for_identity_at(
    state_path: &Path,
    identity: &crate::execution_identity::ExecutionIdentity,
    log_text: &str,
    log_path: &str,
) -> Result<Option<crate::quota_parser::ParsedFailure>> {
    let backend = identity.logical_backend.as_str();
    let now = now_with_local_offset();
    // An idle watchdog kill is a backend outage signal, not an ordinary agent
    // failure. Keep this route out of the candidate set for a short bounded
    // cooldown so the next attempt can use another backend/model instead of
    // burning the same five-minute stall again. Both terminal-attribution
    // variants (stalled before changes / stalled during validation with
    // checkpointed changes) are idle-watchdog stalls and trigger the cooldown.
    if log_text.contains("GAH: killed after ")
        && log_text.contains("(stalled")
        && log_text.contains("not just slow).")
    {
        let cooldown = now + time::Duration::minutes(15);
        crate::availability::record_unavailable_for_identity(
            state_path,
            identity,
            crate::availability::Reason::BackendOutage,
            crate::availability::Source::BackendError,
            Some(cooldown),
            Some(format!(
                "backend idle watchdog stalled; cooldown=15m; log={log_path}"
            )),
            now,
        )?;
        return Ok(Some(crate::quota_parser::ParsedFailure {
            backend: backend.to_string(),
            kind: crate::quota_parser::FailureKind::BackendStalled,
            retryable: true,
            reset_at: Some(cooldown.format(&Rfc3339)?),
            retry_after_seconds: Some(15 * 60),
            confidence: crate::quota_parser::Confidence::High,
            matched_evidence: "GAH idle watchdog stall".to_string(),
            unresolved_timezone: None,
        }));
    }
    let Some(parsed) = crate::quota_parser::parse(backend, log_text, now) else {
        return Ok(None);
    };

    // Issue #437: ContextLimitExceeded is a routing signal, not a backend
    // availability problem. The same backend may succeed with a larger-context
    // model, so we must NOT mark it as unavailable.
    if parsed.kind == crate::quota_parser::FailureKind::ContextLimitExceeded {
        return Ok(Some(parsed));
    }

    let parsed_unavailable_until = if let Some(reset_at) = parsed.reset_at.as_deref() {
        OffsetDateTime::parse(reset_at, &Rfc3339).ok()
    } else {
        parsed
            .retry_after_seconds
            .map(|secs| now + time::Duration::seconds(secs as i64))
    };
    // Issue #765: never trust a *computed* ETA past this ceiling -- a
    // mis-parsed or genuinely-wrong ETA observed live spanned multiple days
    // with zero self-correction (both codex and agy, neither of which are
    // `parsed.retryable` for their quota-exhausted classification -- that
    // field means "worth an immediate short-term retry," not "has no ETA",
    // so it's the wrong thing to gate on here). Only clamps when a real ETA
    // was actually computed: `None` (no `reset_at`/`retry_after_seconds` at
    // all, e.g. a bad-credentials auth error) is left untouched -- that
    // case genuinely needs a human, not a ceiling, and forcing it to
    // `Some(ceiling)` would just waste a retry against still-bad
    // credentials every tick. Capping here means every future write is
    // already safe; `availability::reprobe_stale_unavailable_records` (run
    // once per loop tick) separately corrects records written before this
    // existed.
    let ceiling =
        now + time::Duration::seconds(crate::availability::UNAVAILABLE_UNTIL_CEILING_SECONDS);
    let unavailable_until = parsed_unavailable_until.map(|until| until.min(ceiling));
    let reason = match parsed.kind {
        crate::quota_parser::FailureKind::QuotaExhausted => {
            crate::availability::Reason::QuotaExhausted
        }
        crate::quota_parser::FailureKind::RateLimited => crate::availability::Reason::RateLimited,
        crate::quota_parser::FailureKind::AuthenticationError => {
            crate::availability::Reason::AuthenticationError
        }
        crate::quota_parser::FailureKind::BackendStalled => {
            crate::availability::Reason::BackendOutage
        }
        // ContextLimitExceeded is handled by early return at line 1316, so it never reaches here
        crate::quota_parser::FailureKind::ContextLimitExceeded => unreachable!(),
    };
    let summary = format!(
        "{}; confidence={:?}; log={}",
        parsed.matched_evidence, parsed.confidence, log_path
    );
    crate::availability::record_unavailable_for_identity(
        state_path,
        identity,
        reason,
        crate::availability::Source::BackendError,
        unavailable_until,
        Some(summary),
        now,
    )?;
    Ok(Some(parsed))
}

pub(super) fn route_after_backend_unavailable<'a>(
    cfg: &crate::config::GahConfig,
    profile: &Profile,
    route_req: &RouteRequest<'a>,
    ticket_meta: Option<&WorkMetadata>,
    ledger: &mut LedgerEntry,
    route: &RouteDecision,
    failure_output: (&str, &str),
) -> Result<Option<(crate::quota_parser::ParsedFailure, RouteDecision)>> {
    let Some(parsed) = mark_backend_unavailable_from_output_for_identity(
        &route.identity,
        failure_output.0,
        failure_output.1,
    )?
    else {
        return Ok(None);
    };

    let rerouted = decide_route(cfg, profile, route_req.clone(), ticket_meta, ledger)?;

    Ok(Some((parsed, rerouted)))
}

/// Combine CLI output with the run-scoped diagnostic tail captured from a
/// backend-owned internal log. Missing internal logs intentionally preserve
/// existing output-only behavior.
pub(super) fn failure_text_with_internal_log(
    output: &str,
    internal_log_delta: Option<&str>,
) -> String {
    let Some(delta) = internal_log_delta.filter(|delta| !delta.trim().is_empty()) else {
        return output.to_string();
    };
    if output.trim().is_empty() {
        return format!("[backend internal log]\n{delta}");
    }
    format!("{output}\n\n[backend internal log]\n{delta}")
}

#[cfg(test)]
#[path = "attempts/external_approval_gate_tests.rs"]
mod external_approval_gate_tests;
#[cfg(test)]
mod tests;
