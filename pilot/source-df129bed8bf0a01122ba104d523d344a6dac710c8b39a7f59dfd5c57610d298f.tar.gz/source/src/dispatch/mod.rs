use self::terminal::should_notify_dispatch_failure;
use crate::config::{self, GahConfig};
use crate::job_kind::{JobFamily, JobKind};
use crate::ledger::LedgerEntry;
use crate::notifications::notify_terminal_failure;
use crate::usage_attribution::{aggregate_attempt_usage, usage_has_observation};
use anyhow::Result;
use std::fs;
use std::path::PathBuf;
use std::time::Instant;

pub mod checkpoints;

mod already_satisfied;
mod attempts;
mod claims;
mod command;
pub(crate) mod dependencies;
mod dry_run;
mod environment;
mod error;
pub(crate) mod external_approval_pause;
mod identity;
mod issues;
mod metrics;
mod mutation_policy;
mod prior_attempts;
mod prompts;
mod publish;
mod repair_context;
mod repo_inspection;
mod review;
mod terminal;
#[cfg(test)]
mod test_util;
mod text;
mod validation;
mod workflows;

pub use self::review::policy::review_budget_exhausted_error;
pub(crate) use self::text::utf8_safe_prefix;

/// Explicitly publish a previously validated PM plan. Planning itself never
/// calls this path; the CLI requires a separate operator-visible command.
pub(crate) fn publish_pm_plan(
    cfg: &GahConfig,
    profile_name: &str,
    plan_path: &std::path::Path,
    dry_run: bool,
    expected_fingerprint: Option<&str>,
) -> Result<PmPublicationSummary> {
    let profile = config::get_profile(cfg, profile_name)?;
    environment::export_profile_env(profile, false);
    workflows::run_pm_publish(
        cfg,
        profile_name,
        profile,
        plan_path,
        dry_run,
        expected_fingerprint,
    )
}

pub(crate) use self::workflows::{pm_plans, PmPublicationSummary};

pub(crate) fn validate_pm_source_depth(
    cfg: &GahConfig,
    profile_name: &str,
    target: &str,
) -> Result<u32> {
    let profile = config::get_profile(cfg, profile_name)?;
    environment::export_profile_env(profile, false);
    workflows::validate_pm_source_depth(profile, target)
}

pub use self::attempts::{capacity_deferred_error, node_capacity_deferred_error, review_preflight};
pub(crate) use self::attempts::{
    contextualize_capacity_deferral, post_attempt_capacity_deferral,
    routing_runtime_state_from_entries,
};

pub(crate) use self::claims::duplicate_work_error;
pub use self::claims::{merge_branch, MergeExecution};
pub(crate) use self::claims::{scan_available_tickets_with_dependencies, TicketScan};
pub(crate) use self::prior_attempts::prior_attempt_context;
pub use self::validation::{self_check_validation_gate, ValidationGateError};

fn ensure_terminal_failure_attribution(
    failure_class: &mut Option<String>,
    failure_stage: &mut Option<String>,
) {
    failure_class.get_or_insert_with(|| {
        crate::ledger::FailureClass::HarnessError
            .as_str()
            .to_string()
    });
    failure_stage.get_or_insert_with(|| crate::ledger::FailureStage::Dispatch.as_str().to_string());
}

pub(super) const MIN_DISPATCH_FREE_BYTES: u64 = 10 * 1024 * 1024 * 1024;

pub struct DispatchArgs {
    pub profile: String,
    pub mode: String,
    pub backend: String,
    pub target: String,
    pub branch: Option<String>,
    pub mr: Option<String>,
    pub current_branch: bool,
    pub dry_run: bool,
    pub oh_profile: Option<String>,
    pub model: Option<String>,
    pub retries: u32,
    pub allow_draft_fail: bool,
    pub prod: bool,
    pub issue_intake_override: bool,
    /// TICKET-111: proceed despite a baseline validation failure that the
    /// classifier could not attribute to harness/environment/expected-red
    /// (`BaselineDisposition::UnknownRed`). Named for exactly what it
    /// overrides, not a generic bypass.
    pub allow_unknown_red_baseline: bool,
    /// TICKET-079/089: seeds the *initial* route decision as if the prior
    /// attempt were a genuine agent-capability failure, activating the same
    /// cost-aware escalation-to-a-stronger-model logic TICKET-089 already
    /// applies mid-retry-loop -- reused here so `NextAction::Escalate`
    /// doesn't need a second escalation mechanism.
    pub escalate: bool,
    /// TICKET-118: for FixMr action, reuse an existing branch instead of creating a new one.
    pub existing_branch: Option<String>,
    /// Exact review generation selected by the controller for an existing-
    /// branch repair. Direct CLI dispatches leave this unset; controller
    /// FixMr actions require an exact match during repair-context preflight.
    pub expected_review_generation: Option<String>,
    /// TICKET-073: deliberately bypass the fresh-worktree self-verification of
    /// a profile's `validation_commands`. Intended only for recovering from a
    /// known-broken config after the operator has acknowledged the failure.
    pub skip_validation_gate: bool,
    /// Distinguishes dispatch purpose for ledger persistence: `initial`,
    /// `retry`, `escalate`, `post_review_repair`, `review`, or
    /// `stuck_loop_gate`. The retry cap counts only `post_review_repair`
    /// entries.
    pub dispatch_reason: Option<String>,
    /// Bounded, redacted evidence from prior controller dispatches. Populated
    /// only for Retry/Escalate; direct and initial dispatches leave it absent.
    pub prior_attempt_context: Option<String>,
    /// Controller-provided work identity, especially important for reviews
    /// that do not resolve a ticket file during dispatch.
    pub work_id: Option<String>,
    /// Controller-assigned identity shared by start/finish events and the
    /// resulting ledger entry. Direct CLI dispatches generate one in `run`.
    pub run_id: Option<String>,
    /// Parallel-controller two-phase admission: after reserving the selected
    /// route, request node capacity and wait for the controller's decision.
    /// Direct CLI dispatches leave this unset and retain blocking route waits.
    pub route_admission: Option<crate::controller::RouteNodeAdmission>,
}

pub fn run(cfg: &GahConfig, args: &DispatchArgs) -> Result<()> {
    let profile = config::get_profile(cfg, &args.profile)?;
    environment::export_profile_env(profile, args.prod);

    println!("Profile: {}", profile.display_name);
    println!("Repo:    {}", profile.repo);
    println!("Branch:  {}", profile.default_target_branch);
    println!("Mode:    {}", args.mode);
    println!("Backend: {}", args.backend);
    println!();

    if args.dry_run {
        return dry_run::dry_run(cfg, profile, args);
    }

    // TICKET-073: verify the dispatch gate itself (validation_commands) against
    // a fresh worktree before spending any backend budget. Skips entirely when
    // the commands are unchanged since the last successful self-check (fast
    // path, hash compare only); otherwise spins up one fresh worktree and runs
    // the commands once. A failed self-check bails with a distinct error and is
    // NOT conflated with the dispatched ticket's own outcome.
    self_check_validation_gate(profile, cfg, args.skip_validation_gate)?;

    // Issue #882: local claim-mode ledger entry, or a central claims API
    // lease when configured (fail closed) -- see claims::acquire_claim.
    // The guard is kept alive for the rest of `run()` via this binding;
    // its `Drop` releases the claim on every exit path below, including
    // the many early returns.
    let _central_claim_guard =
        if JobKind::parse(&args.mode).map(|kind| kind.family()) == Ok(JobFamily::ImproveLike) {
            claims::acquire_claim(cfg, profile, args)?
        } else {
            None
        };

    let ts = args
        .run_id
        .clone()
        .unwrap_or_else(|| uuid::Uuid::new_v4().to_string());
    let session_dir = PathBuf::from(&profile.artifact_root)
        .join("sessions")
        .join(&ts);
    let mut ledger = LedgerEntry::new(
        &args.profile,
        profile,
        &args.backend,
        &args.mode,
        &args.target,
        Some(ts.clone()),
        Some(&session_dir),
    );
    ledger.work_id = args.work_id.clone();
    ledger.dispatch_reason = args.dispatch_reason.clone();
    let started = Instant::now();
    fs::create_dir_all(&session_dir)?;
    println!("Session: {}", session_dir.display());

    let result = match JobKind::parse(&args.mode) {
        Ok(JobKind::Improve | JobKind::Fix) => {
            workflows::run_improve(cfg, profile, args, &session_dir, &mut ledger)
        }
        Ok(JobKind::Pm) => {
            workflows::run_pm(cfg, &args.profile, profile, args, &session_dir, &mut ledger)
        }
        Ok(JobKind::Review) => workflows::run_review(cfg, profile, args, &session_dir, &mut ledger),
        Ok(JobKind::Experiment) => {
            workflows::run_experiment(cfg, &args.profile, profile, args, &session_dir, &mut ledger)
        }
        Ok(JobKind::Research | JobKind::Audit | JobKind::Estimate) => {
            workflows::run_research(cfg, &args.profile, profile, args, &session_dir, &mut ledger)
        }
        Err(_) => anyhow::bail!("unknown mode: {}", args.mode),
    };
    ledger.duration_seconds = Some(started.elapsed().as_secs_f64());
    if !usage_has_observation(&ledger.usage) {
        ledger.usage = aggregate_attempt_usage(&ledger.attempts);
    }
    if let Err(err) = &result {
        // Every terminal dispatch error must be attributable. More precise
        // workflow boundaries set their own class/stage; this fallback marks
        // uncaught orchestration/plumbing errors as harness-owned rather than
        // sending an operationally useless class=unknown/stage=unknown alert.
        ensure_terminal_failure_attribution(&mut ledger.failure_class, &mut ledger.failure_stage);
        ledger.error_summary = Some(error::summarize_error(err));
    }
    let policy_approval_gate = terminal::is_policy_approval_gate(&ledger);
    let append_result = terminal::append_ledger_entry(cfg, &ledger, policy_approval_gate);
    if let Err(err) = &append_result {
        eprintln!("warning: failed to append ledger entry: {:#}", err);
    }
    if result.is_ok() && append_result.is_ok() {
        if let Err(err) = crate::ledger::complete_external_approvals_for_work_item(
            cfg,
            &args.profile,
            profile,
            ledger.work_id.as_deref(),
        ) {
            eprintln!("warning: failed to complete external approval: {err:#}");
        }
    }
    // Issue #230: every terminal attempt (success, failure, timeout,
    // cancellation, or policy refusal) schedules an idempotent telemetry
    // export from the now-durable ledger. Runs after the append above so a
    // failed/slow export can never rewrite or lose the authoritative
    // ledger outcome; export failures are retained in export health state
    // for bounded retry rather than surfaced here.
    crate::telemetry::schedule_export_after_terminal_attempt(cfg);
    // Approval skips notify at routing time, including nonterminal fallbacks.
    if result
        .as_ref()
        .err()
        .is_some_and(should_notify_dispatch_failure)
        && !policy_approval_gate
    {
        notify_terminal_failure(
            cfg,
            profile,
            crate::notifications::TerminalFailurePayload {
                profile: &args.profile,
                work_id: ledger
                    .work_id
                    .as_deref()
                    .or(ledger.branch.as_deref())
                    .unwrap_or("unknown"),
                run_id: &ts,
                failure_class: ledger.failure_class.as_deref().unwrap_or("unknown"),
                failure_stage: ledger.failure_stage.as_deref(),
                attempt_count: ledger.attempts_started,
                error_summary: ledger.error_summary.as_deref(),
                mr_url: ledger.mr_url.as_deref().or(ledger.branch.as_deref()),
            },
        );
    }
    result
}

#[cfg(test)]
mod tests;
