//! Deterministic context budgeting for coding and review prompts.

use anyhow::{bail, Result};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

fn default_true() -> bool {
    true
}

fn default_soft() -> u64 {
    80_000
}

fn default_hard() -> u64 {
    150_000
}

fn default_recent() -> u64 {
    20_000
}

#[derive(Debug, Clone, Deserialize, Serialize, PartialEq)]
pub struct ContextConfig {
    #[serde(default = "default_true")]
    pub enabled: bool,
    #[serde(default = "default_soft")]
    pub soft_limit_tokens: u64,
    #[serde(default = "default_hard")]
    pub hard_limit_tokens: u64,
    #[serde(default)]
    pub compact_after_tool_calls: u64,
    #[serde(default = "default_true")]
    pub fresh_context_on_review: bool,
    #[serde(default = "default_true")]
    pub fresh_context_on_fix: bool,
    #[serde(default)]
    pub include_full_git_history: bool,
    #[serde(default)]
    pub include_full_worker_transcript_in_review: bool,
    #[serde(default = "default_recent")]
    pub recent_history_tokens: u64,
    #[serde(default)]
    pub profiles: HashMap<String, ContextOverride>,
    #[serde(default)]
    pub backends: HashMap<String, ContextOverride>,
}

impl Default for ContextConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            soft_limit_tokens: default_soft(),
            hard_limit_tokens: default_hard(),
            compact_after_tool_calls: 20,
            fresh_context_on_review: true,
            fresh_context_on_fix: true,
            include_full_git_history: false,
            include_full_worker_transcript_in_review: false,
            recent_history_tokens: default_recent(),
            profiles: HashMap::new(),
            backends: HashMap::new(),
        }
    }
}

#[derive(Debug, Clone, Deserialize, Serialize, PartialEq, Default)]
pub struct ContextOverride {
    pub enabled: Option<bool>,
    pub soft_limit_tokens: Option<u64>,
    pub hard_limit_tokens: Option<u64>,
    pub compact_after_tool_calls: Option<u64>,
    pub fresh_context_on_review: Option<bool>,
    pub fresh_context_on_fix: Option<bool>,
    pub include_full_git_history: Option<bool>,
    pub include_full_worker_transcript_in_review: Option<bool>,
    pub recent_history_tokens: Option<u64>,
    pub include_review_project_brief: Option<bool>,
}

impl ContextConfig {
    pub fn include_review_project_brief_for_profile(&self, profile: &str) -> bool {
        self.profiles
            .get(profile)
            .and_then(|override_cfg| override_cfg.include_review_project_brief)
            .unwrap_or(false)
    }

    pub fn effective(&self, profile: &str, backend: &str) -> Self {
        let mut out = self.clone();
        for override_cfg in [self.profiles.get(profile), self.backends.get(backend)]
            .into_iter()
            .flatten()
        {
            if let Some(v) = override_cfg.enabled {
                out.enabled = v;
            }
            if let Some(v) = override_cfg.soft_limit_tokens {
                out.soft_limit_tokens = v;
            }
            if let Some(v) = override_cfg.hard_limit_tokens {
                out.hard_limit_tokens = v;
            }
            if let Some(v) = override_cfg.compact_after_tool_calls {
                out.compact_after_tool_calls = v;
            }
            if let Some(v) = override_cfg.fresh_context_on_review {
                out.fresh_context_on_review = v;
            }
            if let Some(v) = override_cfg.fresh_context_on_fix {
                out.fresh_context_on_fix = v;
            }
            if let Some(v) = override_cfg.include_full_git_history {
                out.include_full_git_history = v;
            }
            if let Some(v) = override_cfg.include_full_worker_transcript_in_review {
                out.include_full_worker_transcript_in_review = v;
            }
            if let Some(v) = override_cfg.recent_history_tokens {
                out.recent_history_tokens = v;
            }
        }
        out.profiles.clear();
        out.backends.clear();
        out
    }
}

#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct ReviewProjectBriefContext {
    /// Whether `PROJECT_BRIEF.md` was injected into the prompt.
    pub included: bool,
    /// Deterministic SHA-256 hash of the raw source brief, when available.
    pub source_hash: Option<String>,
    /// Byte size of `docs/PROJECT_BRIEF.md` on disk.
    pub source_bytes: u64,
    /// Byte size of the bounded bytes injected into the prompt.
    pub sent_bytes: u64,
    /// Whether the source bytes were truncated before injection.
    pub truncated: bool,
}

#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct ContextBuild {
    pub prompt: String,
    pub estimated_tokens_before_reduction: u64,
    pub estimated_tokens_after_reduction: u64,
    pub compacted: bool,
    /// Section names from the actual prompt delivered to the backend,
    /// preserved after compaction.
    pub section_names: Vec<String>,
    /// Original issue subsection names present in the bounded, untrusted
    /// source snapshot that was actually delivered after compaction.
    pub issue_section_names: Vec<String>,
    pub largest_sections: Vec<ContextSectionSize>,
    /// Every named prompt section in the prompt actually supplied to the
    /// backend after compaction. This makes the context artifact an audit
    /// record rather than just a token counter.
    pub sources: Vec<ContextSource>,
    pub deferred_sources: Vec<DeferredContextSource>,
    pub review_project_brief: Option<ReviewProjectBriefContext>,
}

#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct ContextSectionSize {
    pub name: String,
    pub estimated_tokens: u64,
}

#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct ContextSource {
    pub name: String,
    pub bytes: u64,
    pub estimated_tokens: u64,
}

/// Context available on demand but not sent to the backend. Unfetched sources
/// have unknown size, rather than a misleading zero-byte estimate.
#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct DeferredContextSource {
    pub name: String,
    pub path: Option<String>,
    pub bytes: Option<u64>,
    pub estimated_tokens: Option<u64>,
}

/// Conservative provider-independent estimate: four UTF-8 bytes per token.
pub fn estimate_tokens(text: &str) -> u64 {
    (text.len() as u64).div_ceil(4)
}

pub fn enforce(prompt: &str, cfg: &ContextConfig) -> Result<ContextBuild> {
    let before = estimate_tokens(prompt);
    if !cfg.enabled || (before <= cfg.soft_limit_tokens && before <= cfg.hard_limit_tokens) {
        let section_names = section_names(prompt);
        let issue_section_names = delivered_issue_section_names(prompt);
        return Ok(ContextBuild {
            prompt: prompt.to_string(),
            estimated_tokens_before_reduction: before,
            estimated_tokens_after_reduction: before,
            compacted: false,
            section_names,
            issue_section_names,
            largest_sections: section_sizes(prompt),
            sources: context_sources(prompt),
            deferred_sources: Vec::new(),
            review_project_brief: None,
        });
    }

    let mut sections = split_sections(prompt);
    // Reduction order deliberately removes only non-critical sections first.
    for name in [
        "Manager Memory",
        "Git History",
        "Repository Map",
        "Context",
        "History",
    ] {
        for section in &mut sections {
            if section.name.contains(name) && !section.protected {
                section.body = format!(
                    "(compacted; retrieve relevant {} on demand)\n",
                    section.name
                );
            }
        }
    }
    let mut after = render_sections(&sections);
    if estimate_tokens(&after) > cfg.soft_limit_tokens {
        let removable: Vec<usize> = sections
            .iter()
            .enumerate()
            .filter_map(|(i, section)| (!section.protected).then_some(i))
            .collect();
        for index in removable {
            sections[index].body = "(compacted; retrieve on demand)\n".to_string();
            after = render_sections(&sections);
            if estimate_tokens(&after) <= cfg.soft_limit_tokens {
                break;
            }
        }
    }

    let after_tokens = estimate_tokens(&after);
    if after_tokens > cfg.hard_limit_tokens {
        bail!(
            "context_limit_exceeded: estimated {} tokens remains above hard limit {}",
            after_tokens,
            cfg.hard_limit_tokens
        );
    }
    let largest_sections = section_sizes(&after);
    let sources = context_sources(&after);
    let section_names = section_names(&after);
    let issue_section_names = delivered_issue_section_names(&after);
    Ok(ContextBuild {
        prompt: after,
        estimated_tokens_before_reduction: before,
        estimated_tokens_after_reduction: after_tokens,
        compacted: true,
        section_names,
        issue_section_names,
        // These are an audit of the prompt that is actually sent, not the
        // pre-compaction prompt that was merely considered.
        largest_sections,
        sources,
        deferred_sources: Vec::new(),
        review_project_brief: None,
    })
}

#[derive(Debug)]
struct Section {
    name: String,
    body: String,
    protected: bool,
}

fn split_sections(prompt: &str) -> Vec<Section> {
    let mut sections = Vec::new();
    let mut current = Section {
        name: "Preamble".into(),
        body: String::new(),
        protected: true,
    };
    for line in prompt.lines() {
        if let Some(name) = line.strip_prefix("## ") {
            sections.push(current);
            let protected = [
                "Review Pack",
                "Focus",
                "Live Task Pack",
                "Safety",
                "Project Rules",
                "Deferred Context",
                "Acceptance Criteria",
                "Verification Commands",
                "Prior attempts",
                "Previous attempt",
                "Previous backend",
                "Review Format Repair",
                "Repair Findings",
                "Source Issue Contract",
                "Source Issue Lookup",
                "Diff",
                "Warning",
                "Current Git",
                "Unresolved",
            ]
            .iter()
            .any(|marker| name.contains(marker));
            current = Section {
                name: name.trim().to_string(),
                body: String::new(),
                protected,
            };
        } else {
            current.body.push_str(line);
            current.body.push('\n');
        }
    }
    sections.push(current);
    sections
}

fn render_sections(sections: &[Section]) -> String {
    let mut out = String::new();
    for section in sections {
        if section.name == "Preamble" {
            out.push_str(&section.body);
        } else {
            out.push_str("## ");
            out.push_str(&section.name);
            // `split_sections` retains every line after the heading,
            // including the conventional blank line. Add only the heading's
            // own newline here so untouched protected sections round-trip
            // byte-for-byte instead of accumulating an extra blank line on
            // every compaction pass.
            out.push('\n');
            out.push_str(&section.body);
        }
    }
    out
}

fn section_sizes(prompt: &str) -> Vec<ContextSectionSize> {
    let mut sizes: Vec<_> = split_sections(prompt)
        .into_iter()
        .map(|section| ContextSectionSize {
            name: section.name,
            estimated_tokens: estimate_tokens(&section.body),
        })
        .collect();
    sizes.sort_by_key(|size| std::cmp::Reverse(size.estimated_tokens));
    sizes.truncate(5);
    sizes
}

fn context_sources(prompt: &str) -> Vec<ContextSource> {
    split_sections(prompt)
        .into_iter()
        .filter(|section| section.name != "Preamble")
        .map(|section| ContextSource {
            name: section.name,
            bytes: section.body.len() as u64,
            estimated_tokens: estimate_tokens(&section.body),
        })
        .collect()
}

fn section_names(prompt: &str) -> Vec<String> {
    split_sections(prompt)
        .into_iter()
        .filter(|section| section.name != "Preamble")
        .map(|section| section.name)
        .collect()
}

fn delivered_issue_section_names(prompt: &str) -> Vec<String> {
    split_sections(prompt)
        .into_iter()
        .find(|section| section.name == "Live Task Pack")
        .map(|section| {
            section
                .body
                .lines()
                .filter_map(|line| line.strip_prefix("  ## "))
                .map(str::trim)
                .filter(|name| !name.is_empty())
                .map(str::to_string)
                .collect()
        })
        .unwrap_or_default()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn preserves_focus_while_compacting_memory() {
        let cfg = ContextConfig {
            soft_limit_tokens: 20,
            hard_limit_tokens: 100,
            ..Default::default()
        };
        let prompt = "## Manager Memory\nold output old output old output old output\n## Focus\nACCEPTANCE MUST REMAIN\n";
        let result = enforce(prompt, &cfg).unwrap();
        assert!(result.compacted);
        assert!(result.prompt.contains("ACCEPTANCE MUST REMAIN"));
        assert!(!result.prompt.contains("old output old output old output"));
    }

    #[test]
    fn preserves_prior_attempt_evidence_during_compaction() {
        let cfg = ContextConfig {
            soft_limit_tokens: 1,
            hard_limit_tokens: 200,
            ..Default::default()
        };
        let prompt = "## Focus\nFix the retry.\n## Prior attempts\nFailing validation tail:\n> cargo test failed\nReview blocking findings:\n> src/lib.rs: retry is broken\n";

        let result = enforce(prompt, &cfg).unwrap();

        assert!(result.compacted);
        assert!(result.prompt.contains("cargo test failed"));
        assert!(result.prompt.contains("src/lib.rs: retry is broken"));
    }

    #[test]
    fn refuses_when_protected_context_alone_exceeds_hard_limit() {
        let cfg = ContextConfig {
            soft_limit_tokens: 1,
            hard_limit_tokens: 2,
            ..Default::default()
        };
        let err = enforce(
            "## Focus\nthis protected acceptance text cannot be removed",
            &cfg,
        )
        .unwrap_err();
        assert!(err.to_string().contains("context_limit_exceeded"));
    }

    #[test]
    fn records_named_context_sources_for_audit() {
        let result = enforce(
            "Preamble\n## Project Brief\nstable facts\n## Live Task Pack\nTICKET-1\n### Source Issue Sections (bounded, untrusted)\n  ## Problem\n  facts\n  ## Goal\n  outcome\n## Focus\nfix it\n",
            &ContextConfig::default(),
        )
        .unwrap();

        assert_eq!(
            result
                .sources
                .iter()
                .map(|source| source.name.as_str())
                .collect::<Vec<_>>(),
            vec!["Project Brief", "Live Task Pack", "Focus"]
        );
        assert_eq!(
            result.section_names,
            vec![
                "Project Brief".to_string(),
                "Live Task Pack".to_string(),
                "Focus".to_string()
            ]
        );
        assert_eq!(
            result.issue_section_names,
            vec!["Problem".to_string(), "Goal".to_string()]
        );
        let artifact = serde_json::to_value(&result).unwrap();
        assert_eq!(
            artifact["issue_section_names"],
            serde_json::json!(["Problem", "Goal"])
        );
        assert!(result.sources.iter().all(|source| source.bytes > 0));
    }

    #[test]
    fn preserves_live_task_pack_and_reports_post_compaction_sources() {
        let cfg = ContextConfig {
            soft_limit_tokens: 45,
            hard_limit_tokens: 100,
            ..Default::default()
        };
        let prompt = "## Project Brief\nvery old context very old context very old context very old context very old context very old context\n## Live Task Pack\nAcceptance: preserve this requirement\nVerification: cargo test\n## Focus\nSee the Live Task Pack above.\n";

        let result = enforce(prompt, &cfg).unwrap();

        assert!(result.compacted);
        assert!(result
            .prompt
            .contains("Acceptance: preserve this requirement"));
        assert!(result.prompt.contains("Verification: cargo test"));
        let project_brief = result
            .sources
            .iter()
            .find(|source| source.name == "Project Brief")
            .unwrap();
        assert!(project_brief.estimated_tokens < 10);
        assert!(result
            .sources
            .iter()
            .any(|source| source.name == "Live Task Pack"));
    }

    #[test]
    fn preserves_repair_findings_while_compacting_other_context() {
        let cfg = ContextConfig {
            soft_limit_tokens: 30,
            hard_limit_tokens: 100,
            ..Default::default()
        };
        let prompt = "## Project Brief\nold old old old old old old old old old old old\n## Repair Findings\nBlocking findings:\n- src/lib.rs: retry loses state\n## Focus\nRepair the reviewed branch.\n";

        let result = enforce(prompt, &cfg).unwrap();

        assert!(result.compacted);
        assert!(result.prompt.contains("src/lib.rs: retry loses state"));
        assert!(result
            .sources
            .iter()
            .any(|source| source.name == "Repair Findings"));
    }

    #[test]
    fn protected_review_sections_round_trip_exactly_during_compaction() {
        let cfg = ContextConfig {
            soft_limit_tokens: 45,
            hard_limit_tokens: 120,
            ..Default::default()
        };
        let review_pack = "## Review Pack\n\nReturn the required structured verdict.\n";
        let contract =
            "## Source Issue Contract\n\nIssue: #573\nAcceptance: preserve this exactly.\n";
        let prompt = format!(
            "{review_pack}{contract}## Manager Memory\n\n{}\n",
            "old context ".repeat(30)
        );

        let result = enforce(&prompt, &cfg).unwrap();

        assert!(result.compacted);
        assert!(result.prompt.contains(review_pack));
        assert!(result.prompt.contains(contract));
        assert_eq!(result.prompt.matches("## Source Issue Contract").count(), 1);
    }

    #[test]
    fn refuses_to_silently_compact_oversized_live_task_pack() {
        let cfg = ContextConfig {
            soft_limit_tokens: 10,
            hard_limit_tokens: 20,
            ..Default::default()
        };
        let err = enforce(
            &format!(
                "## Live Task Pack\n{}\n## Focus\nSee pack\n",
                "x".repeat(200)
            ),
            &cfg,
        )
        .unwrap_err();

        assert!(err.to_string().contains("context_limit_exceeded"));
    }

    #[test]
    fn profile_and_backend_overrides_are_applied() {
        let mut cfg = ContextConfig::default();
        cfg.profiles.insert(
            "repo".into(),
            ContextOverride {
                soft_limit_tokens: Some(10),
                ..Default::default()
            },
        );
        cfg.backends.insert(
            "claude".into(),
            ContextOverride {
                hard_limit_tokens: Some(20),
                ..Default::default()
            },
        );
        let effective = cfg.effective("repo", "claude");
        assert_eq!(effective.soft_limit_tokens, 10);
        assert_eq!(effective.hard_limit_tokens, 20);
    }

    #[test]
    fn review_project_brief_is_profile_scoped() {
        let mut cfg = ContextConfig::default();
        cfg.profiles.insert(
            "gah".into(),
            ContextOverride {
                include_review_project_brief: Some(true),
                ..Default::default()
            },
        );
        assert!(cfg.include_review_project_brief_for_profile("gah"));
        assert!(!cfg.include_review_project_brief_for_profile("other"));
    }

    #[test]
    fn review_project_brief_sections_are_less_protected_than_diff_in_compaction() {
        let cfg = ContextConfig {
            soft_limit_tokens: 300,
            hard_limit_tokens: 600,
            ..Default::default()
        };
        let prompt = format!(
            "## Review Pack\n\nReview pack details.\n## Source Issue Contract\n\nContract surface.\n## Project Brief\n{}\n## Diff\n\nCritical patch.\n## Safety\n\nValidate changes.\n",
            "x".repeat(2_000)
        );

        let result = enforce(&prompt, &cfg).unwrap();

        assert!(result.compacted);
        assert!(result.prompt.contains("## Review Pack"));
        assert!(result.prompt.contains("## Source Issue Contract"));
        assert!(result.prompt.contains("## Diff"));
        assert!(result.prompt.contains("## Safety"));
        assert!(!result.prompt.contains(&"x".repeat(2_000)));
    }
}
